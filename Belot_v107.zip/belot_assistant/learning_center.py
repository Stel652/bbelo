"""Learning Center (консоль): состояние обучения, ошибки советов, откат чемпиона.
  python learning_center.py            — отчёт
  python learning_center.py rollback   — вернуть предыдущего чемпиона"""
import os, sys, json, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
DATA = os.path.join(HERE, "data"); SP = os.path.join(DATA, "selfplay")

def _j(p, d):
    try: return json.load(open(p, encoding="utf-8"))
    except Exception: return d

def archive_champion(out, old, new, mean, z, n):
    p = os.path.join(out, "champions.json")
    h = _j(p, [])
    h.append(dict(t=int(time.time()), old=old, new=new, mean=round(mean, 3), z=round(z, 2), n=n))
    json.dump(h[-100:], open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

def rollback(sp=SP):
    h = _j(os.path.join(sp, "champions.json"), [])
    if not h: return None
    last = h.pop()
    params = _j(os.path.join(sp, "params.json"), {})
    params["champion"] = last["old"]
    json.dump(params, open(os.path.join(sp, "params.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(h, open(os.path.join(sp, "champions.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return last["old"]

def report():
    from engine.decision_analysis import load, analyse
    st, pr = _j(os.path.join(SP, "stats.json"), {}), _j(os.path.join(SP, "params.json"), {})
    dec = load(os.path.join(DATA, "decisions.jsonl"))
    L = ["BELOT AI — LEARNING CENTER", f"Раздач самоигры: {st.get('rounds', 0)} | нарушений правил: {st.get('violations', 0)}",
         f"Чемпион: {pr.get('champion')}", f"Смен чемпиона: {len(_j(os.path.join(SP, 'champions.json'), []))}",
         f"Решений в decisions.jsonl: {sum(1 for e in dec if e.get('ev') == 'decision')}", "", "Советы по типам (худшие сверху):"]
    for r in analyse(dec)[:10]:
        L.append(f"  {r['reason'][:40]:40} n={r['n']:<4} взято={r['win_rate']} {'' if r['reliable'] else '(мало данных)'}")
    ex = []
    try:
        ex = [json.loads(l) for l in open(os.path.join(SP, "experiments.jsonl"), encoding="utf-8")]
    except Exception: pass
    L += ["", f"Эксперименты (paired_eval): {len(ex)}"]
    for e in ex[-5:]:
        L.append(f"  {e['override']} n={e['n']} разница={e['mean']} z={e['z']} лучше={e['better']}")
    return "\n".join(L)

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "rollback":
        print("Откат на:", rollback())
    else:
        print(report())
