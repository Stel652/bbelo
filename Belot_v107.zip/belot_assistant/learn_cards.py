# learn_cards.py — добавить эталоны карт из скриншота (учим программу вашей колоде).
# Запуск:  python learn_cards.py screenshot.png "A♣ 10♦ J♦ Q♦ K♦ A♦ K♠ A♠"
# Карты перечисляются СЛЕВА НАПРАВО, как лежат в руке. Масти: ♥♦♣♠ или h d c s.
# Можно добавить зону руки:  python learn_cards.py shot.png "7h 8h 9c" x y w h
import sys, os, time, types, cv2
try:
    import mss  # noqa
except ImportError:
    sys.modules["mss"] = types.SimpleNamespace(mss=lambda: None)
import config
from engine.vision import VisionEngine

SUITS = {"♥": "hearts", "h": "hearts", "♦": "diamonds", "d": "diamonds",
         "♣": "clubs", "c": "clubs", "♠": "spades", "s": "spades"}

def parse(tokens):
    out = []
    for t in tokens.replace(",", " ").split():
        t = t.strip()
        suit = SUITS.get(t[-1].lower() if t[-1].isascii() else t[-1])
        rank = t[:-1].upper()
        if suit is None or rank not in ("7", "8", "9", "10", "J", "Q", "K", "A"):
            sys.exit(f"Не понял карту '{t}'. Пример: 10♦ или 10d, Kh, 7c")
        out.append((rank, suit))
    return out

img = cv2.imread(sys.argv[1])
if img is None:
    sys.exit("Не удалось открыть скриншот")
labels = parse(sys.argv[2])
H, W = img.shape[:2]
z = tuple(map(int, sys.argv[3:7])) if len(sys.argv) >= 7 else config.scaled_zone(config.ZONE_MY_HAND, W, H)
x, y, w, h = z
crop = img[y:y+h, x:x+w]
v = VisionEngine()
boxes, _ = v._find_card_boxes(crop)
boxes.sort()
if len(boxes) != len(labels):
    sys.exit(f"Нашёл {len(boxes)} карт на скриншоте, а ты указал {len(labels)}. Проверь список/зону.")
d = os.path.join(os.path.dirname(__file__), "assets", "game_idx")
os.makedirs(d, exist_ok=True)
tag = int(time.time())
for i, ((bx, by, bw, bh), (rank, suit)) in enumerate(zip(boxes, labels)):
    rp, pp, _ = v._idx_patches(crop[by:by+bh, bx:bx+bw])
    cv2.imwrite(os.path.join(d, f"rank_{rank}#{tag}{i}.png"), rp[4:28, 3:23])
    cv2.imwrite(os.path.join(d, f"suit_{suit}#{tag}{i}.png"), pp[4:28, 3:23])
print(f"Добавлено эталонов: {len(labels)} → {d}")
print("Теперь запусти debug_vision.py на этом же скриншоте — все карты должны совпасть.")
