# config.py
"""Настройки захвата экрана и оформления оверлея.

ВАЖНО: перед запуском укажите реальные координаты областей игры.
Формат каждой зоны: (x, y, width, height), в пикселях экрана.
"""

# Замените координаты на реальные области вашего стола/экрана.
ZONE_MY_HAND_OLD = (267, 541, 730, 142)  # старые скриншоты 1279x719 (для тестов)
ZONE_MY_HAND = (320, 568, 638, 107)   # рамка рук по скрину 1918x1078: x480 y852 w957 h160 (/1.5)
ZONE_TABLE = (377, 214, 523, 278)     # стол (зелёное поле), по скрину 1918x1078
ZONE_DECLARER_NAME = (59, 158, 85, 27)  # имя того, кто выбрал козырь (рядом с квадратиком козыря)
ZONE_MY_NAME = (517, 537, 77, 17)       # моё имя внизу (JackDaniels1) — эталон для сравнения
ZONE_DECLARER_NAME_ALT_DY = 30   # раскладка с плашкой «14 / A»: имя ниже на 30 (в опорных координатах)
NAME_MATCH_THR = 0.78            # сходство имени сверху с эталоном «JackDaniels1» (другие имена в тестах <= 0.41)
SHOTS_MAX_FILES = 1400            # data/shots: храним последние N файлов
ZONE_TRUMP = (25, 155, 24, 24)
ZONE_TRUMP_ALT = (25, 185, 24, 24)   # режим с плашкой «14 / A» сверху: иконка козыря ниже       # белый квадратик с мастью козыря слева вверху

TEMPLATE_MATCH_THRESHOLD = 0.72  # углы карт, 1..8 карт
TRUMP_MATCH_THRESHOLD = 0.88
# Set to hearts/diamonds/clubs/spades if no on-screen trump indicator is calibrated.
TRUMP_SUIT = None
CAPTURE_FPS = 20

# RGBA
COLOR_ACCENT = (0, 220, 120, 230)
COLOR_BG = (20, 25, 30, 220)
COLOR_TEXT = (255, 255, 255, 255)

REFERENCE_SCREEN = (1279, 719)
def scaled_zone(zone, screen_w, screen_h):
    """Scale reference coordinates to current screen resolution."""
    rx, ry = REFERENCE_SCREEN
    x, y, w, h = zone
    return (round(x*screen_w/rx), round(y*screen_h/ry),
            max(1,round(w*screen_w/rx)), max(1,round(h*screen_h/ry)))

# Многокадровое подтверждение карт руки (True — применять к советам; False — только журнал vote_diff)
FRAME_VOTING = True

# Автоклик (engine/autoplay.py): бот сам кликает по посоветованной карте. По умолчанию ВЫКЛЮЧЕН, включение — F4.
AUTOPLAY = False
AUTOPLAY_HOLD = 0.8          # сек: совет и рука не должны меняться перед кликом
AUTOPLAY_SCALE = 1.0         # масштаб Windows (если клик попадает мимо: 1.25 / 1.5 и т.п.)
AUTOPLAY_OFFSET = (0, 0)     # смещение экрана в пикселях (второй монитор и т.п.)

# --- Торги и комбинации (engine/bidding.py). Координаты в опорной сетке 1279x719 (= скрин 1918x1078 / 1.5) ---
ZONE_BID_PANEL = (473, 397, 333, 168)    # панель «Joc [масть] / Pas» внизу по центру
ZONE_COMBO = (247, 392, 158, 204)       # слева внизу: сюда выпадают кнопки комбинаций (Bella, Tărț, 50, 100 ...) — до 4 штук друг над другом; по скрину 1920x1080 нижняя Bella доходит до y=888 (ref 592)
BID_AUTO = True                         # автоклик Joc/Pas и выбор козыря во 2-м круге (работает вместе с кнопкой «Автоклик»)
COMBO_AUTO = True                       # автоклик кнопок комбинаций
# Румынские названия (для журнала/OCR; без OCR кнопки определяются по появлению нового объекта в зоне)
COMBO_WORDS = ["bella", "belot", "terta", "tertz", "terț", "jumate suta", "jumătate sută", "jumate", "suta", "sută",
               "carre", "patru", "cinci", "50", "100", "20", "150", "200"]


# --- Чей сейчас ход: у игрока, который ходит, вокруг аватара зелёное кольцо-таймер ---
TURN_RING = True
ZONE_TURN_ME = (580, 513, 107, 73)     # опорная сетка 1279x719: кольцо вокруг МОЕГО аватара (внизу)
ZONE_TURN_L = (253, 313, 133, 133)     # аватар слева
ZONE_TURN_R = (920, 313, 133, 133)     # аватар справа
TURN_MIN_FRAC = 0.004                  # доля зелёных пикселей в зоне, начиная с которой кольцо считается видимым
AUTOPLAY_HOLD_RING = 0.5               # сек. выдержки перед кликом, когда ход подтверждён кольцом

# v104: ожидание хода соперников перед автокликом (если кольцо хода не подтверждено)
AUTOPLAY_WAIT_UNSURE = 2.0
AUTOPLAY_FIRST_WAIT = 3.0

# v107: оракул легальных ходов — игра затемняет карты, которые сейчас нельзя сыграть (engine/playable.py)
SCREEN_LEGAL = True
ZONE_RESULTS = (400, 235, 480, 270)   # центр стола: сюда выпадает окно «Rezultate runda N» (опорная сетка 1279x719)
RESULTS_DIALOG = True
