@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
python -m pip install pyinstaller
python -m PyInstaller --noconfirm --clean --windowed --name "Belot Assistant" --add-data "assets;assets" main.py
 echo.
 echo Build finished. EXE is in dist\Belot Assistant\
 pause
