# train_selfplay.py — АВТОНОМНОЕ ОБУЧЕНИЕ БОТА САМОИГРОЙ (отдельный процесс, не мешает программе).
#
# Запуск:  двойной клик по train_bot.bat   или   python train_selfplay.py [раздач] [--workers N]
#   по умолчанию 10000 раздач за прогон; можно 100000 и больше.  Ctrl+C — остановить, всё сохранится.
#
# Что делает:
#   1. Играет раздачи бот против бота (4 игрока, полные правила: торг, козырь, обязательства).
#   2. КАЖДЫЙ ход проверяет по правилам (can_play_card + независимая проверка «обязан отвечать в масть»),
#      проверяет сумму очков (162), раздачу (32 уникальные карты), победителя взятки. Ошибки пишет в data/selfplay/violations.jsonl.
#   3. Копит опыт в data/selfplay/: stats.json (по типам советов: сколько взяток/очков), params.json
#      (лучшие найденные настройки), rounds.jsonl (журнал раздач), report.txt (человекочитаемый отчёт).
#   4. Подбирает настройки (порог торга, стиль хода козырем, учёт пустых мастей) — кандидат против чемпиона,
#      принимает только если выигрыш статистически значим.  Опыт НАКАПЛИВАЕТСЯ между запусками.
import os, sys, json, time, random, math, argparse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from engine.tracker import CardTracker, deck_for_mode, observe_complete_trick
from engine.rules import can_play_card, who_takes_trick
from engine.strategy import should_play, best_suit, recommend_for_mode
from engine.scoring import points_to_bile
from engine.cards import SUITS

OUT = os.path.join(HERE, "data", "selfplay")
BASE = dict(min_score=50, voids=False, lead_style="small")

def reason_key(why):
    k = (why or "").split(" · ")[0].split(" (")[0].strip()
    return k[:60] or "?"

def play_round(rng, cfgs, dealer, audit=True, collect=None):
    """Одна раздача. cfgs[0] — пара мест 0,2; cfgs[1] — пара мест 1,3. Возвращает (разница бил, нарушения)."""
    viol = []
    deck = list(deck_for_mode("2v2")); rng.shuffle(deck)
    hands = [deck[i * 8:(i + 1) * 8] for i in range(4)]
    if audit and len(set(deck)) != 32:
        viol.append("deck!=32")
    turned = rng.choice(SUITS)
    first5 = [h[:5] for h in hands]
    declarer = trump = None
    for k in range(1, 5):
        p = (dealer + k) % 4
        if should_play(first5[p], turned, cfgs[p % 2]["min_score"])[0]:
            declarer, trump = p, turned; break
    if declarer is None:
        for k in range(1, 5):
            p = (dealer + k) % 4
            s, _ = best_suit(first5[p])
            if s == turned: continue
            if k == 4 or should_play(first5[p], s, cfgs[p % 2]["min_score"])[0]:
                declarer, trump = p, s; break
        if declarer is None:
            declarer = dealer; trump = best_suit(first5[dealer])[0]
    trk = [CardTracker("2v2") for _ in range(4)]
    init_hands = [sorted(str(c) for c in h) for h in hands]   # полная раздача для воспроизведения
    moves, tricks_log = [], []
    leader = declarer; pts = [0, 0]
    for trick in range(8):
        table, order, played = [], [], {}
        for k in range(4):
            p = (leader + k) % 4; h = hands[p]; cfg = cfgs[p % 2]
            snap = trk[p].update(h, table)
            pw = k >= 2 and who_takes_trick(table, trump) == k - 2
            tla = (p == declarer or trick > 0)
            card, why = recommend_for_mode(h, table, trump, "2v2", trump_lead_allowed=tla, is_partner_winning=pw,
                                           snap=snap, i_declared=(p == declarer), last_to_play=(k == 3),
                                           voids=(trk[p].voids if cfg["voids"] else None), lead_style=cfg["lead_style"],
                                           use_mc=False, budget=0.05)
            if card is None:
                viol.append(f"no_card p{p} t{trick}"); card = h[0]
            if audit:
                if card not in h: viol.append(f"card_not_in_hand {card}")
                if not can_play_card(card, table, h, trump, tla):
                    viol.append(f"illegal_by_rules {card} table={[str(c) for c in table]} hand={[str(c) for c in h]} trump={trump}")
                # независимая проверка: есть масть — обязан отвечать в масть
                if table and any(c.suit == table[0].suit for c in h) and card.suit != table[0].suit:
                    viol.append(f"must_follow_suit {card} lead={table[0]}")
            moves.append([trick, p, str(card), reason_key(why)])
            h.remove(card); table.append(card); order.append(p); played[p] = card
            if collect is not None:
                collect.append((reason_key(why), p % 2))
        for p in range(4):
            observe_complete_trick(trk[p], table, played[p], trump)
            trk[p].update(hands[p], table)
        w = order[who_takes_trick(table, trump)]
        tp = sum(c.points(trump) for c in table) + (10 if trick == 7 else 0)
        pts[w % 2] += tp
        tricks_log.append(dict(n=trick, leader=leader, cards=[str(c) for c in table], winner=w, points=tp))
        if collect is not None:
            collect.append(("__trick__", w % 2, tp, [reason for reason in ()]))
        leader = w
    if audit and sum(pts) != 162:
        viol.append(f"points_sum={sum(pts)}")
    dt = declarer % 2
    if pts[dt] < pts[1 - dt]:
        b = [0, 0]; b[1 - dt] = points_to_bile(sum(pts))
    else:
        b = [points_to_bile(pts[0]), points_to_bile(pts[1])]
    return b[0] - b[1], viol, dict(trump=trump, declarer=declarer, pts=pts, dealer=dealer, turned=turned,
                                   hands=init_hands, moves=moves, tricks=tricks_log)

def worker(args):
    """Матч cfgA vs cfgB: n раздач со сменой сторон. Возвращает (сумма, сумма квадратов, n, нарушения, статистика советов)."""
    cfgA, cfgB, n, seed = args
    rng = random.Random(seed); tot = sq = 0; viols = []; adv = {}; rounds = []
    for g in range(n):
        d = rng.randrange(4); col = []
        if g % 2 == 0:
            r, v, info = play_round(rng, [cfgA, cfgB], d, collect=col); side = 0
        else:
            r, v, info = play_round(rng, [cfgB, cfgA], d, collect=col); r = -r; side = 1
        tot += r; sq += r * r
        viols += v[:3]
        for item in col:
            if item[0] == "__trick__": continue
            key, team = item
            a = adv.setdefault(key, [0, 0]); a[0] += 1
        if g < 5 and not v:
            rounds.append(dict(seed=seed, g=g, diff=r, **info))
    return tot, sq, n, viols[:20], adv, rounds

def run_match(pool, cfgA, cfgB, n, base_seed, workers):
    chunk = max(50, n // (workers * 4))
    jobs = []; s = base_seed
    left = n
    while left > 0:
        m = min(chunk, left); jobs.append((cfgA, cfgB, m - (m % 2) or m, s)); s += 1; left -= m
    tot = sq = cnt = 0; viols = []; adv = {}; rounds = []
    for t, q, c, v, a, r in (pool.imap_unordered(worker, jobs) if pool else map(worker, jobs)):
        tot += t; sq += q; cnt += c; viols += v; rounds += r
        for k, (x, _) in a.items():
            adv.setdefault(k, [0, 0])[0] += x
    mean = tot / max(cnt, 1)
    var = sq / max(cnt, 1) - mean * mean
    se = math.sqrt(max(var, 1e-9) / max(cnt, 1))
    return mean, se, cnt, viols, adv, rounds

def load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f: return json.load(f)
    except Exception:
        return default

def save_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)

def neighbours(c):
    out = []
    for ms in (c["min_score"] - 5, c["min_score"] + 5):
        if 25 <= ms <= 80: out.append(dict(c, min_score=ms))
    out.append(dict(c, voids=not c["voids"]))
    out.append(dict(c, lead_style="high" if c["lead_style"] == "small" else "small"))
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("rounds", nargs="?", type=int, default=0, help="0 = играть бесконечно, пока не закроешь окно / Ctrl+C")
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    a = ap.parse_args()
    # низкий приоритет — не мешает основной программе и игре
    try:
        if os.name == "nt":
            import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000)
        else:
            os.nice(15)
    except Exception:
        pass
    os.makedirs(OUT, exist_ok=True)
    import signal
    def _term(*_): raise KeyboardInterrupt()
    for _n in ("SIGTERM", "SIGBREAK", "SIGHUP"):
        if hasattr(signal, _n):
            try: signal.signal(getattr(signal, _n), _term)
            except Exception: pass
    params_p, stats_p = os.path.join(OUT, "params.json"), os.path.join(OUT, "stats.json")
    params = load_json(params_p, {"champion": BASE, "history": [], "total_rounds": 0})
    stats = load_json(stats_p, {"rounds": 0, "violations": 0, "advice": {}, "runs": 0})
    champ = params["champion"]
    import multiprocessing as mp
    pool = mp.Pool(a.workers) if a.workers > 1 else None
    t0 = time.time(); done = 0; seed0 = int(time.time()) % 10**6
    print(f"Обучение: {'БЕСКОНЕЧНО (закрой окно или Ctrl+C)' if a.rounds == 0 else str(a.rounds) + ' раздач'}, процессов {a.workers}, чемпион {champ}")
    try:
        step = 0
        per_match = 1000 if a.rounds == 0 else max(400, min(2000, a.rounds // 10))
        while a.rounds == 0 or done < a.rounds:
            cands = neighbours(champ)
            improved = False
            for cand in cands:
                if a.rounds and done >= a.rounds: break
                seed = random.randrange(10**9); step += 1   # каждый раз новая случайная раздача
                mean, se, cnt, viols, adv, rounds = run_match(pool, cand, champ, per_match, seed, a.workers)
                done += cnt
                stats["rounds"] += cnt
                stats["violations"] += len(viols)
                for k, (x, _) in adv.items():
                    s = stats["advice"].setdefault(k, {"n": 0}); s["n"] += x
                if viols:
                    with open(os.path.join(OUT, "violations.jsonl"), "a", encoding="utf-8") as f:
                        for v in viols: f.write(json.dumps({"t": time.time(), "v": v}, ensure_ascii=False) + "\n")
                with open(os.path.join(OUT, "rounds.jsonl"), "a", encoding="utf-8") as f:
                    for r in rounds: f.write(json.dumps(r, ensure_ascii=False) + "\n")
                z = mean / se if se else 0
                print(f"[{done:>7}/{a.rounds}] {cand} vs чемпион: {mean:+.3f} бил (z={z:+.1f}) нарушений={len(viols)}")
                params["history"].append(dict(cand=cand, mean=round(mean, 3), z=round(z, 2), n=cnt))
                params["history"] = params["history"][-300:]
                if z >= 2.5:      # значимое улучшение -> новый чемпион
                    try:   # версия чемпиона сохраняется для отката (learning_center.py rollback)
                        from learning_center import archive_champion
                        archive_champion(OUT, champ, cand, mean, z, cnt)
                    except Exception: pass
                    champ = cand; improved = True
                    print(f"   ★ новый чемпион: {champ}")
                    break
            params["champion"] = champ; params["total_rounds"] = params.get("total_rounds", 0) + 0
            save_json(params_p, params); save_json(stats_p, stats)
            with open(os.path.join(OUT, "report.txt"), "w", encoding="utf-8") as f_:
                f_.write(f"Самоигра идёт: всего раздач {stats['rounds']}, нарушений правил {stats['violations']}\nЛучшие настройки: {champ}\n")
            if not improved and step % 20 == 0:
                champ = dict(champ)   # чемпион не изменился — продолжаем искать, опыт копится
    except KeyboardInterrupt:
        print("Остановлено пользователем — сохраняю.")
    finally:
        if pool: pool.terminate()
        params["champion"] = champ; params["total_rounds"] = params.get("total_rounds", 0) + done
        stats["runs"] += 1
        save_json(params_p, params); save_json(stats_p, stats)
        dt = time.time() - t0
        rep = (f"Самоигра: {done} раздач за {dt:.0f} с в этом запуске; всего накоплено {stats['rounds']} раздач.\n"
               f"Нарушений правил за всё время: {stats['violations']} (подробности: violations.jsonl)\n"
               f"Лучшие настройки: {champ}\n")
        with open(os.path.join(OUT, "report.txt"), "w", encoding="utf-8") as f: f.write(rep)
        print("\n" + rep)

if __name__ == "__main__":
    main()
