# train_game_idx.py — добавляет эталоны карт из скриншотов.
# Использование: python train_game_idx.py   (список ниже можно дополнять)
import sys, types, os, glob, cv2
try:
    import mss  # noqa
except ImportError:
    sys.modules["mss"] = types.SimpleNamespace(mss=lambda: None)
import config
from engine.vision import VisionEngine

# файл скриншота -> карты слева направо в руке (ранг, масть)
LABELS = {
 "014534": "A:clubs 10:diamonds J:diamonds Q:diamonds K:diamonds A:diamonds K:spades A:spades",
 "032941": "10:clubs J:clubs K:clubs 9:hearts",
 "033049": "9:clubs 10:diamonds 9:spades J:spades K:spades",
 "033136": "9:clubs 10:hearts Q:hearts 9:spades J:spades K:spades 10:diamonds K:diamonds",
 "033551": "9:hearts 10:hearts A:hearts 9:clubs Q:clubs 9:diamonds A:diamonds A:spades",
}

def hand_boxes(v, shot):
    H, W = shot.shape[:2]
    x, y, w, h = config.scaled_zone(config.ZONE_MY_HAND, W, H)
    crop = shot[y:y+h, x:x+w]
    boxes, _ = v._find_card_boxes(crop)
    return crop, sorted(boxes)

def train(folder, only=None, outdir="assets/game_idx"):
    v = VisionEngine(); os.makedirs(outdir, exist_ok=True)
    for f in glob.glob(os.path.join(outdir, "*.png")): os.remove(f)
    n = 0
    for fn in glob.glob(os.path.join(folder, "*.png")):
        key = next((k for k in LABELS if k in fn), None)
        if not key or (only and key not in only): continue
        crop, boxes = hand_boxes(v, cv2.imread(fn))
        labs = [l.split(":") for l in LABELS[key].split()]
        if len(boxes) != len(labs):
            print("пропуск", key, len(boxes), "карт найдено, ожидалось", len(labs)); continue
        for i, ((bx, by, bw, bh), (r, s)) in enumerate(zip(boxes, labs)):
            rp, pp, _ = v._idx_patches(crop[by:by+bh, bx:bx+bw])
            cv2.imwrite(f"{outdir}/rank_{r}#{key}{i}.png", rp[4:28, 3:23])
            cv2.imwrite(f"{outdir}/suit_{s}#{key}{i}.png", pp[4:28, 3:23]); n += 1
    print("эталонов добавлено:", n)

if __name__ == "__main__":
    train(sys.argv[1] if len(sys.argv) > 1 else "screenshots")
