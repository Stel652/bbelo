# Добавляет эталоны (ранг+масть) из скриншота с известной рукой/столом. Нужен для ♠/♣ на твоём разрешении.
import sys, os, types, cv2
try:
    import mss  # noqa
except ImportError:
    sys.modules["mss"] = types.SimpleNamespace(mss=lambda: None)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from engine.vision import VisionEngine

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "game_idx")

def learn(path, cards, tag):
    """cards: [(ранг, масть, x, y, w, h)] — прямоугольники карт на скрине."""
    v = VisionEngine(); img = cv2.imread(path); n = 0
    for i, (r, s, x, y, w, h) in enumerate(cards):
        rp, pp, _ = v._idx_patches(img[y:y+h, x:x+w])
        cv2.imwrite(f"{OUT}/rank_{r}#{tag}{i}.png", rp[4:28, 3:23])
        cv2.imwrite(f"{OUT}/suit_{s}#{tag}{i}.png", pp[4:28, 3:23]); n += 1
    return n

if __name__ == "__main__":
    # скрин 000000.png (1918x1078): рука слева направо, карты шаг 120 px, ширина 105, верх y=858; стол: A♠
    hand = [("K", "diamonds"), ("9", "spades"), ("J", "spades"), ("9", "clubs"), ("J", "clubs"), ("Q", "clubs"), ("K", "clubs")]
    cards = [(r, s, 545 + 120 * i, 858, 105, 150) for i, (r, s) in enumerate(hand)]
    cards.append(("A", "spades", 984, 511, 106, 153))
    print("добавлено:", learn(sys.argv[1] if len(sys.argv) > 1 else "000000.png", cards, "scr55"))
