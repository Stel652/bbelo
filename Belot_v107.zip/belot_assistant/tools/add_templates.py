"""Добавляет эталоны карт (ранг + масть) со скриншота, чтобы бот узнавал ЛЮБЫЕ карты, в т.ч. 7 и 8.

Использование (из папки belot_assistant):
    python tools/add_templates.py скрин.png "7h 8d 10c Js"            # карты руки слева направо
    python tools/add_templates.py скрин.png "7h 8d" --dry-run         # только показать, ничего не писать

Ранги: 7 8 9 10 J Q K A.  Масти: h=♥  d=♦  c=♣  s=♠.
Скриншот — весь экран игры (как для бота). Метки пишите в порядке слева направо; если часть первой карты
закрыта кнопкой, всё равно укажите её. После добавления прогоните: python -m pytest tests (или tests/…).
"""
import argparse, hashlib, os, sys, types
import cv2
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
try:
    import mss  # noqa
except ImportError:
    sys.modules["mss"] = types.SimpleNamespace(mss=lambda: None)
import config
from engine.vision import VisionEngine

SUITS = {"h": "hearts", "d": "diamonds", "c": "clubs", "s": "spades"}
RANKS = {"7", "8", "9", "10", "J", "Q", "K", "A"}


def parse(labels):
    out = []
    for tok in labels.split():
        r, s = tok[:-1].upper().replace("T", "10"), tok[-1].lower()
        if r not in RANKS or s not in SUITS:
            raise SystemExit(f"не понял метку «{tok}» (пример: 7h, 10c, Js)")
        out.append((r, SUITS[s]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("image"); ap.add_argument("labels")
    ap.add_argument("--assets", default=os.path.join(os.path.dirname(__file__), "..", "assets", "game_idx"))
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    img = cv2.imread(a.image)
    if img is None:
        raise SystemExit("не могу открыть картинку")
    labels = parse(a.labels)
    v = VisionEngine(); v.warmup()
    H, W = img.shape[:2]
    x, y, w, h = config.scaled_zone(config.ZONE_MY_HAND, W, H)
    crop = img[y:y + h, x:x + w]
    v.detect_cards_in_image(crop, vmin=105)
    boxes = sorted(v.last_boxes)
    if len(boxes) != len(labels):
        raise SystemExit(f"на скриншоте найдено карт: {len(boxes)}, меток: {len(labels)} — проверьте порядок и рамку руки")
    os.makedirs(a.assets, exist_ok=True)
    have_r, have_s = {}, {}                      # эталоны именно из указанной папки
    for f in os.listdir(a.assets):
        t = cv2.imread(os.path.join(a.assets, f), cv2.IMREAD_GRAYSCALE)
        if t is not None and "_" in f:
            kind, nm = f[:-4].split("_", 1)
            (have_r if kind == "rank" else have_s).setdefault(nm.split("#")[0], []).append(t)
    added = 0
    for (bx, by, bw, bh), (rank, suit) in zip(boxes, labels):
        cc = crop[by:by + bh, bx:bx + bw]
        rp, pp, red = v._idx_patches(cc)
        if red != (suit in ("hearts", "diamonds")):
            # индекс закрыт (кнопка) — берём нижний правый угол
            rp, pp, red = v._idx_patches(cv2.rotate(cc, cv2.ROTATE_180))
            if red != (suit in ("hearts", "diamonds")):
                print(f"  пропуск {rank}{suit}: цвет не совпал с меткой"); continue
        for kind, patch, name in (("rank", rp, rank), ("suit", pp, suit)):
            tpl = patch[3:27, 3:23]
            have = (have_r if kind == "rank" else have_s).get(name, [])
            best = max((float(cv2.matchTemplate(patch, t, cv2.TM_CCOEFF_NORMED).max()) for t in have), default=0)
            if best > 0.985:
                print(f"  {kind} {name}: такой эталон уже есть ({best:.3f})"); continue
            fn = f"{kind}_{name}#{hashlib.md5(tpl.tobytes()).hexdigest()[:7]}.png"
            print(f"  + {fn}" + ("  (dry-run)" if a.dry_run else ""))
            if not a.dry_run:
                cv2.imwrite(os.path.join(a.assets, fn), tpl)
            added += 1
    print(f"готово: добавлено эталонов {added}")


if __name__ == "__main__":
    main()
