"""Проверка фильтров по журналу: python tools/check_filters.py [data/trace.jsonl] [data/mismatch/labels.json]
Показывает, сколько раз сработал каждый фильтр, какие карты убраны, и статус разметки промахов."""
import json, sys, collections
tp = sys.argv[1] if len(sys.argv) > 1 else "data/trace.jsonl"
lp = sys.argv[2] if len(sys.argv) > 2 else "data/mismatch/labels.json"
c, cards, frames = collections.Counter(), collections.Counter(), 0
for l in open(tp, encoding="utf8"):
    try: d = json.loads(l)
    except Exception: continue
    ev = d.get("ev"); c[ev] += 1
    if ev == "frame": frames += 1
    key = {"table_low_conf_removed": "cards", "trick_leftover_removed": "cards", "hand_twin_removed": "removed"}.get(ev)
    if key:
        for x in d.get(key, []): cards[(ev, x)] += 1
for ev in ("table_low_conf_removed", "hand_twin_removed", "trick_leftover_removed", "table_overflow", "mismatch"):
    print(f"{ev:26} {c[ev]}")
print("кадров в журнале:", frames, "(журнал прореженный, подряд кадров нет)" if frames < c["advice"] else "")
for (ev, x), n in cards.most_common(15): print(f"  {ev}: {x} x{n}")
try:
    lab = json.load(open(lp, encoding="utf8")); st = collections.Counter(v.get("status") for v in lab.values())
    print("разметка промахов:", dict(st))
except Exception as e: print("labels.json не прочитан:", e)
if not (c["table_low_conf_removed"] or c["hand_twin_removed"] or c["trick_leftover_removed"]):
    print("Фильтры в этом журнале не срабатывали: он записан до них или в партии не было ложных карт.")
