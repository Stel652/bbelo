"""Mismatch Dataset: индекс ошибок распознавания (data/mismatch/*.png) для РУЧНОЙ разметки.
Создаёт data/mismatch/labels.json; в него вручную вписывают верные карты (например ["9♣","10♣"]).
Размеченными считаются только записи со статусом "confirmed"."""
import os, re, json, sys
D = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "mismatch")

def build(d=D):
    p = os.path.join(d, "labels.json")
    cur = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
    for f in sorted(os.listdir(d)):
        m = re.match(r"(hand|table)_(\d+)_(\d+)vs(\d+)\.png$", f)
        if m and f not in cur:
            cur[f] = {"zone": m[1], "ts": int(m[2]), "seen": int(m[3]), "expected": int(m[4]),
                      "labels": None, "status": "unlabeled"}
    json.dump(cur, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return cur

def confirmed(d=D):
    p = os.path.join(d, "labels.json")
    cur = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
    return {k: v for k, v in cur.items() if v.get("status") == "confirmed" and v.get("labels")}

if __name__ == "__main__":
    c = build(); print(len(c), "записей;", len(confirmed()), "подтверждено")
