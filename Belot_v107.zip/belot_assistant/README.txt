BELOT AI ASSISTANT — strategy and performance repair build

Preserved project rules and modules:
- engine/cards.py: 32-card rank order and points
- engine/rules.py: follow-suit / trump obligations
- engine/combinations.py: Tertz, half-hundred, hundred, four-of-a-kind and Bella
- engine/scoring.py: existing score and BT calculations

Changes in this build:
- recommendations are now generated for both opening leads and tricks already in progress;
- legal follow-suit checks take priority over cutting with a trump;
- the strategy chooses a low-cost winning card when possible, otherwise sheds a low-value card;
- tracker maintains an aggregate unseen-card pool and suit counts without claiming to know hidden hands;
- screen capture reuses one MSS session, scaled templates are cached, and multiple same-rank detections are no longer collapsed to one candidate;
- overlay text wraps instead of running off-screen; analysis polling is increased to about 6 frames/second.

IMPORTANT RECOGNITION LIMITATION:
The supplied card templates use a different card artwork from the cards visible in the belot.md screenshot (the game screenshot has a red/yellow court-card design). Full-card template matching can therefore still miss cards. This build improves multi-hit handling and speed but is NOT yet validated as reliable recognition for every card in the live game. Do not rely on its recommendation until the displayed hand and table cards have been visually confirmed. The table cards are spatially ordered, not yet reliably assigned to player seats or chronological turn order, so in-progress recommendations are marked provisional.

The hidden-card tracker estimates only the aggregate unseen pool from cards actually observed. It does not fabricate exact opponent hands. Per-player probability estimates require reliable seat attribution and trick history, which are not yet implemented.

Install:
1. Run install.bat.
2. Run run_gui.bat.
3. Select the game mode and trump suit.
4. Press F2 to inspect the capture zones.

Tests:
Run `.venv\\Scripts\\python.exe -m pytest tests` (or `python -m pytest tests`).

АВТООБУЧЕНИЕ (v40): train_bot.bat -> train_selfplay.py. Самоигра 10 000+ раздач в отдельном процессе (низкий приоритет),
проверка каждого хода по правилам, опыт копится в data/selfplay/ (stats.json, params.json, rounds.jsonl, report.txt, violations.jsonl).
Козырь: classify_trump_icon теперь различает пики/трефы по форме (выпуклость + ширина), проверено на 40 вариантах размера.

=== v68 ===
* Кто выбрал козырь: имя сверху сравнивается с эталоном МОЕГО имени (assets/names/my_name_top.png). Есть JackDaniels1 -> я, другое имя -> не я.
  Читаются обе раскладки (обычная и с плашкой «14/A»). Галочка «Я объявил» дополнительно учит эталон (data/names/).
* Скриншоты в data/shots: весь экран + стол + рука + места имени + моё имя, с json (козырь, голоса, рука). Когда: новая раздача/сброс,
  выбор козыря, смена козыря, мой ход (карта ушла на стол), расхождение карт, неуверенная масть. Хранится последние 1400 файлов.
* Козырь больше не залипает после сброса раздачи; подавленные смены пишутся (trump_change_suppressed).
* ♣/♠: карта на том же месте не меняет масть из-за одного неуверенного кадра; одиночное пересечение по чёрной карте не сбрасывает раздачу сразу.
* Панель подсказки исключена из захвата экрана (Windows) и не заходит на зону руки.
* mismatch не срабатывает при доборе 5->8; ограничен бюджет времени на повторные проходы распознавания.
* trace.jsonl: события declarer, trump_change(_suppressed), reset_suppressed, played, shot, suit_override; в reset — какие карты пересеклись;
  оценки карт руки теперь пишутся (раньше их затирал стол); шум «карты не видны» не пишется; ротация .old1/.old2.


=== v69–v78: трекеры и обучение ===
engine/decision_tracker.py  — decision_id: совет -> сыгранная карта -> итог взятки (data/decisions.jsonl)
engine/validation.py        — проверка колоды/состояния (дубликаты, размеры)
engine/card_memory.py       — кто может держать неизвестные карты (достоверное/вероятное)
engine/player_tracker.py    — статистика соперников (учитывает число наблюдений)
engine/frame_voting.py      — многокадровое подтверждение карт (в main.py пока в теневом режиме)
engine/replay.py            — проверка полных записей самоигры (rounds.jsonl)
engine/decision_analysis.py — какие типы советов проигрывают взятки
database/db.py              — импорт JSONL в SQLite (data/belot.db)
paired_eval.py              — Challenger vs Champion на одинаковых раздачах; журнал experiments.jsonl
learning_center.py          — отчёт; "rollback" возвращает предыдущего чемпиона
tools/mismatch_manifest.py  — индекс 32 ошибок распознавания для ручной разметки


АВТОКЛИК (engine/autoplay.py)
Выключен по умолчанию. F4 — включить/выключить. Бот кликает по посоветованной карте только в твой ход,
только по разрешённой правилами карте и только если совет и рука не менялись ~1 сек. После 3 неудачных попыток выключается сам.
Если клик попадает мимо: config.AUTOPLAY_SCALE (масштаб Windows 1.25/1.5) и AUTOPLAY_OFFSET (смещение монитора).
В журнале: autoplay_click, autoplay_stopped. Играть за тебя без твоего контроля не рекомендуется — следи за ходами.

v89–v90: кнопка «Автоклик» в окне (F4). Торги: бот оценивает первые 5 карт и жмёт Joc/Pas (панель ZONE_BID_PANEL);
2-й круг: если зелёных кнопок несколько — читает масть на каждой и жмёт лучшую. Кнопки комбинаций слева (ZONE_COMBO) жмутся при появлении.
Зоны/слова — в config.py (ZONE_BID_PANEL, ZONE_COMBO, COMBO_WORDS). В журнале: bid_click, combo_click, autoplay_click (trace.jsonl).

v92: автоклик ждёт карты соперников (не раньше чем на столе всё определилось; AUTOPLAY_WAIT_UNSURE=3 сек, когда не уверен что мой ход);
2-й круг торгов: 3 белые кнопки мастей + Pas — выбираем лучшую масть, если играть невыгодно -> Pas, если Pas нет — обязаны выбрать лучшую;
распознавание: чёрные значки (10♠/10♣/9♠) больше не «разрезают» карту — раньше 5-я карта терялась.

v93: кнопка комбинации ищется как зелёная плашка с белым текстом (ZONE_COMBO над рукой, не залезает на карты); максимум 3 клика на одно появление.

v94: учёт заходов: если прошлую взятку взял не я — следующий ход соперника: нет советов и кликов, пока на столе нет карт (если 15 сек никто не ходит — считаем, что заход мой).
Первая взятка раздачи: автоклик при пустом столе ждёт AUTOPLAY_FIRST_WAIT=4 сек (вдруг заходит соперник).

v101: (1) комбинации: автоклик жмёт ВСЕ кнопки (Bella, Tărț, 50, 100 ... друг над другом), каждую по разу, повтор только если кнопка осталась;
      зона ZONE_COMBO расширена вниз (раньше нижняя «Bella» на 1920x1080 обрезалась); кнопка должна быть зелёной (карты с красным рисунком не срабатывают).
      (2) торги в режиме 3p: should_play(..., mode="3p") — осторожные правила (без партнёра слабый козырь = «болт»): 3 козыря без J+9, 4 мелких, «тузы вместо козырей» -> Pas.

v102: engine/robust.py — защита от ♠/♣ путаницы на столе: карта, которая уже вышла/у меня в руке, второй раз не появляется (это двойник);
      неоднозначные чёрные карты стола читаются обоими способами, совет выбирается ЗАКОННЫЙ при любом прочтении (main.py: robust_recommend).

v104: автоклик быстрее и не выключается сам: HOLD 0.6, кольцо 0.3 с, 2 одинаковых кадра; после 3 неудач — "retry" вместо остановки;
      короткая рука (не все карты видны) не блокирует клик, если ход — заход или в масть захода.

v105: перед кликом — проверка свежим кадром (номинал и цвет карты под курсором, число карт в руке), иначе "verify_failed" и клика нет;
      тайминги посередине (HOLD 0.8, кольцо 0.5, 3 кадра); при неполной руке клик только на заходе (стол пуст).

=== v107 ===
* ♠/♣: engine/suit_shape.py (+assets/suit_shape.json) — классификатор по форме значка в двух углах карты (только numpy). Включается для карт шириной >=58 px, на мелких экранах работают эталоны.
* Оракул легальных ходов: engine/playable.py. Игра затемняет карты, которые нельзя сыграть (яркая ~246, серая ~200). Совет и автоклик — только по разрешённым картам. Расхождения с rules.py -> trace.jsonl, событие legal_mismatch. Выключатель: config.SCREEN_LEGAL.
* Окно «Rezultate runda N»: пока открыто, бот ничего не читает и не кликает; mismatch не пишется (config.RESULTS_DIALOG, ZONE_RESULTS). Событие results_dialog.
* Торги: открытая карта на столе не считается сыгранной (событие bidding_table_ignored).
* Козырь новой раздачи: «свежим» становится после >=2 одинаковых чтений иконки; сразу после раздачи смена по 2 кадрам. Ручной F5–F8 — сразу актуален.
* Тесты: tests/test_real_v107.py (реальные кадры в tests/real_v107). main.py проверен только на синтаксис — проверьте вживую.
