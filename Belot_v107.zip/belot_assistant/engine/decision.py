# engine/decision.py — трёхуровневая архитектура выбора хода.
#   Уровень 1: матрица правил  — легальность + жёсткие отсечки глупых ходов (быстро, <1 мс)
#   Уровень 2: evaluation      — число для каждого допустимого хода (быстро, единицы мс)
#   Уровень 3: Monte Carlo     — только когда уровень 2 «не уверен» (сложная середина игры), до 500 раскладов
from typing import List, Tuple, Optional
from .rules import can_play_card, who_takes_trick
from .situations import situation_bonus
from .tracker import is_master

HARD_MARGIN = 4.0      # если разрыв между 1-м и 2-м ходом меньше — позиция «сложная»


# ------------------------------------------------------------------ Уровень 1
def level1_filter(hand, table, trump, ctx, trump_lead_allowed=True) -> Tuple[List, List[str]]:
    """Возвращает (допустимые ходы после отсечки, заметки). Никогда не возвращает пустой список,
    если есть хоть один легальный ход."""
    legal = [c for c in hand if can_play_card(c, table, hand, trump, trump_lead_allowed)]
    notes = []
    if len(legal) <= 1:
        return legal, notes
    pts = lambda c: c.points(trump)
    wins = lambda c: bool(table) and who_takes_trick(table + [c], trump) == len(table)
    cand = list(legal)
    # R1: партнёр берёт надёжно — не перебиваю его, если есть другой ход
    if ctx["partner_secure"]:
        keep = [c for c in cand if not wins(c)]
        if keep: cand = keep; notes.append("R1 не перебиваю партнёра")
    # R2: соперник берёт, а я не бью — не отдаю A/10/козырь, если есть дешёвая карта
    if table and not ctx["partner_winning"] and not any(wins(c) for c in cand):
        cheap = [c for c in cand if pts(c) < 10 and not c.is_trump(trump)] or [c for c in cand if pts(c) < 10]
        if cheap: cand = cheap; notes.append("R2 не дарю очки")
    # R3: бью дешёвой картой, а не дорогой, когда есть выбор (J/9 козыря берегу, пока не нужно)
    if table and not ctx["partner_winning"]:
        w = [c for c in cand if wins(c)]
        if len(w) > 1:
            cheapest = min(pts(c) + (0.01 * c.strength(trump)) for c in w)
            w2 = [c for c in w if pts(c) + 0.01 * c.strength(trump) <= cheapest + 4]
            cand = w2 + [c for c in cand if not wins(c) and pts(c) <= 3]
            notes.append("R3 бью дёшево")
    # R3b: A и 10 одной не-козырной масти оба берут взятку -> 10 не предлагаю, иду тузом
    if table and not ctx["partner_winning"]:
        for a in [c for c in cand if c.rank == "A" and not c.is_trump(trump) and wins(c)]:
            tens = [c for c in cand if c.suit == a.suit and c.rank == "10" and wins(c)]
            if tens: cand = [c for c in cand if c not in tens]; notes.append("R3b беру тузом, 10 берегу")
    # R4: голый J/9 козыря не выбрасываю в пустую (кроме последней карты)
    if len(hand) > 1:
        safe = [c for c in cand if not (c.is_trump(trump) and c.rank in ("J", "9") and not wins(c))]
        if safe: cand = safe
    return (cand or legal), notes


# ------------------------------------------------------------------ Уровень 2
def level2_eval(card, ctx) -> float:
    h, table, trump, snap = ctx["hand"], ctx["table"], ctx["trump"], ctx.get("snap")
    pts = card.points(trump)
    isT = card.is_trump(trump)
    table_pts = sum(c.points(trump) for c in table)
    wins = bool(table) and who_takes_trick(table + [card], trump) == len(table)
    phase = "open" if len(h) >= 7 else ("mid" if len(h) >= 4 else "end")
    last = ctx["last_to_play"]
    master = bool(snap) and is_master(card, snap, trump)
    score = 0.0
    # 1) очки, которые, вероятно, возьму / потеряю
    if table:
        if wins:
            p_hold = 1.0 if (last or master) else 0.62
            score += p_hold * (table_pts + pts) - pts * (1 - p_hold) * 0.5
            if len(h) == 1: score += 10                         # последняя взятка +10
        elif ctx["partner_winning"]:
            score += pts if ctx["partner_secure"] else 0.4 * pts   # отдаю очки партнёру
        else:
            score -= pts                                         # отдал очки сопернику
    else:
        # заход: верная взятка (мастер) ценнее, голая 10 / козырь без нужды — хуже
        score += (pts + 6) if master else -0.3 * pts
    # 2) контроль козырей
    if snap:
        unseen_tr = [u for u in snap["unseen"] if u.suit == trump]
        my_tr = [c for c in h if c.suit == trump]
        higher_out = sum(1 for u in unseen_tr if isT and u.strength(trump) > card.strength(trump))
        if isT and not table:
            if ctx["declared"] and unseen_tr and len(my_tr) >= 3:
                score += 4 + (2 if not higher_out else 0)         # тяну козыри, пока они у соперников
            elif unseen_tr and not ctx["declared"]:
                score -= 3
        if isT and card.rank in ("J", "9") and phase != "end" and not wins:
            score -= 4                                           # старшие козыри берегу
    # 3) позиция: играющий — козыри; не играющий — боковые A/10
    if ctx["declared"] and isT and not table: score += 1.5
    if not ctx["declared"] and not isT and not table and card.rank in ("A", "10"): score += 1.5
    # 4) риск BT / счёт
    if ctx["risk"] == "risky" and wins: score += 0.15 * (table_pts + pts) + 1
    if ctx["risk"] == "safe" and isT and card.rank in ("J", "9") and not wins: score -= 2
    # 5) фаза игры
    if phase == "end" and wins: score += 2
    if phase == "open" and isT and not ctx["declared"]: score -= 2
    return score


# ------------------------------------------------------------------ Уровень 3
def level3_mc(hand, table, trump, snap, mode, cands, budget=0.35, max_samples=500):
    from .mc import mc_scores
    return mc_scores(hand, table, trump, snap, mode, cands, budget, max_samples)


# ------------------------------------------------------------------ Конвейер
def decide(hand, table, trump, mode, ctx, trump_lead_allowed=True, prior=None,
           use_mc=False, budget=0.35, max_samples=500):
    """Возвращает (карта, заметка, was_hard). prior — подсказка прежней эвристики (небольшой бонус)."""
    cand, notes = level1_filter(hand, table, trump, ctx, trump_lead_allowed)
    if not cand:
        return None, "", False
    if len(cand) == 1:
        return cand[0], "единственный ход", False
    total = {}
    for c in cand:
        b, _ = situation_bonus(c, ctx)               # правила из руководства (матрица 3p и др.)
        total[c] = level2_eval(c, ctx) + b + (2.0 if c == prior else 0.0)
    ranked = sorted(cand, key=total.get, reverse=True)
    margin = total[ranked[0]] - total[ranked[1]]
    hard = margin < HARD_MARGIN and 3 <= len(hand) <= 7 and ctx.get("snap") is not None
    best = ranked[0]
    if hard and use_mc:
        top = ranked[:3]
        res = level3_mc(hand, table, trump, ctx["snap"], mode, top, budget, max_samples)
        if res:
            scores, k = res
            mc_total = {c: scores[c] + 0.5 * total[c] for c in top}
            best = max(mc_total, key=mc_total.get)
            return best, f"L3 Monte Carlo {k} раскладов: {scores[best]:+.0f}", True
    return best, ("L1+L2 " + ", ".join(notes)).strip(), hard
