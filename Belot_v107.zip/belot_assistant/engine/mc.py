# engine/mc.py — выбор хода "расчётом": случайно раздаём неизвестные карты и доигрываем раунд.
import random, time
from .rules import can_play_card, who_takes_trick

def _legal(hand, table, trump):
    return [c for c in hand if can_play_card(c, table, hand, trump, True)]

def _policy(hand, table, trump, ally_winning):
    legal = _legal(hand, table, trump)
    if len(legal) == 1:
        return legal[0]
    if not table:
        aces = [c for c in legal if c.rank == "A" and c.suit != trump]
        if aces: return aces[0]
        side = [c for c in legal if c.suit != trump]
        pool = side or legal
        return min(pool, key=lambda c: (c.points(trump), c.strength(trump)))
    if ally_winning:
        return max(legal, key=lambda c: (c.suit != trump, c.points(trump), -c.strength(trump)))
    win = [c for c in legal if who_takes_trick(table + [c], trump) == len(table)]
    if win:
        return min(win, key=lambda c: (c.points(trump), c.strength(trump)))
    return min(legal, key=lambda c: (c.points(trump), c.strength(trump)))

def _rollout(hands, table, n, first, trump, P, allies):
    """hands: rel -> список; table: уже лежащие карты (n шт.); first — моя карта (индекс n). Возвращает очки (мои - чужие)."""
    cards = list(table) + [first]
    diff = 0
    idx = n + 1
    rels_order = None
    leader_idx = 0
    while True:
        while len(cards) < P:
            rel = (len(cards) - n) % P
            h = hands[rel]
            winner_idx = who_takes_trick(cards, trump)
            ally = ((winner_idx - n) % P) in allies and rel in allies
            c = _policy(h, cards, trump, ally)
            h.remove(c); cards.append(c)
        w = (who_takes_trick(cards, trump) - n) % P        # rel победителя
        pts = sum(c.points(trump) for c in cards)
        if not hands[0] or all(not h for h in hands.values()):
            pts += 10
        diff += pts if w in allies else -pts
        if all(not h for h in hands.values()):
            return diff
        # следующая взятка: начинает победитель; пересчитываем n так, чтобы rel = (index - n) % P
        n = (-w) % P
        cards = []
        # первый игрок взятки
        rel = w
        c = _policy(hands[rel], cards, trump, False)
        hands[rel].remove(c); cards.append(c)

def mc_scores(hand, table, trump, snap, mode, valid, budget=0.25, max_samples=80, seed=None):
    """Средняя разница очков (мои - чужие) для каждой допустимой карты, либо None если данных мало."""
    P = {"1v1": 2, "3p": 3, "2v2": 4}[mode]
    n = len(table)
    unseen = [c for c in snap["unseen"] if c not in table]
    sizes = {}
    for rel in range(1, P):
        played = rel >= P - n
        sizes[rel] = len(hand) - 1 if played else len(hand)
    if sum(sizes.values()) > len(unseen) or len(valid) < 1:
        return None
    allies = {0, 2} if mode == "2v2" else {0}
    rng = random.Random(seed)
    t0 = time.time()
    totals = {c: 0.0 for c in valid}
    k = 0
    while k < max_samples and (k < 8 or time.time() - t0 < budget):
        pool = unseen[:]; rng.shuffle(pool)
        base, pos = {}, 0
        for rel in range(1, P):
            base[rel] = pool[pos:pos + sizes[rel]]; pos += sizes[rel]
        for c in valid:
            hands = {0: [x for x in hand if x != c]}
            for rel in range(1, P): hands[rel] = list(base[rel])
            totals[c] += _rollout(hands, table, n, c, trump, P, allies)
        k += 1
    return {c: totals[c] / k for c in valid}, k
