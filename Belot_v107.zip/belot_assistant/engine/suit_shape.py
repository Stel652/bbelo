# engine/suit_shape.py
"""Отдельный классификатор ♠ / ♣ по ФОРМЕ значка (углы карты).
Эталоны мастей у пик и треф почти не различаются (NCC ~0.98 против 0.98), особенно на придворных картах и
на уменьшенных экранах. Здесь значок нормализуется (обрезка по тёмному пятну, масштаб 16x16) и разбирается
линейной моделью, веса которой лежат в assets/suit_shape.json (sklearn на ПК не нужен, только numpy).

score(patch) > 0  -> пики, < 0 -> трефы. None, если значка не нашли.
"""
import json, os
import cv2
import numpy as np

_N = 16
_W = None


def _load():
    global _W
    if _W is None:
        p = os.path.join(os.path.dirname(__file__), "..", "assets", "suit_shape.json")
        try:
            with open(p, "r", encoding="utf-8") as f:
                d = json.load(f)
            _W = (np.array(d["w"], np.float32), float(d["b"]), np.array(d["mu"], np.float32), np.array(d["sd"], np.float32))
        except Exception:
            _W = False
    return _W


def features(g):
    """g: серый патч значка, чернила яркие (255 - min(B,G,R)). Возвращает вектор или None."""
    if g is None or g.size == 0 or min(g.shape[:2]) < 5:
        return None
    g = g.astype(np.uint8)
    up = cv2.resize(g, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC)
    up = cv2.GaussianBlur(up, (0, 0), 1.2)
    t, m = cv2.threshold(up, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    if t < 40:                      # пустой патч
        return None
    n, lab, st, _ = cv2.connectedComponentsWithStats((m > 0).astype(np.uint8), 8)
    H, W = m.shape
    best, bscore = None, 0
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if a < 0.04 * H * W:
            continue
        touch = (x <= 0) + (y <= 0) + (x + w >= W) + (y + h >= H)
        sc = a / (1 + 2 * touch)        # компонент, упирающийся в край патча, — это кусок ранга, а не значок
        if sc > bscore:
            best, bscore = i, sc
    if best is None:
        return None
    mm = (lab == best).astype(np.uint8)
    x, y, w, h, a = st[best]
    if w < 8 or h < 8:
        return None
    box = mm[y:y + h, x:x + w]
    cs, _ = cv2.findContours(box, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    c = max(cs, key=cv2.contourArea)
    hull = cv2.contourArea(cv2.convexHull(c))
    sol = cv2.contourArea(c) / max(1.0, hull)
    small = cv2.resize(box.astype(np.float32), (_N, _N), interpolation=cv2.INTER_AREA)
    rows = small.sum(axis=1) / _N                           # профиль ширины по высоте
    cols = small.sum(axis=0) / _N
    ar = w / float(h)
    return np.concatenate([small.ravel(), rows, cols, [sol, ar]]).astype(np.float32)


def score(g):
    W = _load()
    if not W:
        return None
    f = features(g)
    if f is None:
        return None
    w, b, mu, sd = W
    return float(np.dot((f - mu) / sd, w) + b)


def score_card(card_img):
    """Значок по двум углам карты (левый верх и, повернув на 180°, правый низ). Возвращает среднюю оценку или None."""
    if card_img is None or card_img.size == 0:
        return None
    out = []
    for rot in (False, True):
        c = cv2.rotate(card_img, cv2.ROTATE_180) if rot else card_img
        c = cv2.resize(c, (70, 98), interpolation=cv2.INTER_AREA)
        g = 255 - c.min(axis=2)
        s = score(g[14:30, 0:13])
        if s is not None:
            out.append(s)
    return float(np.mean(out)) if out else None
