# engine/hand_eval.py — оценка руки для решения «Joc / Pas»
from .combinations import detect_combinations, total_points

def evaluate_hand(hand, trump):
    """Возвращает (очки 0..100, список пояснений)."""
    score, notes = 0, []
    trumps = [c for c in hand if c.is_trump(trump)]
    n = len(trumps)
    if n >= 5:   score += 40; notes.append(f"{n} козырей (очень сильно)")
    elif n == 4: score += 30; notes.append(f"{n} козыря (хорошо)")
    elif n == 3: score += 15; notes.append(f"{n} козыря (приемлемо)")
    else:        notes.append(f"только {n} козырей (слабо)")
    for c in trumps:
        if c.rank == "J":   score += 25; notes.append("J козыря — полный контроль")
        elif c.rank == "9": score += 15; notes.append("9 козыря")
    pts = sum(c.points(trump) for c in hand)
    if pts >= 60:   score += 20; notes.append(f"{pts} очков (отлично)")
    elif pts >= 40: score += 10; notes.append(f"{pts} очков (хорошо)")
    combs = detect_combinations(hand, trump)
    cp = total_points(combs, trump)
    if cp:
        score += min(cp // 5, 25); notes.append(f"комбинации {cp} очков")
    return min(score, 100), notes
