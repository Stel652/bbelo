# engine/combinations.py
from typing import List, Tuple
from .cards import Card, NORMAL_ORDER

# Приоритет комбинаций (чем больше число, тем старше)
COMB_PRIORITY = {
    "four_J": 100, "four_9": 90, "four_A": 80, "four_10": 70, "four_K": 60, "four_Q": 50,
    "hundred": 40,       # O sută (5+ подряд)
    "half_hundred": 30,  # Jumate de sută (4 подряд)
    "tertz": 20,         # Tărț (3 подряд)
    "bella": 10,         # Bella (Q+K козырь) — считается всегда
}
SQUARE_POINTS = {"J": 200, "9": 150, "A": 100, "10": 100, "K": 100, "Q": 100}

def _runs(ranks):
    """Все серии подряд (по порядку 7..A) длиной >= 3 в одной масти."""
    idx = sorted(NORMAL_ORDER.index(r) for r in ranks)
    runs, cur = [], []
    for i in idx:
        if cur and i == cur[-1] + 1:
            cur.append(i)
        else:
            if len(cur) >= 3: runs.append(cur)
            cur = [i]
    if len(cur) >= 3: runs.append(cur)
    return runs

def detect_combinations(hand: List[Card], trump: str, mode: str = "2v2") -> List[Tuple[str, int, Card]]:
    """Список (тип, очки, старшая карта).

    Особые комбинации (только стол на 4): 'belot' (8 козырей — мгновенная победа),
    'four_8' (аннулирует комбинации всех, кроме Bella), 'four_7' (раздача отменяется).
    """
    result = []
    if any(c.suit == trump and c.rank == "Q" for c in hand) and \
       any(c.suit == trump and c.rank == "K" for c in hand):
        result.append(("bella", 20, Card(trump, "K")))

    for rank in ["J", "9", "A", "10", "K", "Q"]:
        cards = [c for c in hand if c.rank == rank]
        if len(cards) == 4:
            result.append((f"four_{rank}", SQUARE_POINTS[rank], cards[0]))

    if mode == "2v2":
        for rank, name in (("8", "four_8"), ("7", "four_7")):
            cards = [c for c in hand if c.rank == rank]
            if len(cards) == 4:
                result.append((name, 0, cards[0]))
        if sum(1 for c in hand if c.suit == trump) == 8:
            result.append(("belot", 0, Card(trump, "A")))

    # Серии: в одной масти может быть две серии (например 7-8-9 и J-Q-K).
    for suit in ["hearts", "diamonds", "clubs", "spades"]:
        ranks = [c.rank for c in hand if c.suit == suit]
        for run in _runs(ranks):
            top = Card(suit, NORMAL_ORDER[run[-1]])
            n = len(run)
            if n >= 5:   result.append(("hundred", 100, top))
            elif n == 4: result.append(("half_hundred", 50, top))
            else:        result.append(("tertz", 20, top))
    return result

def _key(item, trump):
    name, pts, top = item
    # Среди серий равной длины решает старшая карта в порядке 7..A, затем козырь.
    return (COMB_PRIORITY.get(name, 0), NORMAL_ORDER.index(top.rank), top.suit == trump)

def best_combination(combs: List[Tuple[str, int, Card]], trump: str) -> Tuple[str, int, Card]:
    """Старшая комбинация по правилам приоритета (специальные belot/four_8/four_7 не участвуют)."""
    combs = [c for c in combs if c[0] in COMB_PRIORITY]
    if not combs:
        return ("", 0, None)
    return max(combs, key=lambda it: _key(it, trump))

def total_points(combs: List[Tuple[str, int, Card]], trump: str) -> int:
    """Очки комбинаций руки, которые можно объявить: у игрока может быть несколько комбинаций сразу
    (правила: «combinații cu prioritate pot fi mai multe, atât la un jucător...»). Bella считается всегда.
    Реально засчитаются они, только если не уступают комбинациям стола (сравнение со столом здесь не делается)."""
    return sum(p for n, p, _ in combs if n in COMB_PRIORITY)
