"""Защита от ошибок распознавания масти на столе (♠/♣ путаются чаще всего).

Идея: каждую карту стола читаем возможными способами —
  * карта, которая уже вышла/лежит у меня в руке, второй раз быть не может -> это «двойник» (♠<->♣, ♥<->♦);
  * чёрную карту стола, у которой двойник возможен, считаем неоднозначной (♠ или ♣).
Совет выбираем так, чтобы он был ЗАКОННЫМ при любом возможном прочтении стола: тогда даже если масть прочитана неверно,
ход не нарушит правил (не «срежем» там, где надо идти в масть, и не пойдём в масть там, где её нет)."""
from itertools import product
from .cards import Card
from .rules import can_play_card

TWIN = {"spades": "clubs", "clubs": "spades", "hearts": "diamonds", "diamonds": "hearts"}
BLACK = ("spades", "clubs")


def table_readings(table, banned, hand, max_readings=8):
    """-> список вариантов стола (первый — основной). banned: карты, которых на столе быть не может (уже вышли)."""
    banned, hand_set = set(banned), set(hand)
    options = []
    for c in table:
        t = Card(TWIN[c.suit], c.rank)
        impossible = c in banned or c in hand_set
        t_ok = t not in banned and t not in hand_set
        if impossible and t_ok:
            options.append([t])                       # дубликат -> это точно двойник
        elif c.suit in BLACK and t_ok and not impossible:
            options.append([c, t])                    # ♠/♣ — неоднозначно
        else:
            options.append([c])
    out, seen = [], set()
    for combo in product(*options):
        if len(set(combo)) != len(combo):              # две одинаковые карты на столе — нельзя
            continue
        key = tuple(combo)
        if key not in seen:
            seen.add(key); out.append(list(combo))
        if len(out) >= max_readings:
            break
    return out or [list(table)]


def robust_recommend(rec, hand, table, trump, banned, trump_lead_allowed=True):
    """rec(hand, table) -> (move, why). Возвращает (move, why) — ход, законный при всех прочтениях стола."""
    readings = table_readings(table, banned, hand)
    if len(readings) == 1:
        t0 = readings[0]
        mv, why = rec(hand, t0)
        return mv, why
    legal_sets = []
    for t in readings:
        legal_sets.append({c for c in hand if can_play_card(c, t, hand, trump, trump_lead_allowed)})
    common = set.intersection(*legal_sets) if legal_sets else set()
    first_move, first_why = rec(hand, readings[0])
    if first_move is not None and (not common or first_move in common):
        return first_move, first_why
    for t in readings[1:]:
        mv, why = rec(hand, t)
        if mv is not None and mv in common:
            return mv, why + " (масть на столе неоднозначна — ход законен при любом прочтении)"
    if not common:                                      # прочтения несовместимы — идём по основному
        return first_move, first_why
    # ни один совет не подходит под все прочтения -> самая дешёвая карта из общих законных
    cheap = min(common, key=lambda c: (c.points(trump), c.strength(trump)))
    return cheap, "масть карт на столе неоднозначна — самый безопасный законный ход"
