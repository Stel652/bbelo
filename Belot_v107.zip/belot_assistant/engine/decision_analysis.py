"""Анализ data/decisions.jsonl: какие типы советов чаще проигрывают взятку."""
import json, os
from collections import defaultdict

def load(path):
    if not os.path.exists(path):
        return []
    out = []
    with open(path, encoding="utf-8") as f:
        for l in f:
            try: out.append(json.loads(l))
            except Exception: pass
    return out

def key(why):
    return (why or "?").split(" · ")[0].split(" (")[0].strip()[:60] or "?"

def analyse(events, min_n=5):
    dec, played, outc = {}, {}, {}
    for e in events:
        did = e.get("decision_id")
        if e.get("ev") == "decision": dec[did] = e
        elif e.get("ev") == "played": played[did] = e
        elif e.get("ev") == "outcome": outc[did] = e
    rows = defaultdict(lambda: {"n": 0, "followed": 0, "won": 0, "done": 0, "points": 0})
    for did, d in dec.items():
        r = rows[key(d.get("why"))]; r["n"] += 1
        if played.get(did, {}).get("followed"): r["followed"] += 1
        o = outc.get(did)
        if o: r["done"] += 1; r["won"] += bool(o["trick_won"]); r["points"] += o["trick_points"] if o["trick_won"] else 0
    res = []
    for k, r in rows.items():
        wr = r["won"] / r["done"] if r["done"] else None
        res.append(dict(reason=k, **r, win_rate=None if wr is None else round(wr, 3), reliable=r["done"] >= min_n))
    res.sort(key=lambda x: (x["win_rate"] is None, x["win_rate"] if x["win_rate"] is not None else 0))
    return res

if __name__ == "__main__":
    p = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "decisions.jsonl")
    for r in analyse(load(p)): print(r)
