# engine/scoring.py — подсчёт по правилам "Cum se calculează bilele în joc"
from typing import Dict, List

ROUND_POINTS = 162        # 152 в картах + 10 за последнюю взятку (без комбинаций)

def points_to_bile(points: int) -> int:
    """10 очков = 1 била, половина округляется ВНИЗ: 64 и 65 -> 6, 66 -> 7, 75 -> 7, 76 -> 8.
    (round() в Python округляет 7.5 вверх до 8, поэтому он не подходит)"""
    if points <= 0:
        return 0
    return (points + 4) // 10

def calculate_round_1v1(player_points: int, opponent_points: int, player_played: bool) -> Dict:
    """1 vs 1: пишутся ТОЧНЫЕ очки. BT — только если играющий набрал строго меньше; при равенстве BT нет."""
    result = {"player": player_points, "opponent": opponent_points, "bt": False, "notes": []}
    if player_played and player_points < opponent_points:
        result["bt"] = True
        result["opponent"] = player_points + opponent_points
        result["player"] = 0
        result["notes"].append("BT: играющий набрал меньше")
    elif player_points == opponent_points:
        result["notes"].append("Равенство очков — без BT")
    return result

def calculate_round_pair(team1_points: int, team2_points: int, playing_team: int) -> Dict:
    """2 vs 2: сравниваются суммы пар. Равенство — без BT, били делятся поровну."""
    total = team1_points + team2_points
    result = {"team1": 0, "team2": 0, "bt": False, "notes": []}
    if team1_points == team2_points:
        half = points_to_bile(team1_points)
        result["team1"] = result["team2"] = half
        result["notes"].append("Равенство очков — без BT, били поровну")
        return result
    playing, other = (team1_points, team2_points) if playing_team == 1 else (team2_points, team1_points)
    if playing < other:
        # BT: все очки раунда забирают соперники (в билях, а не в очках)
        result["bt"] = True
        winner = "team2" if playing_team == 1 else "team1"
        result[winner] = points_to_bile(total)
        result["notes"].append("BT: все очки раунда у соперников")
    else:
        result["team1"] = points_to_bile(team1_points)
        result["team2"] = points_to_bile(team2_points)
    return result

def calculate_round_3p(points: Dict[int, int], playing_player: int) -> Dict:
    """3 игрока. Били двух НЕ игравших считаются по очкам с округлением; били играющего =
    общее число билей раунда минус сумма двух. Общее число = били всех очков раунда
    (пример из правил: 64+53+65 = 182 -> 18 билей; 18-(6+5) = 7 билей играющему, BT нет).
    Если по билям играющий равен лучшему сопернику — сравниваем очки; и по очкам равно -> 'egal', без BT.
    """
    others = [i for i in range(3) if i != playing_player]
    total_bile = points_to_bile(sum(points.values()))
    others_bile = {i: points_to_bile(points[i]) for i in others}
    playing_bile = max(0, total_bile - sum(others_bile.values()))

    result = {"bt": False, "notes": [], "equal": False}
    best_other = max(others, key=lambda i: (others_bile[i], points[i]))
    if playing_bile < others_bile[best_other]:
        result["bt"] = True
        result["notes"].append("BT: у играющего меньше билей")
    elif playing_bile == others_bile[best_other]:
        if points[playing_player] < points[best_other]:
            result["bt"] = True
            result["notes"].append("Били равны, по очкам меньше — BT")
        elif points[playing_player] == points[best_other]:
            result["equal"] = True
            result["notes"].append("Равно и по билям, и по очкам — пишется egal")
        else:
            result["notes"].append("Били равны, но по очкам больше — без BT")

    if result["bt"]:
        # Играющий не получает билей; соперники сохраняют свои. (Как делится его доля — в правилах не описано.)
        result[playing_player] = 0
    else:
        result[playing_player] = playing_bile
    for i in others:
        result[i] = others_bile[i]
    return result

def calculate_minuses(took_any_trick: bool, bt_count: int, mode: str) -> int:
    """-10 билей (1v1: -100 очков) за раунд без единой взятки (для 2v2 — у обеих игроков пары);
    -10 за каждый третий BT (3-й, 6-й, ...)."""
    unit = 100 if mode == "1v1" else 10
    minus = 0
    if not took_any_trick:
        minus += unit
    if bt_count > 0 and bt_count % 3 == 0:
        minus += unit
    return minus

def game_limit(mode: str, three_player_limit: int = 101) -> int:
    return 1010 if mode == "1v1" else (three_player_limit if mode == "3p" else 101)

def check_game_end(scores: List[int], limit: int, mode: str, tournament: bool = False):
    """Возвращает (победитель | None, новый_лимит). Если за один раунд лимит перешли несколько
    участников — лимит растёт на 50 (1v1: на 500), кроме чемпионатов / войн кланов / лиги."""
    over = [i for i, s in enumerate(scores) if s >= limit]
    if not over:
        return None, limit
    if len(over) > 1 and not tournament:
        return None, limit + (500 if mode == "1v1" else 50)
    return max(over, key=lambda i: scores[i]), limit

class ReducedCombos:
    """Опция 'R' (1 vs 1): комбинации >= 100 очков можно показать максимум 2 раза за игру.
    - без взятки у игрока комбинация не считается;
    - если в раунде ДВЕ комбинации >= 100 (двойная): считаются обе, после чего больше нельзя;
      (если уже была одна — сервер считает и её, и обе новые, потому что двойную нельзя разделить)
    """
    def __init__(self):
        self.shown = {}

    def apply(self, player: int, big_combos: List[int], took_trick: bool) -> List[int]:
        """big_combos — очки комбинаций >= 100 игрока в этом раунде. Возвращает те, что засчитаны."""
        if not big_combos or not took_trick:
            return []
        used = self.shown.get(player, 0)
        if len(big_combos) >= 2:
            if used >= 2:
                return []
            self.shown[player] = 2
            return list(big_combos)
        if used >= 2:
            return []
        self.shown[player] = used + 1
        return list(big_combos)
