# engine/bile.py — били в реальном времени + BT-счётчик (с правильным округлением)
from .scoring import points_to_bile, ROUND_POINTS

class BileTracker:
    def __init__(self, mode):
        self.mode = mode
        self.my_points = 0
        self.opp_points = 0
        self.bt_count = 0          # мои BT в этой игре

    def add_trick(self, points, mine):
        if mine: self.my_points += points
        else:    self.opp_points += points

    def my_bile(self):  return points_to_bile(self.my_points)
    def opp_bile(self): return points_to_bile(self.opp_points)
    def diff(self):     return self.my_bile() - self.opp_bile()

    def estimate_remaining(self):
        """Очков ещё в раунде (из 162 без комбинаций)."""
        return max(0, ROUND_POINTS - self.my_points - self.opp_points)

    def register_bt(self):
        """Вызвать, когда у меня BT. Возвращает предупреждение."""
        self.bt_count += 1
        if self.bt_count % 3 == 0:
            return "BT №%d — минус 10 бил!" % self.bt_count
        if self.bt_count % 3 == 2:
            return "Это уже %d-й BT. Следующий — минус 10 бил." % self.bt_count
        return ""

def risk_advice(behind_bile):
    """Тактика по счёту: впереди — играть осторожно, сильно позади — рисковать."""
    if behind_bile >= 5:  return "позади на %d — рискуй, тяни козырь" % behind_bile
    if behind_bile <= -5: return "впереди на %d — играй осторожно" % -behind_bile
    return ""
