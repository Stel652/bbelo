"""Card Memory: кто из соперников МОЖЕТ держать каждую неизвестную карту.
Разделяет достоверное (карта вышла / лежит у меня / только один возможный владелец)
и вероятное (равномерное распределение среди возможных владельцев).
Пустые масти берутся из CardTracker.voids (1=слева, 2=партнёр, 3=справа)."""
from collections import defaultdict


class CardMemory:
    def __init__(self, tracker):
        self.t = tracker

    def analyse(self, hand, table=()):
        snap = self.t.snapshot(hand, table)
        unseen = snap["unseen"]
        voids = self.t.voids
        possible = {}                    # карта -> набор возможных владельцев (1,2,3)
        for c in unseen:
            possible[c] = {p for p in (1, 2, 3) if c.suit not in voids.get(p, ())}
        certain = {c: next(iter(o)) for c, o in possible.items() if len(o) == 1}
        impossible = [c for c, o in possible.items() if not o]   # противоречие: ошибка данных/распознавания
        prob = {}                        # (карта, игрок) -> вероятность, только по возможным владельцам
        for c, o in possible.items():
            for p in o:
                prob[(c, p)] = 1.0 / len(o)
        return {"unseen": unseen, "possible": possible, "certain": certain,
                "contradictions": impossible, "prob": prob}

    def holders_of_suit(self, suit, hand, table=()):
        """Карты масти, которых нет ни у меня, ни на столе, ни сыграно, -> возможные владельцы."""
        a = self.analyse(hand, table)
        return {c: sorted(o) for c, o in a["possible"].items() if c.suit == suit}

    def expected_cards(self, hand, table=()):
        """Ожидаемое число неизвестных карт у каждого игрока (для разбивки по рукам)."""
        a = self.analyse(hand, table)
        exp = defaultdict(float)
        for (c, p), pr in a["prob"].items():
            exp[p] += pr
        return {p: round(v, 2) for p, v in exp.items()}
