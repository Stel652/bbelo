# engine/cards.py
from dataclasses import dataclass
from typing import List

SUITS = ["hearts", "diamonds", "clubs", "spades"]
SUIT_SYMBOL = {"hearts": "♥", "diamonds": "♦", "clubs": "♣", "spades": "♠"}

# Порядок "подряд" (для комбинаций Tărț / 50 / 100): 7,8,9,10,J,Q,K,A
NORMAL_ORDER = ["7", "8", "9", "10", "J", "Q", "K", "A"]
# СИЛА карт не-козыря (от младшей к старшей): A > 10 > K > Q > J > 9 > 8 > 7
# (раньше сила считалась по NORMAL_ORDER, и 10 ошибочно бил только J, Q, K -> была ниже K)
NORMAL_STRENGTH = ["7", "8", "9", "J", "Q", "K", "10", "A"]
RANKS_BY_DECK = {
    32: ["7", "8", "9", "10", "J", "Q", "K", "A"],   # стол на 4
    24: ["9", "10", "J", "Q", "K", "A"],             # 1 vs 1 и стол на 3
}
# Порядок для КОЗЫРЯ (J - старший, 9 - второй)
TRUMP_ORDER = ["7", "8", "Q", "K", "10", "A", "9", "J"]

# Очки
POINTS_TRUMP = {"J": 20, "9": 14, "A": 11, "10": 10, "K": 4, "Q": 3, "8": 0, "7": 0}
POINTS_NORMAL = {"A": 11, "10": 10, "K": 4, "Q": 3, "J": 2, "9": 0, "8": 0, "7": 0}

@dataclass(frozen=True)
class Card:
    suit: str
    rank: str

    def is_trump(self, trump: str) -> bool:
        return self.suit == trump

    def points(self, trump: str) -> int:
        return (POINTS_TRUMP if self.is_trump(trump) else POINTS_NORMAL)[self.rank]

    def strength(self, trump: str) -> int:
        if self.is_trump(trump):
            return 100 + TRUMP_ORDER.index(self.rank)
        return NORMAL_STRENGTH.index(self.rank)

    def __str__(self):
        return f"{self.rank}{SUIT_SYMBOL[self.suit]}"