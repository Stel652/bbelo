"""Player Tracker: статистика по местам (1=слева, 2=партнёр, 3=справа).
Профиль учитывает число наблюдений и не делает выводов по малой выборке."""
from collections import defaultdict
from .rules import who_takes_trick

class PlayerTracker:
    MIN_OBS = 20
    def __init__(self):
        self.s = defaultdict(lambda: defaultdict(int))

    def observe_trick(self, table, my_card, trump):
        """Полная взятка (порядок хода) + моя карта -> статистика соперников."""
        if my_card not in table or len(table) < 3: return
        n, j, lead = len(table), table.index(my_card), table[0].suit
        win = who_takes_trick(table, trump)
        for i, c in enumerate(table):
            rel = (i - j) % n
            if rel == 0: continue
            st = self.s[rel]
            st["cards"] += 1
            if i > 0 and c.suit != lead:
                st["no_follow"] += 1
                if c.suit == trump: st["trumped"] += 1
                else: st["discarded"] += 1
                if c.suit != trump: st["discard_points"] += c.points(trump)
            if i == win: st["won_tricks"] += 1

    def profile(self, rel):
        st, n = self.s[rel], self.s[rel]["cards"]
        def rate(k): return round(st[k] / n, 3) if n else None
        return {"observations": n, "reliable": n >= self.MIN_OBS, "no_follow_rate": rate("no_follow"),
                "trump_rate": rate("trumped"), "discard_rate": rate("discarded"), "win_rate": rate("won_tricks")}
