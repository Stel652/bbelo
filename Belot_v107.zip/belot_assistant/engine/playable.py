# engine/playable.py
"""Оракул легальных ходов по экрану: игра сама затемняет карты, которые сейчас нельзя сыграть.
Яркая карта: бумага ~246, затемнённая ~197-201 (замер на кадрах f669/f927). Порог 225.

levels_from_image(vision, hand_img)  -> [(cx, level)] по каждой карте руки в кадре
attach(hand_hits, levels)            -> {Card: level}
PlayableOracle.update(...)           -> frozenset разрешённых карт, когда сигнал подтверждён двумя одинаковыми кадрами;
                                        None — сигнала нет (все карты яркие, всё затемнено — окно/оверлей, или кадр не подтверждён)
"""
import cv2
import numpy as np

DIM_THR = 225        # ниже — карта затемнена (нельзя играть)
MIN_BRIGHT = 235     # хотя бы одна карта должна быть по-настоящему яркой, иначе это затемнение всего экрана (диалог)


def levels_from_image(vision, img):
    """Уровень «бумаги» каждой карты в зоне руки: 90-й процентиль min(B,G,R) в нижней-средней части карты."""
    if img is None or img.size == 0:
        return []
    try:
        boxes, _wide = vision._find_card_boxes(img, 90)
    except Exception:
        return []
    out = []
    for x, y, w, h in boxes:
        c = img[y:y + h, x:x + w]
        if c.size == 0:
            continue
        reg = c[int(h * .45):int(h * .9), int(w * .15):int(w * .85)]
        if reg.size == 0:
            continue
        out.append((x + w // 2, int(np.percentile(reg.min(axis=2), 90)), w))
    return out


def attach(hand_hits, levels):
    """Сопоставляет распознанные карты (card, (cx, cy)) и уровни яркости по близости центра. Нет пары -> карты нет в словаре."""
    res = {}
    for card, p in hand_hits:
        best, bd = None, 1e9
        for cx, lv, w in levels:
            d = abs(cx - p[0])
            if d < bd:
                best, bd = lv, d
                bw = w
        if best is not None and bd <= 0.45 * bw:
            res[card] = best
    return res


def read(vision, img, hand_hits):
    """(уровни распознанных карт, число карт на экране без распознанной пары)."""
    levels = levels_from_image(vision, img)
    lv = attach(hand_hits, levels)
    return lv, max(0, len(levels) - len(lv))


def screen_legal(card_levels):
    """Разрешённые карты по яркости или None, если сигнала нет."""
    if len(card_levels) < 2:
        return None
    lv = card_levels
    if max(lv.values()) < MIN_BRIGHT:
        return None                              # всё серое — диалог/оверлей, а не подсказка игры
    dim = {c for c, v in lv.items() if v < DIM_THR}
    if not dim:
        return None                              # все яркие — ограничений нет
    bright = frozenset(c for c in lv if c not in dim)
    return bright if bright else None


class PlayableOracle:
    """Принимает сигнал, только если два кадра подряд дали одно и то же (карта, затемнена?)."""

    def __init__(self):
        self.prev = None
        self.value = None
        self.since = 0

    def reset(self):
        self.prev, self.value, self.since = None, None, 0

    def update(self, card_levels, unmatched=0):
        if unmatched:                    # на экране есть нераспознанная карта: по неполной картине не судим
            card_levels = {}
        sig = None
        if card_levels:
            sig = frozenset((c, v < DIM_THR) for c, v in card_levels.items())
        cand = screen_legal(card_levels) if card_levels else None
        if sig is not None and sig == self.prev:
            self.value = cand
            self.since += 1
        else:
            self.value = None if sig != self.prev else self.value
            self.since = 0
        self.prev = sig
        return self.value
