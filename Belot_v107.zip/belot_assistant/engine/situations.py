# engine/situations.py — правила из глав B–T как бонусы/штрафы к оценке карты (в очках).
# Каждая функция описывает целое семейство ситуаций из руководства (напр. M33–M40 «ходи старшей в масть»).
from .rules import who_takes_trick

def _wins(card, table, trump):
    return bool(table) and who_takes_trick(table + [card], trump) == len(table)

def situation_bonus(card, ctx):
    """ctx: hand, table, trump, snap, partner_winning, partner_secure, last_to_play, declared, risk, voids, mode"""
    h, table, trump = ctx["hand"], ctx["table"], ctx["trump"]
    pts = card.points(trump); isT = card.suit == trump
    bonus, tags = 0.0, []
    table_pts = sum(c.points(trump) for c in table)
    wins = _wins(card, table, trump)
    last_trick = len(h) == 1
    # E4/P21–P23/D10/D11/O29: J и 9 козыря берегу, если взятка не крупная
    if isT and card.rank == "J" and not last_trick and not (wins and table_pts >= 20):
        bonus -= 6; tags.append("J берегу")
    if isT and card.rank == "9" and not last_trick and not (wins and table_pts >= 14):
        bonus -= 3; tags.append("9 берегу")
    # C1/N1–N8/E3: партнёр берёт надёжно -> отдаю очки, не перебиваю
    if ctx["partner_secure"]:
        bonus += 0.6 * pts if not isT else -2
        if wins: bonus -= 5; tags.append("не перебиваю партнёра")
    # C5/N13–N16/O3: соперник берёт, а я не бью -> не растрачиваю A/10
    if table and not ctx["partner_winning"] and not wins:
        bonus -= 0.7 * pts
    # B13/E2: режу козырем только крупную взятку
    if table and isT and table[0].suit != trump and wins and table_pts < 10 and not last_trick:
        bonus -= 2; tags.append("режу мелочь")
    # D4/O13: последняя взятка (+10) — беру
    if last_trick and wins:
        bonus += 4
    # B6/M22–M27: не объявил козырь — не тяну его первым
    if not table and isT and not ctx["declared"] and any(c.suit != trump for c in h):
        bonus -= 5; tags.append("козырь не начинаю")
    # B1/M1–M12/E1: объявил, 4+ козырей — тяну младшим
    ntr = sum(1 for c in h if c.suit == trump)
    if not table and ctx["declared"] and isT and ntr >= 4 and card.rank not in ("J",) and \
            card.strength(trump) == min(x.strength(trump) for x in h if x.suit == trump):
        bonus += 3; tags.append("тяну козырь")
    # B3/M3/M4: 2–3 козыря — козырь не тяну
    if not table and isT and ntr <= 3 and any(c.suit != trump for c in h):
        bonus -= 3
    # D1/O1: у других козырей нет — мои козыри главные
    snap = ctx.get("snap")
    if snap and not table and isT:
        left = [c for c in snap["unseen"] if c.suit == trump]
        if not left: bonus += 3; tags.append("козырей у других нет")
    # C6/C7/N17/N18: A потом 10 той же масти
    if not table and not isT and card.rank in ("A", "10"):
        same = sum(1 for c in h if c.suit == card.suit)
        bonus += 1.0 + 0.5 * min(same, 4)
    # B15/N22: длинная масть
    # C8/N25: масть без ответа у соперника
    if not table and ctx.get("voids") and card.suit in (ctx["voids"].get(1, set()) | ctx["voids"].get(3, set())):
        bonus -= 4
    # F/Q/D5/D6: счёт
    if ctx["risk"] == "risky" and not table and isT and ctx["declared"]: bonus += 3
    if ctx["risk"] == "safe" and not table and not isT and card.rank in ("A", "10"): bonus += 2

    # --- v19: дополнительные советы из руководства (без нарушения правил: влияют только на выбор среди допустимых карт) ---
    def _is_master(c):
        return bool(snap) and not any(u.suit == c.suit and u.strength(trump) > c.strength(trump) for u in snap["unseen"])
    have_bella = any(c.suit == trump and c.rank == "Q" for c in h) and any(c.suit == trump and c.rank == "K" for c in h)
    # C10/C11/J4/S29: Bella = 20 очков — выкладываю Q/K козыря, пока пара цела (объявляется при первой из них)
    if have_bella and isT and card.rank in ("Q", "K") and len(h) > 1:
        bonus += 4; tags.append("Bella +20")
    # B11/E10: голая 10 без A (A ещё не вышел) — её съедят, не вывожу
    if snap and not table and not isT and card.rank == "10" and not _is_master(card) \
            and any(u.suit == card.suit and u.rank == "A" for u in snap["unseen"]):
        bonus -= 5; tags.append("10 без A — съедят")
    # N13–N16/C5: сброс — освобождаю короткую масть, чтобы потом резать козырем (E2)
    if table and not ctx["partner_winning"] and not wins and not isT and any(c.suit == trump for c in h):
        if sum(1 for c in h if c.suit == card.suit) == 1 and pts <= 3:
            bonus += 1.5; tags.append("освобождаю масть под рез")
    # P22/P23/E14: крупная взятка соперника — беру её, если могу и партнёр не берёт надёжно
    if table and wins and not ctx["partner_secure"] and table_pts >= 10:
        bonus += 0.15 * table_pts
    # D2/O3: у меня нет козырей, у других есть — A и 10 надо разыграть пока не порезали
    if snap and not table and not isT and not any(c.suit == trump for c in h) and card.rank in ("A", "10") \
            and any(u.suit == trump for u in snap["unseen"]) and _is_master(card):
        bonus += 2; tags.append("сыграть A/10, пока не порезали")
    # --- матрица решений для 3 игроков (блоки 1-3) ---
    if ctx.get("mode") == "3p":
        b3, t3 = matrix3p_bonus(card, ctx, wins, table_pts)
        bonus += b3; tags += t3
    # B2/D7/D8: единственная карта/только козыри — без штрафов
    if len(h) == 1:
        bonus = 0
    return bonus, tags


def matrix3p_bonus(card, ctx, wins, table_pts):
    """Правила матрицы решений для игры втроём (блоки 1-3). Только бонусы к выбору среди допустимых карт."""
    h, table, trump, snap = ctx["hand"], ctx["table"], ctx["trump"], ctx.get("snap")
    isT = card.suit == trump
    bonus, tags = 0.0, []
    trumps = [c for c in h if c.suit == trump]
    others_have_trump = (not snap) or any(u.suit == trump for u in snap["unseen"])
    # 2.31-2.33, 2.35, 2.37: перебиваю козырем, если взятка достаточно дорогая
    if table and wins and isT and table[0].suit != trump:
        lead_top = max(table, key=lambda c: c.strength(trump))
        need = {"A": 15, "10": 20}.get(lead_top.rank)
        if card.rank == "J" and lead_top.rank == "A": need = 25
        if need is not None:
            bonus += 3 if table_pts >= need else -3
            tags.append("3p: режу дорогую взятку" if table_pts >= need else "3p: взятка дешёвая — не режу")
    if table and wins and isT and table[0].suit == trump:
        need = 20 if card.rank == "J" else 15
        bonus += 2 if table_pts >= need else -2; tags.append("3p: перебиваю козырь")
    # 3.19-3.22: две карты — A/10 боковой разыгрываю, J/9 козыря держу на последнюю
    if not table and len(h) == 2:
        side = [c for c in h if c.suit != trump]; tr = [c for c in h if c.suit == trump]
        if len(side) == 1 and len(tr) == 1:
            sc, tc = side[0], tr[0]
            if tc.rank in ("J", "9") and sc.rank == "A": bonus += 6 if card == sc else -6; tags.append("3p: A сначала, J/9 на последнюю")
            elif tc.rank == "8" and sc.rank == "10":     bonus += 6 if card == tc else -6; tags.append("3p: 8 сначала, 10 берегу")
            elif others_have_trump:                      # 3.23
                bonus += 3 if card == sc else -3; tags.append("3p: боковую, козырь берегу")
    # 3.1/3.2/3.6: у соперников козырей нет — мои козыри играют; единственный козырь — на последнюю
    if not table and snap and not others_have_trump and len(trumps) >= 2 and isT:
        bonus += 3; tags.append("3p: у соперников нет козырей")
    if not table and snap and not others_have_trump and len(trumps) == 1 and isT and len(h) > 1:
        bonus -= 3; tags.append("3p: единственный козырь — на последнюю")
    # 1.7 / 1.35 / 1.37: длинная масть (5+) — играю её, начиная со старшей
    if not table and not isT:
        n = sum(1 for c in h if c.suit == card.suit)
        if n >= 5: bonus += 3; tags.append("3p: длинная масть")
        if n >= 4 and card.rank in ("A", "10"): bonus += 1
    # 1.3 / 1.4: козырей <= 3 — боковая A/10, козыри не тяну
    if not table and ctx.get("declared") and len(trumps) <= 3 and isT and any(c.suit != trump and c.rank in ("A", "10") for c in h):
        bonus -= 2
    # 1.8 / 2.18: не играющий с 4+ козырями — не тяну
    if not table and not ctx.get("declared") and len(trumps) >= 4 and isT: bonus -= 2
    # 1.9 / 1.10 / 2.19 / 2.20: не играющий — J и 9 берегу
    if not ctx.get("declared") and isT and card.rank in ("J", "9") and len(h) > 1 and not (wins and table_pts >= 20):
        bonus -= 2
    # 3.7-3.9 / 3.24-3.25: последняя взятка — играю старшее
    if len(h) == 1: bonus = 0
    return bonus, tags
