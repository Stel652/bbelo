"""Проверка согласованности состояния: колода, дубликаты, размеры рук.
Возвращает список проблем (пустой список = состояние допустимо)."""
from .tracker import deck_for_mode


def check_state(hand, table, seen, mode="2v2"):
    deck = deck_for_mode(mode)
    problems = []
    hand, table, seen = list(hand), list(table), set(seen)
    for name, cards in (("рука", hand), ("стол", table)):
        if len(set(cards)) != len(cards):
            problems.append(f"дубликат карты в: {name}")
        for c in cards:
            if c not in deck:
                problems.append(f"карта {c} вне колоды режима {mode}")
    if set(hand) & set(table):
        problems.append("карта одновременно в руке и на столе")
    if set(hand) & seen:
        problems.append("карта одновременно в руке и среди сыгранных: "
                        + ",".join(sorted(map(str, set(hand) & seen))))
    players = {"2v2": 4, "1v1": 2, "3p": 3}.get(mode, 4)
    if len(table) > players:
        problems.append(f"на столе {len(table)} карт при {players} игроках")
    per_hand = len(deck) // players
    if len(hand) > per_hand:
        problems.append(f"в руке {len(hand)} карт, максимум {per_hand}")
    return problems


def is_valid(hand, table, seen, mode="2v2"):
    return not check_state(hand, table, seen, mode)
