"""Автоклик: бот сам кликает по карте, которую посоветовал, и проверяет, что ход сделан.
ВЫКЛЮЧЕН по умолчанию (config.AUTOPLAY = False), включается клавишей F4; F4 ещё раз — стоп.
Безопасность: кликаем только в свой ход, только по карте из списка разрешённых ходов, только если советом и руками
не менялось HOLD секунд, и не чаще одного клика за RETRY_AFTER секунд; после неудачных попыток автоклик выключается."""
import time

class AutoPlayer:
    def __init__(self, click, hold=1.0, retry_after=2.5, max_clicks=3, now=time.time, min_frames=3):
        self.click, self.hold, self.retry_after, self.max_clicks, self.now = click, hold, retry_after, max_clicks, now
        self.min_frames = min_frames      # сколько кадров подряд состояние должно быть ОДИНАКОВЫМ (защита от спешки/мерцания распознавания)
        self.enabled = False
        self._reset()

    def _reset(self):
        self.sig, self.t_seen, self.clicks, self.t_click, self.same = None, 0.0, 0, 0.0, 0

    def toggle(self):
        self.enabled = not self.enabled
        self._reset()
        return self.enabled

    def step(self, move, legal, hand, table, trump, my_turn, pos, zone, hold=None, verify=None):
        """pos — {карта: (x, y)} в координатах зоны руки, zone — (x, y, w, h) зоны руки на экране.
        Возвращает 'click', 'stopped' или None (ничего не делали)."""
        if not self.enabled:
            return None
        p = pos.get(move) if move is not None else None
        ok = my_turn and move is not None and move in legal and p is not None \
            and 0 <= p[0] <= zone[2] and 0 <= p[1] <= zone[3]
        if not ok:
            self._reset()
            return None
        sig = (move, tuple(sorted(map(str, hand))), len(table), trump)   # содержимое стола мерцает при распознавании — стабильность держим по ходу, руке и числу карт на столе
        t = self.now()
        pp = getattr(self, "_p_prev", None)
        self._p_prev = p
        if pp is not None and (abs(pp[0] - p[0]) > 5 or abs(pp[1] - p[1]) > 5):
            self.sig = None; self.same = 0           # карта сдвигается (анимация/перестройка руки) — ждём, пока остановится
        if sig != self.sig:
            self.sig, self.t_seen, self.clicks, self.t_click, self.same = sig, t, 0, 0.0, 1
            return None
        self.same += 1
        if self.same < self.min_frames:
            return None
        if t - self.t_seen < (self.hold if hold is None else hold):
            return None
        if self.clicks and t - self.t_click < self.retry_after:
            return None                       # ждём, пока карта окажется на столе (тогда sig изменится)
        if self.clicks >= self.max_clicks:
            # раньше здесь автоклик выключался навсегда. Теперь: перечитываем ситуацию и пробуем снова (клик по разрешённой карте безопасен)
            self.clicks = 0; self.t_seen = t; self.same = 0
            return "retry"
        if verify is not None:
            try:
                good = bool(verify(p))
            except Exception:
                good = False
            if not good:                       # перед самым кликом свежий кадр не подтвердил карту под курсором — не кликаем
                self.sig = None; self.same = 0
                return "verify_failed"
        self.click(zone[0] + p[0], zone[1] + p[1])
        self.clicks += 1; self.t_click = t
        return "click"


def mouse_click(x, y, scale=1.0, offset=(0, 0)):
    """Клик левой кнопкой в точке экрана (пиксели захвата); курсор возвращается на место."""
    from pynput.mouse import Controller, Button
    m = Controller(); old = m.position
    m.position = (int(x * scale + offset[0]), int(y * scale + offset[1]))
    time.sleep(0.05); m.click(Button.left, 1); time.sleep(0.05)
    m.position = old
