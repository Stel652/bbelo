"""Автоторги и автоклик комбинаций (румынский интерфейс belot.md).

1) Панель «Joc [масть] / Pas»: оцениваем первые 5 карт (strategy.should_play / best_suit) и сами жмём Joc или Pas.
   Если зелёных кнопок несколько (2-й круг, выбор козыря) — читаем масть на каждой кнопке и жмём лучшую (или Pas).
2) Слева внизу появляются кнопки комбинаций (Bella, Jumate Suta, Terta ...): новый объект в зоне -> клик.
Всё работает только при включённом автокликe. Чистые функции работают с BGR-картинками -> легко тестировать."""
import time
import cv2
import numpy as np


def _blobs(mask, min_area, max_w=None, max_h=None, min_h=0):
    n, _, st, cen = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if max_w and w > max_w or max_h and h > max_h or h < min_h:
            continue
        if a >= min_area and w > h * 0.8 and a / float(w * h) > 0.55:   # сплошная кнопка, не рамка
            out.append({"box": (int(x), int(y), int(w), int(h)), "c": (int(cen[i][0]), int(cen[i][1])), "area": int(a)})
    return out


def find_bid_buttons(img):
    """-> {'green': [blob...] слева направо, 'red': [blob...]} в координатах картинки. Joc зелёная, Pas красная."""
    if img is None or img.size == 0:
        return {"green": [], "red": [], "white": []}
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
    green = ((h >= 35) & (h <= 90) & (s > 90) & (v > 110))
    red = (((h <= 10) | (h >= 168)) & (s > 110) & (v > 110))
    k = np.ones((3, 3), np.uint8)
    green = cv2.morphologyEx(green.astype(np.uint8), cv2.MORPH_CLOSE, k, iterations=2)
    red = cv2.morphologyEx(red.astype(np.uint8), cv2.MORPH_CLOSE, k, iterations=2)
    H, W = img.shape[:2]
    min_a = max(120, int(H * W * 0.012))
    lim = dict(max_w=int(W * 0.45), max_h=int(H * 0.45))     # кнопка небольшая; фон стола (любого цвета) не подходит
    g = sorted(_blobs(green, min_a, **lim), key=lambda b: b["c"][0])
    r = sorted(_blobs(red, min_a, **lim), key=lambda b: b["c"][0])
    # 2-й круг: белые квадратные кнопки с мастями (одинаковые, в один ряд)
    white = ((v > 215) & (s < 40)).astype(np.uint8)
    white = cv2.morphologyEx(white, cv2.MORPH_CLOSE, k, iterations=2)
    w_ = [b for b in _blobs(white, max(400, int(H * W * 0.02)), min_h=int(H * 0.25), **lim) if 0.75 < b["box"][2] / float(b["box"][3]) < 1.35]
    w_ = sorted(w_, key=lambda b: b["c"][0])
    if len(w_) < 2 or max(b["c"][1] for b in w_) - min(b["c"][1] for b in w_) > 12:
        w_ = []
    return {"green": g, "red": r, "white": w_}


def white_blob_suit(img, blob, classify):
    """Масть на белой кнопке (2-й круг): классифицируем всю кнопку."""
    x, y, w, h = blob["box"]
    m = int(min(w, h) * 0.12)
    crop = img[y + m:y + h - m, x + m:x + w - m]
    try:
        return classify(crop)
    except Exception:
        return None


def decide_round2(hand, suits, has_pas, should_play, evaluate):
    """3 кнопки мастей (+ Pas). Выбираем лучшую; если играть невыгодно — Pas; если Pas нет — обязаны выбрать лучшую."""
    known = [(i, s) for i, s in enumerate(suits) if s]
    if not known:
        return None, None
    best = max(known, key=lambda it: evaluate(hand, it[1]))
    ok, _ = should_play(hand, best[1])
    if ok or not has_pas:
        return "white", best[0]
    return "red", None


def blob_suit(img, blob, classify):
    """Масть иконки на кнопке: белый квадратик справа внутри кнопки."""
    x, y, w, h = blob["box"]
    crop = img[y:y + h, x + int(w * 0.5):x + w]
    if crop.size == 0:
        return None
    g = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    ys, xs = np.where(g > 225)
    if len(xs) < 20:
        return None
    sq = crop[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    try:
        return classify(sq)
    except Exception:
        return None


def decide_bid(hand, suits, should_play, best_suit, evaluate):
    """suits — масти на зелёных кнопках (слева направо; None — не прочиталась). -> ('green', индекс) | ('red', None) | (None, None)."""
    known = [(i, s) for i, s in enumerate(suits) if s]
    if not known:
        return None, None
    if len(suits) == 1:
        ok, _ = should_play(hand, known[0][1])
        return ("green", 0) if ok else ("red", None)
    # несколько вариантов (2-й круг): берём лучшую масть из доступных
    best = max(known, key=lambda it: evaluate(hand, it[1]))
    ok, _ = should_play(hand, best[1])
    return ("green", best[0]) if ok else ("red", None)


def find_combo_buttons(img):
    """Кнопка комбинации (зелёная плашка с белым текстом: «Patru cărți J», «Bella», «Jumate Suta» ...) слева внизу.
    Только цветные яркие широкие сплошные плашки с белым текстом внутри; рамки, аватар, веер карт и сукно не подходят."""
    if img is None or img.size == 0:
        return []
    H, W = img.shape[:2]
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    sat, val = hsv[:, :, 1], hsv[:, :, 2]
    mask = ((sat > 100) & (val > 150)).astype(np.uint8)
    white = (val > 205) & (sat < 60)
    raw = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=1)
    mask = raw   # слабое склеивание: плашки друг под другом не сливаются
    out = []
    for b in _blobs(mask, int(W * H * 0.012)):
        x, y, w, h = b["box"]
        if w < W * 0.45 or w / float(max(h, 1)) < 1.6:
            continue
        for (yy, hh) in _split_rows(raw[y:y + h, x:x + w], H):
            if not (H * 0.09 <= hh <= H * 0.35) or w / float(hh) < 2.2:
                continue
            if white[y + yy:y + yy + hh, x:x + w].mean() < 0.012:      # внутри должен быть белый текст
                continue
            sel = raw[y + yy:y + yy + hh, x:x + w] > 0
            hue = hsv[y + yy:y + yy + hh, x:x + w, 0][sel]
            if hue.size == 0 or not (35 <= float(np.median(hue)) <= 90):   # кнопка зелёная; красные/жёлтые картинки карт не подходят
                continue
            out.append({"box": (x, y + yy, w, hh), "c": (x + w // 2, y + yy + hh // 2), "area": int(w * hh)})
    return sorted(out, key=lambda b: b["c"][1])


def _split_rows(m, H):
    """Разделяет высокий блок на отдельные плашки по строкам-промежуткам (покрытие строки < 30%)."""
    cov = m.mean(axis=1) if m.size else np.zeros(0)
    segs, start = [], None
    for i, v in enumerate(cov):
        if v >= 0.3 and start is None:
            start = i
        elif v < 0.3 and start is not None:
            segs.append((start, i - start)); start = None
    if start is not None:
        segs.append((start, len(cov) - start))
    return [sg for sg in segs if sg[1] >= H * 0.05] or [(0, m.shape[0])]


class ComboWatcher:
    """Видит ВСЕ кнопки комбинаций (их бывает несколько: Bella + Tertz + 50 ...) и отдаёт по очереди каждую ненажатую.
    Кнопка считается стабильной после `persist` кадров на одном месте; каждую жмём один раз (повтор — только если
    она осталась на месте после паузы, до `retries` раз). Когда кнопок нет `gone` кадров подряд — всё сбрасывается."""
    def __init__(self, now=time.time, persist=3, retries=2, gone=4):
        self.now, self.persist, self.retries, self.gone = now, persist, retries, gone
        self.reset()

    def reset(self):
        self.seen = {}        # ключ позиции -> сколько кадров подряд виден
        self.clicks = {}      # ключ позиции -> сколько раз нажали
        self.visible = []
        self.absent = 0

    @staticmethod
    def _key(c):
        return (int(round(c[0] / 12.0)), int(round(c[1] / 12.0)))

    def feed(self, img):
        bl = find_combo_buttons(img)
        if not bl:
            self.absent += 1
            self.visible = []
            if self.absent >= self.gone:
                self.reset()
            return None
        self.absent = 0
        self.visible = [b["c"] for b in bl]
        keys = [self._key(c) for c in self.visible]
        self.seen = {k: self.seen.get(k, 0) + 1 for k in keys}
        for c, k in zip(self.visible, keys):                  # сверху вниз (find_combo_buttons сортирует по y)
            n = self.clicks.get(k, 0)
            if self.seen[k] < self.persist:
                continue
            if n == 0 or (n <= self.retries and self.seen[k] >= self.persist + 8 * n):   # не нажалась — пробуем ещё
                return c
        return None

    def mark_clicked(self, c):
        k = self._key(c)
        self.clicks[k] = self.clicks.get(k, 0) + 1


class BidClicker:
    def __init__(self, click, now=time.time, hold=1.0, cooldown=2.5, max_clicks=3):
        self.click, self.now, self.hold, self.cooldown, self.max_clicks = click, now, hold, cooldown, max_clicks
        self.reset()

    def reset(self):
        self.sig, self.t_seen, self.clicks, self.t_click = None, 0.0, 0, 0.0

    def step(self, hand, buttons, suits, zone, should_play, best_suit, evaluate):
        """-> строка-описание клика или None. zone — (x,y,w,h) панели на экране."""
        if not hand or len(hand) < 5 or not (buttons["green"] or buttons["red"] or buttons.get("white")):
            self.reset()
            return None
        sig = (tuple(sorted(map(str, hand))), tuple(suits))
        t = self.now()
        if sig != self.sig:
            self.sig, self.t_seen, self.clicks = sig, t, 0
            return None
        if t - self.t_seen < self.hold or (self.clicks and t - self.t_click < self.cooldown) or self.clicks >= self.max_clicks:
            return None
        if buttons.get("white"):
            kind, idx = decide_round2(list(hand), suits, bool(buttons["red"]), should_play, evaluate)
            if kind == "white" and idx is not None:
                bb = buttons["white"][idx]
                self.click(zone[0] + bb["c"][0], zone[1] + bb["c"][1]); self.clicks += 1; self.t_click = t
                return f"козырь {suits[idx]}"
        else:
            kind, idx = decide_bid(list(hand), suits, should_play, best_suit, evaluate)
        if kind == "green" and idx < len(buttons["green"]):
            b = buttons["green"][idx]
        elif kind == "red" and buttons["red"]:
            b = buttons["red"][0]
        else:
            return None
        self.click(zone[0] + b["c"][0], zone[1] + b["c"][1])
        self.clicks += 1; self.t_click = t
        return ("Joc" + (f" ({suits[idx]})" if idx is not None and idx < len(suits) else "")) if kind == "green" else "Pas"
