"""Фильтры распознавания: ложные карты стола и двойники ♠/♣ на одной позиции в руке."""
BLACK = ("spades", "clubs")

def _score(scores, c):
    s = (scores or {}).get(f"{c.rank}{c.suit[0]}")
    return s if isinstance(s, (tuple, list)) and len(s) == 2 else None

def filter_table(hits, scores, rank_thr=0.4, suit_thr=0.1, protect=(), dead=()):
    """Стол: ложная карта — оценка достоинства < rank_thr. Оценка масти у чёрных карт — это сходство с эталоном,
    а ♠/♣ решает форма значка, поэтому настоящие A♣, K♠, Q♠ и 10♠ имеют масть ~0.0-0.2 (в реальной партии так убирался
    сыгранный A♣). Низкая масть (< suit_thr) считается признаком ложной карты только у карт, которые уже не могут
    появиться (dead: закрытые взятки). protect — карты, что были у меня в руке: их со стола не убираем никогда.
    Возвращает (оставленные, удалённые)."""
    keep, drop = [], []
    for c, p in hits:
        s = _score(scores, c)
        bad = s is not None and c not in protect and (s[0] < rank_thr or (s[1] < suit_thr and c in dead))
        (drop if bad else keep).append((c, p))
    return keep, drop

def dedupe_black_twins(hits, scores, known_hand=(), played=(), tol=25):
    """Две карты одного достоинства (♠ и ♣) на одной позиции — одна физическая карта.
    Выбор: сначала уже стабильно бывшая в руке, потом ещё не сыгранная, потом лучшая оценка масти."""
    out, dropped = [], []
    used = set()
    for i, (c, p) in enumerate(hits):
        if i in used: continue
        grp = [(c, p)]
        for j in range(i + 1, len(hits)):
            c2, p2 = hits[j]
            if j not in used and c2.rank == c.rank and c2.suit != c.suit and c.suit in BLACK and c2.suit in BLACK \
                    and abs(p[0] - p2[0]) <= tol:
                grp.append((c2, p2)); used.add(j)
        if len(grp) == 1:
            out.append((c, p)); continue
        def key(h):
            s = _score(scores, h[0])
            return (h[0] in known_hand, h[0] not in played, s[1] if s else 0.0)
        best = max(grp, key=key)
        out.append(best); dropped += [h for h in grp if h is not best]
    return out, dropped


class TrickGate:
    """Остатки прошлой взятки: игра убирает стол с задержкой, и старые карты висят рядом с новыми.
    Когда на столе стабильно лежит полный комплект (players карт) `need` кадров подряд — взятка завершена,
    её карты считаются «устаревшими» и не попадают в стол, пока не исчезнут (≥ gone кадров подряд)."""
    def __init__(self, need=3, gone=6):
        self.need, self.gone = need, gone
        self.reset()

    def reset(self):
        self.stale = {}        # карта -> сколько кадров подряд её нет
        self._cand, self._cnt = None, 0

    def update(self, hits, players):
        """Возвращает (оставленные, отброшенные как остаток прошлой взятки)."""
        vis = {c for c, _ in hits}
        for c in list(self.stale):
            if c in vis: self.stale[c] = 0
            else:
                self.stale[c] += 1
                if self.stale[c] >= self.gone: del self.stale[c]
        keep = [h for h in hits if h[0] not in self.stale]
        drop = [h for h in hits if h[0] in self.stale]
        cur = frozenset(c for c, _ in keep)
        if len(cur) == players and cur == self._cand:
            self._cnt += 1
        else:
            self._cand, self._cnt = (cur if len(cur) == players else None), (1 if len(cur) == players else 0)
        if self._cnt >= self.need:           # взятка завершена: отсюда карты считаем остатком
            for c in cur: self.stale[c] = 0
            self._cand, self._cnt = None, 0
        return keep, drop


class PlayedGuard:
    """Сыгранная карта (подтверждённый ход: была в руке, появилась на столе, из руки исчезла) иногда снова «появляется»
    в руке на следующих кадрах — в реальном журнале J♣ сыграна в кадре 220, а в кадрах 221-236 числилась в руке и
    даже советовалась. Подтверждённую карту убираем из руки, пока она там видна; вернуться она может только после
    `back` кадров отсутствия. (Дубли «рука+стол» сами по себе сыгранной картой НЕ считаем: в журнале 11 из 24 таких
    случаев были призраками чёрных карт.)"""
    def __init__(self, back=8):
        self.back = back
        self.reset()

    def reset(self):
        self.ban = {}

    def confirm(self, cards):
        for c in cards: self.ban[c] = 0

    def update(self, raw_hand, hand_mem):
        """Возвращает множество карт, которые надо убрать из руки и памяти руки в этом кадре."""
        for c in list(self.ban):
            if c in raw_hand: self.ban[c] = 0
            else:
                self.ban[c] += 1
                if self.ban[c] >= self.back: del self.ban[c]
        return {c for c in self.ban if c in raw_hand or c in hand_mem}


def lead_suit_fix(hand, table, forbidden=(), trump=None, stable=()):
    """Масть первой карты стола — пики/трефы, а в руке нет этой масти, но есть другая чёрная: почти наверняка это та же масть,
    просто ♠/♣ в руке перепутаны (реальный журнал: на столе Q♠, A♠, а в руке «J♣» — совет «режу козырем», хотя нужно идти пикой).
    Такие карты считаем мастью первой карты, если получившейся карты нет на столе и она не вышла раньше.
    НЕ трогаем карту, если это козырь (законная порезка, когда нужной масти нет) или если она стабильно читалась в руке
    на многих кадрах (stable) — иначе настоящая 10♠ превращалась в 10♣ (реальный случай из журнала).
    Возвращает (новая рука, список (было, стало))."""
    if not table or not hand:
        return list(hand), []
    lead = table[0].suit
    if lead not in BLACK or any(c.suit == lead for c in hand):
        return list(hand), []
    other = BLACK[0] if lead == BLACK[1] else BLACK[1]
    banned = set(forbidden) | set(table)
    out, flips = [], []
    for c in hand:
        if c.suit == other and c.suit != trump and c not in stable:
            n = type(c)(lead, c.rank)
            if n not in banned and n not in hand:
                out.append(n); flips.append((c, n)); continue
        out.append(c)
    return out, flips
