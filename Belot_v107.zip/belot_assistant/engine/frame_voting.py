"""Multi-frame Recognition + Confidence Tracker: карта подтверждается только если стабильно
видна в нескольких последних кадрах. Одиночный кадр не меняет состояние."""
from collections import deque, Counter

HIGH, MEDIUM, LOW = "high", "medium", "low"

class FrameVoter:
    def __init__(self, window=5, confirm=3):
        self.window, self.confirm = window, confirm
        self.frames = deque(maxlen=window)

    def push(self, cards):
        """cards — карты, распознанные в кадре. Возвращает (подтверждённые, уверенность по каждой карте)."""
        self.frames.append(set(cards))
        return self.state()

    def state(self):
        cnt = Counter(c for f in self.frames for c in f)
        n = len(self.frames)
        conf = {}
        for c, k in cnt.items():
            conf[c] = HIGH if (k >= self.confirm and k == n) else MEDIUM if k >= self.confirm else LOW
        confirmed = {c for c, lvl in conf.items() if lvl != LOW}
        return confirmed, conf

    def reliable_hand(self, expected_len=None):
        """None, если подтверждённых карт не столько, сколько ожидается (не выдавать ложный совет)."""
        confirmed, _ = self.state()
        if expected_len is not None and len(confirmed) != expected_len:
            return None
        return confirmed
