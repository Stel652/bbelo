# engine/rules.py
from typing import List, Optional
from .cards import Card

def can_play_card(card: Card, table: List[Card], hand: List[Card], trump: str,
                  trump_lead_allowed: bool) -> bool:
    """Check the project's follow-suit/trump obligations.

    Follow the led suit whenever possible. If the led suit is trump, the
    overtrump requirement is applied to that suit as well. When void in the
    led suit, trump if possible and overtrump an existing trump where required.
    """
    if not table:
        if card.is_trump(trump) and not trump_lead_allowed:
            return not any(not c.is_trump(trump) for c in hand)
        return True

    lead_suit = table[0].suit
    has_lead = any(c.suit == lead_suit for c in hand)
    trumps_on_table = [c for c in table if c.is_trump(trump)]

    # Following the led suit has priority over any discard/cut.
    if has_lead:
        if card.suit != lead_suit:
            return False
        # If trump was led, a higher trump must beat the current one when held.
        if lead_suit == trump and trumps_on_table:
            highest = max(trumps_on_table, key=lambda c: c.strength(trump))
            higher = [c for c in hand if c.suit == trump and c.strength(trump) > highest.strength(trump)]
            if higher:
                return card.strength(trump) > highest.strength(trump)
        return True

    has_trump = any(c.is_trump(trump) for c in hand)
    if has_trump:
        if not card.is_trump(trump):
            return False
        if trumps_on_table:
            highest = max(trumps_on_table, key=lambda c: c.strength(trump))
            higher = [c for c in hand if c.is_trump(trump) and c.strength(trump) > highest.strength(trump)]
            if higher:
                return card.strength(trump) > highest.strength(trump)
        return True
    return True

def who_takes_trick(table: List[Card], trump: str) -> int:
    """Индекс карты, которая забирает взятку."""
    if not table:
        return -1
    lead = table[0].suit
    best_idx = 0
    best = table[0].strength(trump)
    for i, c in enumerate(table[1:], 1):
        if c.suit != lead and not c.is_trump(trump):
            continue
        if c.strength(trump) > best:
            best = c.strength(trump)
            best_idx = i
    return best_idx