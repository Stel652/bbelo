"""Память бота: пишет все ходы в журнал, считает статистику советов и помнит её между играми.

Файлы лежат в папке data/ рядом с main.py:
  games.jsonl — журнал событий (совет, твой реальный ход, итог взятки, итог раздачи)
  stats.json  — накопленная статистика: как часто совет выигрывал взятку, сколько очков принёс
"""
import json, os, time
from .rules import who_takes_trick
from .tracker import observe_complete_trick

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

def reason_key(why):
    k = (why or "").split(" · ")[0].split(" (")[0].strip()
    return k[:60] or "?"

class GameMemory:
    def __init__(self, mode):
        self.mode = mode
        os.makedirs(DATA_DIR, exist_ok=True)
        self.log_path = os.path.join(DATA_DIR, "games.jsonl")
        self.stats_path = os.path.join(DATA_DIR, "stats.json")
        self.stats = self._load()
        self.game_id = int(time.time())
        self.prev_hand, self.prev_table = set(), []
        self.last_advice = None          # (card, why)
        self.my_card, self.my_advice = None, None
        self.done_tricks = set()
        self.dirty = 0
        self.last_trick = None
        self._rotate_log()

    def _load(self):
        try:
            with open(self.stats_path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"advice": {}, "followed": 0, "ignored": 0, "tricks": 0, "tricks_won": 0, "points": 0}

    def save(self):
        try:
            with open(self.stats_path, "w", encoding="utf-8") as f:
                json.dump(self.stats, f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    # --- память раздачи: переживает перезапуск программы ---
    def _round_path(self):
        return os.path.join(DATA_DIR, "round_state.json")

    def save_round(self, tracker, trump, hand):
        sig = (len(tracker.seen), len(tracker.closed), trump, tuple(sorted(map(str, hand))))
        if sig == getattr(self, "_round_sig", None):
            return
        self._round_sig = sig
        from .cards import Card
        st = {"t": time.time(), "mode": self.mode, "trump": trump, "rounds": tracker.rounds,
              "seen": [str(c) for c in tracker.seen], "closed": [str(c) for c in tracker.closed],
              "voids": {str(k): sorted(v) for k, v in tracker.voids.items()}}
        tmp = self._round_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False)
        os.replace(tmp, self._round_path())

    def load_round(self, tracker, max_age=20 * 60):
        """Если программу перезапустили посреди раздачи — вспоминаем сыгранные карты и «пустые» масти."""
        try:
            with open(self._round_path(), encoding="utf-8") as f:
                st = json.load(f)
        except Exception:
            return False
        if st.get("mode") != self.mode or time.time() - st.get("t", 0) > max_age:
            return False
        from .cards import Card
        by_str = {str(c): c for c in tracker.deck}
        tracker.seen |= {by_str[x] for x in st.get("seen", []) if x in by_str}
        tracker.closed |= {by_str[x] for x in st.get("closed", []) if x in by_str}
        for k, v in st.get("voids", {}).items():
            if int(k) in tracker.voids:
                tracker.voids[int(k)] |= set(v)
        return True

    def _rotate_log(self, limit=5_000_000):
        try:
            if os.path.getsize(self.log_path) > limit:
                os.replace(self.log_path, self.log_path + ".old")
        except OSError:
            pass

    def _log(self, ev, **kw):
        try:
            rec = {"t": round(time.time(), 1), "game": self.game_id, "mode": self.mode, "ev": ev}
            rec.update(kw)
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass

    # --- вызовы из main.py ---
    def on_advice(self, hand, table, trump, move, why, score):
        if move is None:
            return
        self.last_advice = (move, why)
        self._log("advice", hand=[str(c) for c in hand], table=[str(c) for c in table], trump=trump,
                  move=str(move), why=why, score=list(score))

    def on_new_round(self):
        self._log("new_round")
        self.done_tricks.clear(); self.my_card = None; self.my_advice = None; self.last_trick = None

    def on_table(self, hand, table, trump, players, tracker):
        """Вызывать каждый тик: ловит мой ход (карта ушла из руки на стол) и конец взятки."""
        hand_set = set(hand)
        # мой ход: карта была в руке в прошлый тик и теперь лежит на столе
        for c in table:
            if c in self.prev_hand and c not in hand_set and c != self.my_card and c not in self.prev_table:
                self.my_card = c
                adv = self.last_advice
                self.my_advice = adv
                followed = bool(adv and adv[0] == c)
                self.stats["followed" if followed else "ignored"] += 1
                self._log("played", card=str(c), advised=str(adv[0]) if adv else None,
                          followed=followed, why=adv[1] if adv else None)
        # взятка завершена
        if len(table) >= players and self.my_card in table:
            key = tuple(table)
            if key not in self.done_tricks:
                self.done_tricks.add(key)
                j = table.index(self.my_card)
                w = who_takes_trick(table, trump)
                allies = {0, 2} if self.mode == "2v2" else {0}
                won = ((w - j) % players) in allies
                self.last_trick = (key, w == j)       # (стол, взятку взял именно я)
                pts = sum(c.points(trump) for c in table)
                diff = pts if won else -pts
                self.stats["tricks"] += 1; self.stats["tricks_won"] += int(won); self.stats["points"] += diff
                if self.my_advice:
                    k = reason_key(self.my_advice[1])
                    s = self.stats["advice"].setdefault(k, {"n": 0, "win": 0, "pts": 0, "ign_n": 0, "ign_win": 0})
                    follow = self.my_advice[0] == self.my_card
                    if follow:
                        s["n"] += 1; s["win"] += int(won); s["pts"] += diff
                    else:
                        s["ign_n"] += 1; s["ign_win"] += int(won)
                self._log("trick", table=[str(c) for c in table], mine=str(self.my_card), won=won, pts=diff)
                try:
                    observe_complete_trick(tracker, list(table), self.my_card, trump)   # кто в какой масти пуст
                except Exception:
                    pass
                self.my_card = None; self.my_advice = None
                self.dirty += 1
                if self.dirty >= 2:
                    self.save(); self.dirty = 0
        self.prev_hand, self.prev_table = hand_set, list(table)

    def insight(self, why):
        """Строка для подсказки: как этот тип совета работал раньше."""
        s = self.stats["advice"].get(reason_key(why))
        if s and s["n"] >= 8:
            line = f"память: «{reason_key(why)}» брал взятку {100*s['win']//s['n']}% (n={s['n']}, ср. {s['pts']/s['n']:+.1f} очк.)"
            if s["ign_n"] >= 8:
                line += f"; когда играл иначе — {100*s['ign_win']//s['ign_n']}%"
            return line
        return None
