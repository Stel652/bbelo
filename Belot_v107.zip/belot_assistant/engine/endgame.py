# Точный разбор концовки: когда карт мало, неизвестные карты соперников — это известный набор (unseen).
# Перебираем все раздачи этого набора между соперниками и минимаксом выбираем ход с лучшим средним итогом.
import itertools, random
from .cards import Card
from .rules import can_play_card, who_takes_trick

def _splits(pool, sizes):
    """Все способы раздать pool по местам с заданными размерами (sizes: [(seat, n), ...])."""
    if not sizes:
        yield {}
        return
    (seat, n), rest = sizes[0], sizes[1:]
    for comb in itertools.combinations(pool, n):
        left = [c for c in pool if c not in comb]
        for tail in _splits(left, rest):
            d = {seat: comb}; d.update(tail); yield d

def solve(hand, table, trump, mode, unseen, lead_ok=True, max_deals=300, seed=1):
    """-> (card, avg_value, n_deals) либо None, если данных не хватает (тогда работает обычная эвристика)."""
    P = {"1v1": 2, "3p": 3, "2v2": 4}.get(mode, 4)
    n, h = len(table), len(hand)
    if n >= P or h == 0 or h > (2 if mode == "2v2" else 3):
        return None
    me = n
    sizes = [(s, (h - 1) if s < n else h) for s in range(P) if s != me]
    pool = list(unseen)
    if len(pool) != sum(k for _, k in sizes):
        return None            # счёт карт не сходится — не рискуем, используем эвристику
    team = (lambda s: s == me) if mode != "2v2" else (lambda s: s % 2 == me % 2)
    legal0 = [c for c in hand if can_play_card(c, list(table), hand, trump, lead_ok)]
    if not legal0:
        return None
    deals = list(_splits(pool, sizes))
    if len(deals) > max_deals:
        random.Random(seed).shuffle(deals); deals = deals[:max_deals]

    def search(hands, trick, seat):
        cards = [c for _, c in trick]
        hd = hands[seat]
        legal = [c for c in hd if can_play_card(c, cards, list(hd), trump, True)] or list(hd)
        best = None
        for c in legal:
            nh = dict(hands); nh[seat] = tuple(x for x in hd if x != c)
            nt = trick + [(seat, c)]
            if len(nt) == P:
                w = nt[who_takes_trick([x for _, x in nt], trump)][0]
                pts = sum(x.points(trump) for _, x in nt)
                if all(len(v) == 0 for v in nh.values()):
                    pts += 10
                val = pts if team(w) else -pts
                if any(len(v) for v in nh.values()):
                    val += search(nh, [], w)
            else:
                val = search(nh, nt, (seat + 1) % P)
            if best is None or (team(seat) and val > best) or (not team(seat) and val < best):
                best = val
        return best

    tbl = [(i, c) for i, c in enumerate(table)]
    totals = {c: 0 for c in legal0}
    for d in deals:
        hands = {s: tuple(v) for s, v in d.items()}; hands[me] = tuple(hand)
        for c in legal0:
            nh = dict(hands); nh[me] = tuple(x for x in hand if x != c)
            nt = tbl + [(me, c)]
            if len(nt) == P:
                w = nt[who_takes_trick([x for _, x in nt], trump)][0]
                pts = sum(x.points(trump) for _, x in nt) + (10 if all(len(v) == 0 for v in nh.values()) else 0)
                v = pts if team(w) else -pts
                if any(len(x) for x in nh.values()):
                    v += search(nh, [], w)
            else:
                v = search(nh, nt, (me + 1) % P)
            totals[c] += v
    best = max(legal0, key=lambda c: (totals[c], -c.strength(trump)))
    return best, totals[best] / len(deals), len(deals)
