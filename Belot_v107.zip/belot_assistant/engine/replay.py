"""Проверка записанной раздачи самоигры: восстанавливает ход игры из rounds.jsonl
и проверяет колоду, легальность каждого хода, победителя взятки и сумму очков."""
from .cards import Card
from .rules import can_play_card, who_takes_trick

SYM = {"♥": "hearts", "♦": "diamonds", "♣": "clubs", "♠": "spades"}

def parse(s):
    return Card(SYM[s[-1]], s[:-1])

def verify_round(rec):
    """Возвращает список проблем (пусто = раздача записана и воспроизводится корректно)."""
    if "hands" not in rec or "moves" not in rec:
        return ["запись без полной последовательности ходов"]
    problems, trump = [], rec["trump"]
    hands = [[parse(c) for c in h] for h in rec["hands"]]
    allc = [c for h in hands for c in h]
    if len(set(allc)) != 32:
        problems.append("в раздаче не 32 уникальные карты")
    pts = [0, 0]
    for tr in rec["tricks"]:
        table = []
        mv = [m for m in rec["moves"] if m[0] == tr["n"]]
        for _, p, cs, _why in mv:
            c = parse(cs)
            if c not in hands[p]:
                problems.append(f"взятка {tr['n']}: карты {cs} нет у игрока {p}")
                continue
            tla = (p == rec["declarer"] or tr["n"] > 0)
            if not can_play_card(c, table, hands[p], trump, tla):
                problems.append(f"взятка {tr['n']}: нелегальный ход {cs} игрока {p}")
            hands[p].remove(c); table.append(c)
        order = [m[1] for m in mv]
        if table and order[who_takes_trick(table, trump)] != tr["winner"]:
            problems.append(f"взятка {tr['n']}: неверный победитель")
        w = tr["winner"] % 2
        pts[w] += sum(c.points(trump) for c in table) + (10 if tr["n"] == 7 else 0)
    if pts != list(rec["pts"]):
        problems.append(f"очки не сходятся: {pts} vs {rec['pts']}")
    return problems
