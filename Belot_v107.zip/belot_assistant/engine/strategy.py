# engine/strategy.py
from typing import List, Optional, Tuple
from .cards import Card
from .rules import can_play_card, who_takes_trick
from .combinations import detect_combinations, best_combination, total_points
from .hand_eval import evaluate_hand
from .tracker import is_master, trumps_left

def evaluate_hand_for_trump(hand, trump):
    score, notes = evaluate_hand(hand, trump)
    return score, ", ".join(notes)

def should_play_strict(hand: List[Card], trump: str, min_score: int = 50, behind_bile: int = 0):
    """Осторожные торги для игры БЕЗ партнёра (3 игрока): играющий обязан набрать больше каждого соперника,
    иначе «болт» (BT). Поэтому слабые руки (3 козыря без J, 4 мелких козыря, «тузы вместо козырей») — Pas.
    Joc только если козырь реально держит раздачу."""
    trumps = [c for c in hand if c.is_trump(trump)]
    n = len(trumps)
    has_j = any(c.rank == "J" for c in trumps)
    has_9 = any(c.rank == "9" for c in trumps)
    has_a = any(c.rank == "A" for c in trumps)
    side_aces = sum(1 for c in hand if c.rank == "A" and not c.is_trump(trump))
    score, reason = evaluate_hand_for_trump(hand, trump)
    # на втором круге/в конце торга «behind_bile» отстающему разрешает чуть рискнуть
    risk_bonus = 5 if behind_bile <= -5 else 0
    if n >= 6:                          return True, f"Joc: {n} козырей, полный контроль"
    if n >= 5 and (has_j or has_9):     return True, f"Joc: {n} козырей с J/9"
    if n >= 5 and has_a and score >= 55 - risk_bonus: return True, f"Joc: {n} козырей с тузом ({score})"
    if n == 4 and has_j and (has_9 or has_a or side_aces >= 1): return True, f"Joc: 4 козыря с J и поддержкой ({reason})"
    if n == 4 and has_j and has_9:      return True, "Joc: 4 козыря J+9"
    if n == 3 and has_j and has_9 and (has_a or side_aces >= 1): return True, "Joc: 3 козыря J+9 + туз"
    return False, f"Pas ({score}): {n} козыр., слабая рука для игры без партнёра"


def should_play(hand: List[Card], trump: str, min_score: int = 50, behind_bile: int = 0, mode: str = "2v2"):
    """Joc / Pas по правилам торга: 6+ козырей — Joc; 5+ с J/9 — Joc; 4 мелких — только с комбинацией;
    3 козыря — только с Bella; 2 и меньше — Pas."""
    if mode == "3p":
        return should_play_strict(hand, trump, min_score, behind_bile)
    trumps = [c for c in hand if c.is_trump(trump)]
    n = len(trumps)
    big = any(c.rank in ("J", "9") for c in trumps)
    combs = detect_combinations(hand, trump)
    bella = any(x[0] == "bella" for x in combs)
    seq = any(x[0] in ("tertz", "half_hundred", "hundred") or x[0].startswith("four_") for x in combs)
    score, reason = evaluate_hand_for_trump(hand, trump)
    if n >= 6:            return True, f"Joc: {n} козырей, полный контроль"
    if n >= 5 and big:    return True, f"Joc: {n} козырей с J/9"
    if n == 4 and big:    return True, f"Joc: 4 козыря с J/9 ({reason})"
    if n == 4 and seq:    return True, f"Joc: 4 мелких козыря + комбинация"
    if n == 3 and bella:  return True, "Joc: 3 козыря + Bella (20 очков)"
    # v19 (K6/K10/K11/A6/K30/K33): тузы и крупные комбинации компенсируют нехватку козырей
    aces = sum(1 for c in hand if c.rank == "A" and not c.is_trump(trump))
    cp = total_points(combs, trump)
    if n == 4 and aces >= 2:  return True, f"Joc: 4 козыря + {aces} туза"
    if n == 4 and bella:      return True, "Joc: 4 козыря + Bella"
    if n == 3 and aces >= 3:  return True, "Joc: 3 козыря + 3 туза"
    if n == 3 and aces >= 2 and cp >= 20: return True, "Joc: 3 козыря + 2 туза + комбинация"
    if n == 3 and cp >= 50:   return True, f"Joc: 3 козыря + комбинация {cp}"
    if n <= 2:            return False, f"Pas: всего {n} козырей"
    thr = min_score - (10 if behind_bile >= 5 else 0) + (5 if behind_bile <= -5 else 0)
    if score >= thr:     return True, f"Joc ({score}): {reason}"
    return False, f"Pas ({score}): {reason}"

def best_suit(hand: List[Card]):
    """Лучшая масть для выбора козыря (2-й тур): (масть, оценка)."""
    best = None
    for s in ("spades", "hearts", "diamonds", "clubs"):
        sc, _ = evaluate_hand(hand, s)
        if best is None or sc > best[1]:
            best = (s, sc)
    return best

def choose_card(hand: List[Card], table: List[Card], trump: str,
                is_partner_winning: bool, trump_lead_allowed: bool) -> Optional[Card]:
    valid = [c for c in hand if can_play_card(c, table, hand, trump, trump_lead_allowed)]
    if not valid:
        return None

    # Первый ход
    if not table:
        trumps = [c for c in valid if c.is_trump(trump)]
        if trumps:
            return min(trumps, key=lambda c: c.strength(trump))
        return max(valid, key=lambda c: c.strength(trump))

    # Партнёр берёт — скидываем очки
    if is_partner_winning:
        return max(valid, key=lambda c: c.points(trump))

    # Пытаемся взять
    for c in valid:
        new_table = table + [c]
        if who_takes_trick(new_table, trump) == len(new_table) - 1:
            # Из тех, что берут, выбираем минимально ценную
            winners = [x for x in valid if who_takes_trick(table + [x], trump) == len(table)]
            if winners:
                return min(winners, key=lambda x: x.points(trump))
            return c

    # Не можем взять — скидываем младшую
    return min(valid, key=lambda c: c.strength(trump))


def _cheapest_safe_winner(winning, hand, table, trump, master, last_to_play):
    """Среди карт, берущих взятку: если я хожу не последним — беру ВЕРНОЙ (старшей, мастер) картой,
    а не дешёвой, которую могут перебить (A+10 на руке -> иду тузом, 10 остаётся мастером).
    Если последний — самой дешёвой."""
    key = lambda c: (c.points(trump), c.strength(trump))
    non_tr = [c for c in winning if not c.is_trump(trump)]
    # A и 10 одной не-козырной масти оба берут -> всегда тузом (10 становится старшей после туза)
    for c in non_tr:
        if c.rank == "A" and any(x.suit == c.suit and x.rank == "10" for x in winning):
            return c
    if not last_to_play:
        sure = [c for c in winning if master(c)]
        if sure:
            return min(sure, key=key)
        # не мастер: старшая из берущих той же масти надёжнее дешёвой десятки
        best = max(winning, key=lambda c: c.strength(trump))
        cheap = min(winning, key=key)
        if cheap.rank == "10" and best.suit == cheap.suit and best.rank == "A":
            return best
        return cheap
    return min(winning, key=key)

LEAD_LOW_NO_TRUMP = True   # заход без козырей, когда козырь объявил соперник: младшая карта

def _heuristic_recommend(hand, table, trump, mode, trump_lead_allowed=True,
                       is_partner_winning=False, snap=None, i_declared=False,
                       last_to_play=False, voids=None, risk="normal", lead_style="small"):
    """Легальная рекомендация по принципам профессионала.

    snap — снимок трекера (счёт карт); i_declared — я объявил козырь;
    last_to_play — я хожу последним во взятке (тогда выигрыш партнёра надёжен).
    """
    if not hand:
        return None, "Карты в руке не распознаны — проверь область захвата"
    valid = [c for c in hand if can_play_card(c, table, hand, trump, trump_lead_allowed)]
    if not valid:
        return None, "Не удалось определить допустимый ход: проверь порядок карт на столе"
    master = (lambda c: is_master(c, snap, trump)) if snap else (lambda c: False)
    pts = lambda c: c.points(trump)

    if not table:
        trumps = [c for c in valid if c.is_trump(trump)]
        sides = [c for c in valid if not c.is_trump(trump)]
        opp_trumps = len(trumps_left(snap, trump)) if snap else 1
        opp_void = set()
        if voids:      # масти, которые соперник (слева/справа) уже не имеет -> он их порежет
            opp_void = (voids.get(1, set()) | voids.get(3, set()))
        both_no_trump = bool(voids) and trump in voids.get(1, set()) and trump in voids.get(3, set())
        if both_no_trump:
            opp_trumps = 0
        # Я объявил козырь: начинаю с самого большого — валета, если он у меня есть (затем старший мастер)
        if i_declared and trumps and opp_trumps > 0:
            jack = [c for c in trumps if c.rank == "J"]
            if jack:
                return jack[0], "объявил козырь — начинаю с валета"
            nine = [c for c in trumps if c.rank == "9"]
            j_out = bool(snap) and not any(u.suit == trump and u.rank == "J" for u in snap["unseen"])
            if nine and j_out:      # с 9 иду ТОЛЬКО если валет уже вышел (иначе соперник заберёт её валетом)
                return nine[0], "объявил козырь — валет вышел, 9 старшая: иду с 9"
            top = max(trumps, key=lambda c: c.strength(trump))
            if master(top):
                return top, "объявил козырь — тяну старшим козырем"
        # Тянуть козырь: 4+ козырей. Стиль: младший (J берегу) / старший. «risky» — тяну агрессивно.
        if i_declared and trumps and opp_trumps > 0 and (len(trumps) >= 4 or (risk == "risky" and len(trumps) >= 3)):
            if lead_style == "high" or risk == "risky" and any(master(c) for c in trumps):
                return max(trumps, key=lambda c: c.strength(trump)), "тяну козырь старшим"
            non_j = [c for c in trumps if c.rank != "J"] or trumps
            return min(non_j, key=lambda c: c.strength(trump)), "тяну козырь младшим, J берегу"
        sides_ok = [c for c in sides if c.suit not in opp_void] or sides
        sides = sides_ok
        # Козырь объявил не я, у меня козырей нет, у соперников они есть: тузы и десятки на заходе
        # режутся козырем — иду самой младшей картой (очков не отдаю, ничего не подставляю).
        if LEAD_LOW_NO_TRUMP and not i_declared and not trumps and opp_trumps > 0 and sides and len(hand) > 1:
            return min(sides, key=lambda c: (pts(c), c.strength(trump))), "козырей нет, козырь у соперников — иду младшей"
        # B3: 2-3 козыря — не тяну; боковая масть с A/10, длинная масть — приоритет
        def suit_len(c): return sum(1 for x in hand if x.suit == c.suit)
        side_masters = [c for c in sides if master(c)] or [c for c in sides if c.rank == "A"]
        if side_masters:
            pick = max(side_masters, key=lambda c: (suit_len(c), pts(c)))
            return pick, "A/10 длинной масти — верная взятка" if suit_len(pick) >= 4 else "старшая карта масти — верная взятка"
        if sides:
            return min(sides, key=lambda c: (pts(c), c.strength(trump))), "лёгкий ход, козыри берегу"
        non_j = [c for c in trumps if c.rank != "J"] or trumps
        return min(non_j, key=lambda c: (pts(c), c.strength(trump))), "только козыри — младший"

    winner_idx = who_takes_trick(table, trump)
    winning_card = table[winner_idx]
    winning = [c for c in valid if who_takes_trick(table + [c], trump) == len(table)]
    partner_secure = is_partner_winning and (last_to_play or master(winning_card))

    if is_partner_winning:
        if partner_secure:
            # Не перебиваю партнёра — отдаю очки (A, 10), по возможности не козырем
            pick = max(valid, key=lambda c: (not c.is_trump(trump), pts(c), -c.strength(trump)))
            return pick, "партнёр берёт — отдаю очки"
        # Партнёр лидирует, но его могут перебить: беру сам, если дёшево, иначе даю очки
        if winning and len(table) < 3:
            pick = _cheapest_safe_winner(winning, hand, table, trump, master, last_to_play)
            return pick, "подстраховываю партнёра дёшево"
        pick = max(valid, key=lambda c: (not c.is_trump(trump), pts(c), -c.strength(trump)))
        return pick, "партнёр лидирует — отдаю очки"

    if winning:
        pick = _cheapest_safe_winner(winning, hand, table, trump, master, last_to_play)
        reason = "режу козырем" if pick.is_trump(trump) and not table[0].is_trump(trump) else "беру дёшево"
        return pick, reason
    return min(valid, key=lambda c: (pts(c), c.strength(trump))), "не беру — сбрасываю младшую"


def recommend_for_mode(hand, table, trump, mode, trump_lead_allowed=True,
                       is_partner_winning=False, snap=None, i_declared=False,
                       last_to_play=False, voids=None, risk="normal", lead_style="small",
                       use_mc=True, budget=0.35, max_samples=500):
    """Трёхуровневый выбор: L1 матрица правил -> L2 evaluation -> L3 Monte Carlo (только в сложных позициях)."""
    if snap is not None and 0 < len(hand) <= 3:
        try:
            from .endgame import solve
            r = solve(hand, table, trump, mode, snap["unseen"], trump_lead_allowed)
            if r:
                return r[0], f"точный разбор концовки ({r[2]} раскладов, {r[1]:+.0f})"
        except Exception:
            pass
    pick, reason = _heuristic_recommend(hand, table, trump, mode, trump_lead_allowed, is_partner_winning,
                                        snap, i_declared, last_to_play, voids, risk, lead_style)
    if pick is None or snap is None or reason.startswith("объявил козырь"):
        return pick, reason
    if reason.startswith("не беру — сбрасываю младшую"):
        return pick, reason  # чистый сброс: Monte Carlo не должен подменять младшую карту
    from .decision import decide
    master = (lambda c: is_master(c, snap, trump))
    ctx = dict(hand=hand, table=table, trump=trump, snap=snap, partner_winning=is_partner_winning,
               partner_secure=is_partner_winning and (last_to_play or (bool(table) and master(table[who_takes_trick(table, trump)]))),
               last_to_play=last_to_play, declared=i_declared, risk=risk, voids=voids, mode=mode)
    best, note, hard = decide(hand, table, trump, mode, ctx, trump_lead_allowed, prior=pick,
                              use_mc=use_mc, budget=budget, max_samples=max_samples)
    if best is None:
        return pick, reason
    if best == pick:
        return pick, reason + (f" · {note}" if note.startswith("L3") else "")
    return best, f"{note} (эвристика советовала {pick})"
