"""Счёт карт (card counting): что вышло, что осталось, у кого могут быть козыри.
Точные руки соперников не выдумываются — только пул неизвестных карт."""
import time
from collections import Counter
from .cards import Card, SUITS, RANKS_BY_DECK

RANKS = ("7", "8", "9", "10", "J", "Q", "K", "A")
FULL_DECK = {Card(s, r) for s in SUITS for r in RANKS}

def deck_for_mode(mode):
    """2v2 — 32 карты (7..A); 1v1 и 3p — 24 карты (9..A)."""
    return {Card(s, r) for s in SUITS for r in RANKS_BY_DECK[32 if mode == "2v2" else 24]}

class CardTracker:
    def __init__(self, mode="2v2"):
        self.mode = mode
        self.deck = deck_for_mode(mode)
        self.reset(); self._last_reset_t = 0.0; self.reset_log = []

    def can_reset(self, min_gap=6.0):
        """Не сбрасываем раздачу чаще, чем раз в min_gap секунд (ложные сбросы стирали память и мигали)."""
        return time.time() - getattr(self, "_last_reset_t", 0.0) > min_gap

    def reset(self, reason="manual"):
        self._last_reset_t = time.time()
        self.reset_log = (getattr(self, "reset_log", []) + [(round(time.time(), 2), reason)])[-50:]
        self.rounds = getattr(self, 'rounds', -1) + 1
        self.seen = set()          # карты, реально вышедшие на стол в этом раунде
        self.hand_history = set()
        self.trick_history = []
        self.voids = {1: set(), 2: set(), 3: set()}   # 1=слева, 2=партнёр, 3=справа -> масти, которых у него нет
        self._done_tricks = set()
        self.closed = set()        # карты ЗАВЕРШЁННЫХ взяток: повторно в этой раздаче появиться не могут
        self._prev_table = []

    @property
    def players(self):
        return {"1v1": 2, "3p": 3, "2v2": 4}.get(self.mode, 4)

    @property
    def tricks_done(self):
        return len(self.closed) // self.players

    def twin_of(self, card):
        """Для ♠/♣: та же карта другой чёрной масти (главная путаница распознавания)."""
        if card.suit not in ("clubs", "spades"):
            return None
        return Card("spades" if card.suit == "clubs" else "clubs", card.rank)

    def fix_black(self, cards_pos, forbid=(), protect=()):
        """Карту, которой уже не может быть (вышла в закрытой взятке / лежит в forbid), заменяем двойником ♠↔♣;
        если двойник тоже невозможен — отбрасываем.
        protect — карты, надёжно читаемые на многих кадрах подряд: им верим больше, чем записи о «закрытых» взятках
        (она могла набраться из неверно прочитанного стола) — такую карту не переворачиваем, а запись исправляем."""
        out = []
        for c, p in cards_pos:
            if c in protect:
                if c in self.closed:
                    self.closed.discard(c)      # самоисцеление: стабильная карта в руке не может быть «уже сыгранной»
                out.append((c, p)); continue
            if c in self.closed or c in forbid:
                t = self.twin_of(c)
                if t is not None and t in self.deck and t not in self.closed and t not in forbid:
                    c = t
                else:
                    continue
            out.append((c, p))
        return out

    def update(self, hand, table):
        hand_set, table_set = set(hand), set(table)
        prev = self._prev_table
        if prev and not set(prev) <= table_set and len(prev) >= self.players:
            self.closed |= set(prev)          # стол убрали — взятка закрыта
        self._prev_table = list(table)
        # моя карта числится вышедшей, но снова лежит в руке -> новая раздача
        inter = hand_set & self.seen
        if inter:
            self._hs_cnt = getattr(self, "_hs_cnt", 0) + 1
            # Единственное пересечение по ЧЁРНОЙ карте при короткой руке (<7) — почти всегда путаница ♣/♠: ждём ~2 с (4 кадра).
            # Красные карты, 2+ пересечений или полная рука — настоящая новая раздача, сброс сразу, как раньше.
            only_black_single = len(inter) == 1 and all(c.suit in ("clubs", "spades") for c in inter)
            strong = (not only_black_single) or len(hand_set) >= 7 or self._hs_cnt >= 4
            if strong and self.can_reset():
                self.reset("hand∩seen:" + ",".join(sorted(str(c) for c in inter)))
                self._hs_cnt = 0
            elif not strong:
                self.suppressed_log = (getattr(self, "suppressed_log", []) + [(round(time.time(), 2), "hand∩seen(1): " + ",".join(str(c) for c in inter))])[-50:]
        else:
            self._hs_cnt = 0
        self.hand_history |= hand_set
        self.seen |= table_set
        self.seen |= (self.hand_history - hand_set) & table_set
        return self.snapshot(hand_set, table_set)

    def snapshot(self, hand=None, table=None):
        hand, table = set(hand or ()), set(table or ())
        known = self.seen | hand | table
        unseen = self.deck - known
        by_suit = Counter(c.suit for c in unseen)
        return {
            "unseen_count": len(unseen), "unseen": unseen, "suit_counts": dict(by_suit),
            "suit_probability": {s: (by_suit[s] / len(unseen) if unseen else 0.0) for s in SUITS},
            "known_played": len(self.seen),
        }

# ---------- функции поверх снимка ----------
def trumps_left(snap, trump):
    """Козыри, которые ещё могут быть у остальных игроков."""
    return sorted((c for c in snap["unseen"] if c.suit == trump), key=lambda c: -c.strength(trump))

def high_cards_left(snap):
    return [c for c in snap["unseen"] if c.rank in ("A", "10", "J", "9")]

def points_left(snap, trump):
    """Сколько очков карт ещё у остальных (без 10 за последнюю взятку)."""
    return sum(c.points(trump) for c in snap["unseen"])

def is_master(card, snap, trump):
    """Карта — старшая из ещё не вышедших в своей масти (козырь — среди козырей)."""
    return not any(u.suit == card.suit and u.strength(trump) > card.strength(trump)
                   for u in snap["unseen"])

def observe_complete_trick(tracker, table, my_card, trump):
    """Полная взятка + моя карта в ней -> места известны (я=0, слева=1, партнёр=2, справа=3).
    Кто не ответил в масть — у того этой масти нет (и козыря, если он не козырял)."""
    players = len(table)
    key = tuple(table)
    if key in tracker._done_tricks or my_card not in table or players < 3:
        return
    tracker._done_tricks.add(key)
    j = table.index(my_card)
    lead = table[0].suit
    for i, c in enumerate(table):
        rel = (i - j) % players
        if i == 0 or rel == 0 or rel not in tracker.voids:
            continue
        if c.suit != lead:
            tracker.voids[rel].add(lead)
            if c.suit != trump:
                tracker.voids[rel].add(trump)
