"""Decision Tracker: каждый совет получает уникальный decision_id и связывается
с фактически сыгранной картой и итогом взятки. Пишется в data/decisions.jsonl."""
import os, json, time, uuid
from .cards import Card
from .rules import can_play_card, who_takes_trick

LOG = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "decisions.jsonl")


def legal_moves(hand, table, trump):
    """Допустимые ходы по правилам проекта (rules.can_play_card)."""
    return [c for c in hand if can_play_card(c, list(table), list(hand), trump, True)]


class DecisionTracker:
    def __init__(self, mode="2v2", path=LOG):
        self.mode, self.path = mode, path
        self.pending = None      # последнее решение, ожидающее сыгранной карты
        self.open = {}           # decision_id -> запись, ждущая итога взятки
        self.stats = {"advice": 0, "followed": 0, "ignored": 0, "won": 0, "lost": 0,
                      "illegal_advice": 0}

    def _write(self, rec):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
        except Exception:
            pass

    def record(self, hand, table, trump, move, why, score=None):
        """Новый совет. Одинаковый совет на тех же картах подряд не дублируется."""
        if move is None:
            return None
        sig = (tuple(map(str, hand)), tuple(map(str, table)), str(move))
        if self.pending and self.pending["sig"] == sig:
            return self.pending["decision_id"]
        legal = legal_moves(hand, table, trump)
        rec = {"ev": "decision", "decision_id": uuid.uuid4().hex[:12], "t": round(time.time(), 3),
               "mode": self.mode, "hand": [str(c) for c in hand], "table": [str(c) for c in table],
               "trump": trump, "score": list(score) if score else None,
               "legal": [str(c) for c in legal], "move": str(move), "why": why,
               "move_legal": (move in legal) if legal else None,
               "alternatives": [str(c) for c in legal if c != move]}
        self.stats["advice"] += 1
        if rec["move_legal"] is False:
            self.stats["illegal_advice"] += 1
        self.pending = dict(rec, sig=sig)
        self._write(rec)
        return rec["decision_id"]

    def link_played(self, card):
        """Игрок сыграл карту: фиксируем, послушался ли он совета."""
        p = self.pending
        if not p or p.get("played"):
            return None
        p["played"] = str(card)
        followed = str(card) == p["move"]
        self.stats["followed" if followed else "ignored"] += 1
        self.open[p["decision_id"]] = p
        self._write({"ev": "played", "decision_id": p["decision_id"], "card": str(card),
                     "followed": followed, "t": round(time.time(), 3)})
        self.pending = None
        return p["decision_id"]

    def resolve_trick(self, table, my_card, trump):
        """Полная взятка: определяем, забрали ли её мы (я или партнёр в 2v2), и очки."""
        if my_card not in table:
            return None
        did = next((d for d, r in self.open.items() if r.get("played") == str(my_card)), None)
        if did is None:
            return None
        n = len(table)
        win = who_takes_trick(table, trump)
        j = table.index(my_card)
        rel = (win - j) % n
        mine = rel == 0 or (n == 4 and rel == 2)
        pts = sum(c.points(trump) for c in table)
        rec = self.open.pop(did)
        self.stats["won" if mine else "lost"] += 1
        self._write({"ev": "outcome", "decision_id": did, "trick_won": mine, "winner_rel": rel,
                     "trick_points": pts, "followed": rec["played"] == rec["move"],
                     "t": round(time.time(), 3)})
        return {"decision_id": did, "won": mine, "points": pts}

    def summary(self):
        s = dict(self.stats)
        done = s["won"] + s["lost"]
        s["trick_win_rate"] = round(s["won"] / done, 3) if done else None
        return s

    def resolve_from_table(self, table, trump):
        """Полная взятка на столе: ищем открытое решение, чья сыгранная карта лежит в ней."""
        for r in list(self.open.values()):
            res = self.resolve_trick(list(table), Card(*self._split(r["played"])), trump) if r.get("played") else None
            if res:
                return res
        return None

    @staticmethod
    def _split(s):
        return {"♥": "hearts", "♦": "diamonds", "♣": "clubs", "♠": "spades"}[s[-1]], s[:-1]
