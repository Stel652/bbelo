@echo off
cd /d "%~dp0"
set PY=.venv\Scripts\python.exe
if not exist %PY% set PY=python
echo === Belot bot self-play training: endless ===
echo Runs separately, low priority. close window or Ctrl+C to stop, progress is saved.
%PY% train_selfplay.py 0
echo.
echo Results: data\selfplay\report.txt
pause
