"""Импорт JSONL в SQLite (data/belot.db). JSONL остаётся архивом. Запуск: python database/db.py"""
import os, sys, json, sqlite3
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCHEMA = """
CREATE TABLE IF NOT EXISTS decisions(decision_id TEXT PRIMARY KEY, t REAL, mode TEXT, trump TEXT, hand TEXT,
  tbl TEXT, legal TEXT, move TEXT, why TEXT, move_legal INTEGER, played TEXT, followed INTEGER);
CREATE TABLE IF NOT EXISTS outcomes(decision_id TEXT PRIMARY KEY, trick_won INTEGER, trick_points INTEGER);
CREATE TABLE IF NOT EXISTS sp_rounds(id INTEGER PRIMARY KEY AUTOINCREMENT, trump TEXT, declarer INTEGER, pts0 INTEGER, pts1 INTEGER, data TEXT);
"""
def connect(path=None):
    c = sqlite3.connect(path or os.path.join(HERE, "data", "belot.db")); c.executescript(SCHEMA); return c

def _lines(p):
    if not os.path.exists(p): return
    for l in open(p, encoding="utf-8"):
        try: yield json.loads(l)
        except Exception: pass

def import_all(con, data=None):
    data = data or os.path.join(HERE, "data")
    for e in _lines(os.path.join(data, "decisions.jsonl")):
        j = lambda v: json.dumps(v, ensure_ascii=False)
        if e["ev"] == "decision":
            con.execute("INSERT OR IGNORE INTO decisions(decision_id,t,mode,trump,hand,tbl,legal,move,why,move_legal) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (e["decision_id"], e["t"], e["mode"], e["trump"], j(e["hand"]), j(e["table"]), j(e["legal"]), e["move"], e["why"], e["move_legal"]))
        elif e["ev"] == "played":
            con.execute("UPDATE decisions SET played=?, followed=? WHERE decision_id=?", (e["card"], int(e["followed"]), e["decision_id"]))
        elif e["ev"] == "outcome":
            con.execute("INSERT OR REPLACE INTO outcomes VALUES(?,?,?)", (e["decision_id"], int(e["trick_won"]), e["trick_points"]))
    if con.execute("SELECT COUNT(*) FROM sp_rounds").fetchone()[0] == 0:
        for r in _lines(os.path.join(data, "selfplay", "rounds.jsonl")):
            con.execute("INSERT INTO sp_rounds(trump,declarer,pts0,pts1,data) VALUES(?,?,?,?,?)",
                (r.get("trump"), r.get("declarer"), r["pts"][0], r["pts"][1], json.dumps(r, ensure_ascii=False)))
    con.commit()

if __name__ == "__main__":
    con = connect(); import_all(con)
    print({t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("decisions", "outcomes", "sp_rounds")})
