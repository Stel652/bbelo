@echo off
setlocal
title Belot Assistant - Dependency Installer

cd /d "%~dp0"

echo ==========================================
echo   Belot Assistant - Installing packages
echo ==========================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON=py"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo ERROR: Python was not found.
        echo Install Python 3.10 or newer from https://www.python.org/downloads/
        echo During installation, enable "Add Python to PATH".
        pause
        exit /b 1
    )
    set "PYTHON=python"
)

echo [1/3] Checking Python...
%PYTHON% --version
if errorlevel 1 goto :error

echo.
echo [2/3] Creating virtual environment...
if not exist ".venv\Scripts\python.exe" (
    %PYTHON% -m venv .venv
    if errorlevel 1 goto :error
)

echo.
echo [3/3] Installing required packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :error

".venv\Scripts\python.exe" -m pip install "PyQt6>=6.6.0" "opencv-python>=4.8.0" "numpy>=1.26.0" "mss>=9.0.1" "pynput>=1.7.6"
if errorlevel 1 goto :error

echo.
echo ==========================================
echo   Installation completed successfully!
echo ==========================================
echo.
echo To start the project, run:
echo   .venv\Scripts\python.exe main.py
echo.
pause
exit /b 0

:error
echo.
echo INSTALLATION FAILED.
echo Check your internet connection and Python installation, then run this file again.
pause
exit /b 1
