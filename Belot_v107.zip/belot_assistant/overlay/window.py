# overlay/window.py
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt, QTimer, QPointF, QRect
from PyQt6.QtGui import QPainter, QColor, QPen, QBrush, QFont, QPolygonF
import config

class OverlayWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.WindowStaysOnTopHint |
                            Qt.WindowType.FramelessWindowHint |
                            Qt.WindowType.Tool |
                            Qt.WindowType.WindowTransparentForInput)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.showFullScreen()
        self._exclude_from_capture()
        self.recommendation = None
        self.debug = False
        QTimer(self, timeout=self.update, interval=50).start()

    def _exclude_from_capture(self):
        """Windows 10 2004+: окно подсказки не попадает в скриншоты (mss), иначе панель закрывала карты руки в зоне распознавания."""
        try:
            import sys, ctypes
            if sys.platform == "win32":
                WDA_EXCLUDEFROMCAPTURE = 0x11
                ok = ctypes.windll.user32.SetWindowDisplayAffinity(int(self.winId()), WDA_EXCLUDEFROMCAPTURE)
                self.capture_excluded = bool(ok)
        except Exception:
            self.capture_excluded = False

    def set_recommendation(self, rec): self.recommendation = rec; self.update()
    def toggle_debug(self): self.debug = not self.debug; self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        if self.debug:
            p.setPen(QPen(QColor(255, 255, 0, 150), 2))
            screen=self.screen()
            sw,sh=(screen.geometry().width(),screen.geometry().height()) if screen else (1920,1080)
            for z in [config.scaled_zone(config.ZONE_MY_HAND,sw,sh),config.scaled_zone(config.ZONE_TABLE,sw,sh),config.scaled_zone(config.ZONE_TRUMP,sw,sh),config.scaled_zone(config.ZONE_DECLARER_NAME,sw,sh)]:
                p.drawRect(*z)
        if not self.recommendation:
            return
        rec = self.recommendation
        x, y = rec["position"]
        SYM = {"hearts": "♥", "diamonds": "♦", "clubs": "♣", "spades": "♠"}
        COL = {"hearts": QColor(255, 90, 90), "diamonds": QColor(255, 175, 60),
               "clubs": QColor(90, 225, 125), "spades": QColor(130, 185, 255)}
        WHITE, GREY = QColor(*config.COLOR_TEXT), QColor(170, 180, 190)
        # строки: список сегментов (текст, цвет, размер)
        def cards(label, lst):
            segs = [(label + " ", GREY, 11)]
            segs += [(f"{c.rank}{SYM[c.suit]}  ", COL[c.suit], 15) for c in lst] or [("—", GREY, 11)]
            return segs
        if "hand" not in rec:
            lines = [[(rec.get("text", ""), WHITE, 12)]]
        else:
            NAME = {"hearts": "ЧЕРВЫ", "diamonds": "БУБНЫ", "clubs": "ТРЕФЫ", "spades": "ПИКИ"}
            tr = rec.get("trump")
            lines = []
            if tr in SYM:
                seg = [("КОЗЫРЬ ", GREY, 11), (SYM[tr], COL[tr], 26), ("  " + NAME[tr], COL[tr], 14)]
                dk = rec.get("declarer")
                if dk is True:
                    seg.append(("   выбрал: Я ✓", QColor(76, 217, 100), 12))
                elif dk is False:
                    seg.append(("   выбрал: не я", QColor(255, 179, 64), 12))
                else:
                    seg.append(("   выбрал: ?", GREY, 11))
                lines.append(seg)
            lines.append(cards("МОИ", rec["hand"]))
            if rec["table"]:
                lines.append(cards("СТОЛ", rec["table"]))
            if rec.get("info"):
                for t in rec["info"]:
                    lines.append([(t, GREY, 10)])
            mv = rec["move"]
            if mv:
                lines.append([("ХОД ▶ ", GREY, 12), (f"{mv.rank}{SYM[mv.suit]}", COL[mv.suit], 24),
                              ("   " + rec["why"], WHITE, 11)])
            else:
                lines.append([(rec["why"], QColor(255, 200, 80), 12)])
        # измеряем
        def seg_w(seg):
            f = QFont("Segoe UI", seg[2], QFont.Weight.Bold); p.setFont(f)
            return p.fontMetrics().horizontalAdvance(seg[0])
        widths = [sum(seg_w(s) for s in ln) for ln in lines]
        heights = [max(s[2] for s in ln) * 2 + 4 for ln in lines]
        box_w, box_h = max(widths) + 28, sum(heights) + 16
        px = max(8, min(self.width() - box_w - 8, x - box_w // 2))
        py = max(8, min(self.height() - box_h - 8, y))
        # панель не должна заходить на зону руки (запасная защита, если исключение из захвата недоступно)
        try:
            screen = self.screen()
            sw_, sh_ = (screen.geometry().width(), screen.geometry().height()) if screen else (self.width(), self.height())
            hz = config.scaled_zone(config.ZONE_MY_HAND, sw_, sh_)
            if py + box_h > hz[1] - 6:
                py = max(8, hz[1] - box_h - 6)
        except Exception:
            pass
        p.setBrush(QBrush(QColor(*config.COLOR_BG)))
        p.setPen(QPen(QColor(*config.COLOR_ACCENT), 2))
        p.drawRoundedRect(px, py, box_w, box_h, 10, 10)
        cy = py + 8
        for ln, h in zip(lines, heights):
            cx = px + 14
            for seg in ln:
                p.setFont(QFont("Segoe UI", seg[2], QFont.Weight.Bold)); p.setPen(QPen(seg[1]))
                p.drawText(cx, cy + h - 8, seg[0]); cx += p.fontMetrics().horizontalAdvance(seg[0])
            cy += h
