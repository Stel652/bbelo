# overlay/widgets.py
"""Заготовка для дополнительных элементов интерфейса.

В исходном тексте код overlay/widgets.py отсутствовал.
Основной OverlayWindow реализован в overlay/window.py.
"""
