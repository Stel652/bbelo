# calibrate.py — Belot Assistant calibration (Windows)
# Instalare:
#   python -m pip install mss opencv-python numpy

import os
import sys
import traceback
from pathlib import Path

try:
    import mss
    import cv2
    import numpy as np
except ImportError as exc:
    print("\n[EROARE] Lipseste o biblioteca:", exc)
    print("Ruleaza: python -m pip install mss opencv-python numpy")
    input("\nApasa ENTER pentru inchidere...")
    raise SystemExit(1)

OUTPUT_NAME = "fullscreen_calibration.png"
OUTPUT_TXT = "zones_calibrate.txt"


def save_screenshot(image):
    """Incearca sa salveze langa script; daca nu are permisiune, foloseste TEMP."""
    candidates = [
        Path(__file__).resolve().parent / OUTPUT_NAME,
        Path(os.environ.get("TEMP", ".")) / OUTPUT_NAME,
    ]

    ok, encoded = cv2.imencode(".png", image)
    if not ok:
        raise RuntimeError("OpenCV nu a putut codifica screenshot-ul PNG.")

    last_error = None
    for target in candidates:
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(encoded.tobytes())
            return target
        except OSError as exc:
            last_error = exc

    raise RuntimeError(
        "Nu pot salva screenshot-ul nici langa script, nici in TEMP. "
        f"Ultima eroare: {last_error}"
    )


def grab_screen():
    # MSS() este forma recomandata de versiunile noi ale bibliotecii mss.
    with mss.MSS() as sct:
        if len(sct.monitors) < 2:
            raise RuntimeError("Nu a fost detectat niciun monitor fizic.")

        mon = sct.monitors[1]
        shot = np.array(sct.grab(mon))
        bgr = cv2.cvtColor(shot, cv2.COLOR_BGRA2BGR)
        image_path = save_screenshot(bgr)

        print(f"\n[OK] Screenshot salvat: {image_path}")
        print(f"     Rezolutie: {bgr.shape[1]}x{bgr.shape[0]}")
        print(f"     Monitor: left={mon['left']} top={mon['top']} "
              f"width={mon['width']} height={mon['height']}")
        return bgr.shape[1], bgr.shape[0], image_path


def ask_zone(name, hint, screen_w, screen_h):
    print(f"\n--- {name} ---")
    print("  " + hint)
    print("Introdu coordonatele din screenshot: x y width height")
    print("Scrie skip pentru a sari peste aceasta zona.")

    while True:
        raw = input("> ").strip()
        if raw.lower() == "skip":
            return None

        parts = raw.replace(",", " ").split()
        if len(parts) != 4:
            print("[!] Introdu exact 4 valori: x y width height.")
            continue

        try:
            x, y, w, h = map(int, parts)
        except ValueError:
            print("[!] Valorile trebuie sa fie numere intregi.")
            continue

        if x < 0 or y < 0 or w <= 0 or h <= 0:
            print("[!] x si y trebuie sa fie >= 0, iar width si height > 0.")
            continue
        if x + w > screen_w or y + h > screen_h:
            print(f"[!] Zona depaseste screenshot-ul ({screen_w}x{screen_h}).")
            continue

        return (x, y, w, h)


def main():
    print("=" * 60)
    print("BELOT ASSISTANT — CALIBRARE")
    print("=" * 60)
    print("1. Deschide Belot.md in Chrome si intra intr-o masa.")
    print("2. Lasa cartile si interfata complet vizibile.")
    input("\nApasa ENTER pentru a face screenshot...")

    screen_w, screen_h, image_path = grab_screen()

    print("\nDeschide imaginea indicata mai jos:")
    print(image_path)
    try:
        os.startfile(str(image_path))
    except OSError:
        print("Deschide manual imaginea.")

    print("\nCiteste coordonatele pe imaginea originala, fara redimensionare.")
    zones = {}
    prompts = [
        ("ZONE_MY_HAND", "Dreptunghi peste toate cartile tale din mana."),
        ("ZONE_TABLE", "Dreptunghi peste zona centrala unde apar cartile jucate."),
        ("ZONE_TRUMP", "Dreptunghi peste pictograma atuului din coltul stanga-sus."),
    ]

    for name, hint in prompts:
        zone = ask_zone(name, hint, screen_w, screen_h)
        if zone is not None:
            zones[name] = zone

    output_txt = Path(__file__).resolve().parent / OUTPUT_TXT
    with output_txt.open("w", encoding="utf-8") as f:
        f.write("# Copiaza valorile necesare in config.py\n")
        f.write(f"# Screenshot: {screen_w}x{screen_h}\n")
        for name, _ in prompts:
            if name in zones:
                f.write(f"{name} = {zones[name]}\n")
            else:
                f.write(f"# {name} = (nesetat)\n")

    print("\n" + "=" * 60)
    print("CALIBRARE TERMINATA")
    print("=" * 60)
    for name, _ in prompts:
        print(f"{name} = {zones[name]}" if name in zones else f"# {name} = (nesetat)")
    print(f"\n[OK] Rezultatul a fost salvat: {output_txt}")
    input("\nApasa ENTER pentru inchidere...")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[INFO] Calibrare oprita de utilizator.")
        input("Apasa ENTER pentru inchidere...")
    except Exception:
        print("\n[EROARE] Programul s-a oprit. Detalii:")
        traceback.print_exc()
        input("\nApasa ENTER pentru inchidere...")
