# install.py
"""Установка зависимостей проекта."""
import subprocess
import sys
from pathlib import Path

def main():
    requirements = Path(__file__).with_name("requirements.txt")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", str(requirements)])
    print("\\nЗависимости установлены. Настройте координаты в config.py и добавьте PNG-шаблоны в assets/templates/.")

if __name__ == "__main__":
    main()
