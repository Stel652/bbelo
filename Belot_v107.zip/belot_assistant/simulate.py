# simulate.py — самопроверка стратегии: пара A (места 0,2) с настройками против пары B (1,3) с базовыми.
# Запуск: python simulate.py   (результат: средняя разница бил за раунд, >0 — настройки A лучше)
import random, sys
from engine.tracker import CardTracker, deck_for_mode, observe_complete_trick
from engine.rules import can_play_card, who_takes_trick
import engine.strategy as _new
try:
    import engine_old.strategy as _old
except ImportError:
    _old = _new
from engine.strategy import best_suit
from engine.scoring import points_to_bile

def _eng(cfg):
    return _old if cfg.get('old') else _new

def play_round(rng, cfgs, dealer):
    deck = list(deck_for_mode('2v2')); rng.shuffle(deck)
    hands = [deck[i*8:(i+1)*8] for i in range(4)]
    turned = rng.choice(['spades', 'hearts', 'diamonds', 'clubs'])
    first5 = [h[:5] for h in hands]
    declarer = trump = None
    for k in range(1, 5):                      # тур 1
        p = (dealer + k) % 4
        if _eng(cfgs[p % 2]).should_play(first5[p], turned, cfgs[p % 2]['min_score'])[0]:
            declarer, trump = p, turned; break
    if declarer is None:
        for k in range(1, 5):                  # тур 2
            p = (dealer + k) % 4
            s, sc = best_suit(first5[p])
            if s == turned: continue
            forced = (k == 4)
            if forced or _eng(cfgs[p % 2]).should_play(first5[p], s, cfgs[p % 2]['min_score'])[0]:
                declarer, trump = p, s; break
        if declarer is None:
            declarer = dealer; trump = best_suit(first5[dealer])[0]
    trk = [CardTracker('2v2') for _ in range(4)]
    leader = declarer; pts = [0, 0]; took = [0, 0]
    for trick in range(8):
        table, order, played = [], [], {}
        for k in range(4):
            p = (leader + k) % 4; h = hands[p]; cfg = cfgs[p % 2]
            snap = trk[p].update(h, table)
            pw = k >= 2 and who_takes_trick(table, trump) == k - 2
            card, _ = _eng(cfg).recommend_for_mode(h, table, trump, '2v2', trump_lead_allowed=(p == declarer or trick > 0),
                                         is_partner_winning=pw, snap=snap, i_declared=(p == declarer),
                                         last_to_play=(k == 3), voids=(trk[p].voids if cfg['voids'] else None),
                                         lead_style=cfg['lead_style'], use_mc=cfg.get('mc', False), max_samples=cfg.get('samples', 12), budget=0.05)
            if card is None: card = h[0]
            h.remove(card); table.append(card); order.append(p); played[p] = card
        for p in range(4):
            observe_complete_trick(trk[p], table, played[p], trump)
            trk[p].update(hands[p], table)
        w = order[who_takes_trick(table, trump)]
        pts[w % 2] += sum(c.points(trump) for c in table) + (10 if trick == 7 else 0); took[w % 2] += 1
        leader = w
    dt = declarer % 2
    if pts[dt] < pts[1 - dt]:
        b = [0, 0]; b[1 - dt] = points_to_bile(sum(pts)); bt = True
    else:
        b = [points_to_bile(pts[0]), points_to_bile(pts[1])]
    return b[0] - b[1]

def match(cfgA, cfgB, n, seed=0):
    rng = random.Random(seed); tot = 0
    for g in range(n):
        d = rng.randrange(4)
        if g % 2 == 0:  # меняем стороны, чтобы убрать преимущество мест
            tot += play_round(rng, [cfgA, cfgB], d)
        else:
            tot -= play_round(rng, [cfgB, cfgA], d)
    return tot / n

BASE = dict(min_score=50, voids=False, lead_style='small')
if __name__ == '__main__':
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 1500
    tests = {
        'старший козырь вместо младшего': dict(BASE, lead_style='high'),
        'учёт пустых мастей':             dict(BASE, voids=True),
        'порог торга 40':                 dict(BASE, min_score=40),
        'порог торга 60':                 dict(BASE, min_score=60),
    }
    for name, cfg in tests.items():
        print(f"{name:34s} {match(cfg, BASE, n):+.2f} бил/раунд")

def ab(n=400, mc=False):
    """Новая стратегия против старой (engine_old, если папка есть)."""
    new = dict(BASE, mc=mc); old = dict(BASE, mc=mc, old=True)
    return match(new, old, n)
