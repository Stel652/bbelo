import sys, os, time, json
import cv2
from PyQt6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QTextEdit, QGroupBox, QGridLayout, QComboBox, QCheckBox, QSpinBox)
from PyQt6.QtCore import QObject, QThread, QTimer, pyqtSignal, pyqtSlot
from engine.vision import VisionEngine
from engine.strategy import recommend_for_mode
from engine.robust import robust_recommend
from engine.cards import Card
from engine.tracker import CardTracker, trumps_left, points_left
from engine.strategy import should_play
from engine.combinations import detect_combinations, best_combination, total_points
from engine.bile import BileTracker
from engine.memory import GameMemory
from engine.decision_tracker import DecisionTracker, legal_moves
from engine.validation import check_state
from engine.card_memory import CardMemory
from engine.hit_filters import filter_table, dedupe_black_twins, TrickGate, PlayedGuard, lead_suit_fix
from engine.frame_voting import FrameVoter
from engine.playable import PlayableOracle, read as playable_read
from engine.autoplay import AutoPlayer, mouse_click
from engine.bidding import BidClicker, ComboWatcher, find_bid_buttons, blob_suit, white_blob_suit
from overlay.window import OverlayWindow
import config
from pynput import keyboard

MODE_LABELS = {
    "2v2": "2 на 2 — командный",
    "1v1": "1 на 1 — дуэль",
    "3p": "3 игрока — каждый сам за себя",
}

_TP = {"t": 0, "v": {}}
def _trained_params():
    """Лучшие настройки, найденные самоигрой (data/selfplay/params.json). Перечитываются раз в 30 сек."""
    import time as _t, json as _j, os as _o
    if _t.time() - _TP["t"] > 30:
        _TP["t"] = _t.time()
        try:
            with open(_o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "data", "selfplay", "params.json"), encoding="utf-8") as f:
                _TP["v"] = _j.load(f).get("champion", {})
        except Exception:
            _TP["v"] = {}
    return _TP["v"]

class Worker(QObject):
    result = pyqtSignal(object)
    log = pyqtSignal(str)
    finished = pyqtSignal()
    autoplay_off = pyqtSignal()

    def __init__(self, mode):
        super().__init__()
        self.mode, self.vision, self.trump, self.active = mode, None, None, False
        self.tracker = CardTracker(mode)
        self.bile = BileTracker(mode)
        self.memory = GameMemory(mode)
        self.decisions = DecisionTracker(mode)
        self._oracle = PlayableOracle()         # серые карты на экране = ходить нельзя (engine/playable.py)
        self._screen_legal = None
        self._hand_voter = FrameVoter(5, 3)     # теневой режим: только журнал, на советы не влияет
        try: self.memory.load_round(self.tracker)
        except Exception: pass
        self.hand_seen_cnt = {}
        self.hand_mem = {}      # карта -> сколько кадров подряд не видна
        self.autoplay = AutoPlayer(lambda x, y: mouse_click(x, y, getattr(config, 'AUTOPLAY_SCALE', 1.0), getattr(config, 'AUTOPLAY_OFFSET', (0, 0))),
                                   hold=getattr(config, 'AUTOPLAY_HOLD', 1.0))
        self.autoplay.enabled = bool(getattr(config, 'AUTOPLAY', False))
        _clk = lambda x, y: mouse_click(x, y, getattr(config, 'AUTOPLAY_SCALE', 1.0), getattr(config, 'AUTOPLAY_OFFSET', (0, 0)))
        self.bid = BidClicker(_clk)
        self.combo = ComboWatcher()
        self._combo_click, self._combo_t, self._bid_n = _clk, 0.0, 0
        self.frame = 0
        self.decl_votes, self.trump_votes = [], []
        self._bid_suits, self._bid_seen_off = [], False
        self._shot_pool = None
        self._pos_suit = {}
        self._tbl_prev_set = set()
        self._decl_info = {}
        self.declarer_me = False
        self.declarer_known = None   # None — имя ещё не прочиталось, True — я выбрал, False — другой
        self.score = (0, 0, 1010 if mode == "1v1" else 101)
        self.cand_sig, self.cand_cnt, self.empty_frames = None, 0, 0
        self.committed_sig, self.pending_sig, self.pending_cnt = None, None, 0
        self.prev_hand_len = 0
        self.shown_trump = None
        self.trump_unlocked = False
        self.last_signature = None
        self._pool, self._job = None, 0      # фоновый «глубокий» расчёт (MC), чтобы подсказка не ждала

    @pyqtSlot()
    def start(self):
        try:
            self.vision = VisionEngine()
            self.vision.warmup()
            if self.mode != "2v2":
                self.vision.allowed_ranks = {"9", "10", "J", "Q", "K", "A"}
            self.active = True
            self.log.emit(f"Шаблонов карт загружено: {len(self.vision.templates)}/32")
            self.timer = QTimer(self)
            self.timer.timeout.connect(self.tick)
            self.timer.start(max(33, 1000 // max(1, config.CAPTURE_FPS)))
        except Exception as e:
            self.log.emit("Ошибка запуска захвата: " + str(e))
            self.finished.emit()

    @pyqtSlot(str)
    def set_trump(self, suit):
        self.trump = suit
        if not getattr(self, "_auto_set", False):
            self.trump_fresh = True            # козырь задан вручную (F5–F8): считаем актуальным, иконку не ждём
        self._auto_set = False
        self.committed_sig = None
        self.last_signature = None
        self.cand_sig, self.cand_cnt = None, 0

    @pyqtSlot(int, int, int)
    def set_score(self, mine, opp, limit):
        self.score = (mine, opp, limit)
        self.committed_sig = None
        self.last_signature = None

    @pyqtSlot(bool)
    def set_declarer(self, v):
        self.declarer_me = v
        if v and self.vision is not None and getattr(self, "_manual_decl", False):
            try:
                self.vision.learn_my_top_name()
            except Exception:
                pass
        self.committed_sig = None
        self.trump_unlocked = v

    @pyqtSlot()
    def pause(self):
        self.active = not self.active

    @pyqtSlot()
    def stop(self):
        self.active = False
        self._job += 1
        if self._pool is not None:
            self._pool.shutdown(wait=False)
            self._pool = None
        if getattr(self, "_shot_pool", None) is not None:
            self._shot_pool.shutdown(wait=True)
            self._shot_pool = None
        if hasattr(self, "timer"):
            self.timer.stop()
        if self.vision:
            self.vision.close()
            self.vision = None
        try: self.memory.save()
        except Exception: pass
        self.result.emit(None)
        self.finished.emit()


    # Места за столом (по часовой стрелке на экране): 0=слева, 1=сверху, 2=справа, 3=я (снизу).
    SEAT_CYCLE = {"3p": [0, 2, 3], "2v2": [0, 1, 2, 3], "1v1": [1, 3]}

    @staticmethod
    def _seat_of(p, zone):
        """Место по позиции карты в зоне стола. Карты лежат кучно у центра, поэтому смотрим на смещение
        относительно размера зоны: моя карта — заметно ниже центра, верхняя — заметно выше, остальные — слева/справа."""
        w, h = max(zone[2], 1), max(zone[3], 1)
        dx, dy = (p[0] - w / 2.0) / w, (p[1] - h / 2.0) / h
        if dy > 0.22 and abs(dx) < 0.20:
            return 3
        if dy < -0.22 and abs(dx) < 0.20:
            return 1
        return 0 if dx < 0 else 2

    @staticmethod
    def _order_by_seats(hits, zone, mode="3p", leader_hint=None):
        """Порядок хода по местам. leader_hint — место того, кто заходит (взял прошлую взятку); без него
        полный стол (все места заняты) неоднозначен, и тогда порядок не трогаем."""
        try:
            cyc = Worker.SEAT_CYCLE.get(mode, [0, 1, 2, 3])
            by = {}
            for c, p in hits:
                by.setdefault(Worker._seat_of(p, zone), []).append((c, p))
            if len(by) != len(hits) or any(s_ not in cyc for s_ in by):
                return hits                           # два на одном месте / место не из этого режима
            occ = set(by)
            if len(occ) == len(cyc):                  # все заняты: лидера по местам не найти
                if leader_hint not in cyc:
                    return hits
                start = leader_hint
            else:
                lead = [s_ for s_ in occ if cyc[(cyc.index(s_) - 1) % len(cyc)] not in occ]
                if len(lead) != 1:
                    return hits
                start = lead[0]
            out, i = [], cyc.index(start)
            for _ in range(len(cyc)):
                s_ = cyc[(i) % len(cyc)]; i += 1
                if s_ in occ:
                    out.append(by[s_][0])
            return out if len(out) == len(hits) else hits
        except Exception:
            return hits

    def _trace(self, kind, **kw):
        """Полный журнал для разбора: data/trace.jsonl (каждое изменение увиденного, сбросы, козырь, расхождения, задержки)."""
        try:
            p = os.path.join(os.path.dirname(__file__), "data", "trace.jsonl")
            os.makedirs(os.path.dirname(p), exist_ok=True)
            if kind == "advice" and not kw.get("hand") and not kw.get("table") and str(kw.get("why", "")).startswith("карты не видны"):
                return                      # пауза между раздачами — шум, в журнал не пишем
            if os.path.exists(p) and os.path.getsize(p) > 60_000_000:
                if os.path.exists(p + ".old1"):
                    os.replace(p + ".old1", p + ".old2")
                os.replace(p, p + ".old1")
            kw.update(ev=kind, t=round(time.time(), 3), mode=self.mode, frame=self.frame)
            with open(p, "a", encoding="utf-8") as f:
                f.write(json.dumps(kw, ensure_ascii=False, default=str) + "\n")
        except Exception:
            pass

    def _stab_black(self, name, hits):
        """♣/♠: карта на том же месте с уже подтверждённой мастью (>=2 кадра) не меняет масть из-за одного
        неуверенного кадра (уверенность масти < 0.5). Уверенная смена принимается сразу."""
        try:
            sc = getattr(self, "_scores", {}) or {}
            out = []
            for c, p in hits:
                if c.suit in ("clubs", "spades"):
                    key = (name, c.rank, int(p[0] // 40))
                    st = self._pos_suit.get(key)
                    v = sc.get(f"{c.rank}{c.suit[0]}")
                    conf = v[1] if isinstance(v, (list, tuple)) and len(v) > 1 else 1.0
                    if st and st[0] != c.suit and st[1] >= 2 and conf < 0.5:
                        self._trace("suit_override", pos=name, seen=str(c), kept=st[0], conf=conf)
                        c = Card(st[0], c.rank)
                    elif st and st[0] == c.suit:
                        self._pos_suit[key] = (c.suit, min(st[1] + 1, 50))
                    else:
                        self._pos_suit[key] = (c.suit, 1)
                    if conf < 0.3:
                        self._shot("suit_low", min_gap=60.0, card=str(c), conf=conf)
                out.append((c, p))
            if len(self._pos_suit) > 400:
                self._pos_suit.clear()
            return out
        except Exception:
            return hits

    def _shot(self, kind, min_gap=2.0, **meta):
        """Скриншот для разбора: весь экран + стол + рука + оба места имени + моё имя. Пишется в фоне (data/shots).
        Снимаем при: новая раздача, выбор козыря, мой ход (карта ушла на стол), сброс, расхождение, смена козыря, неуверенная масть."""
        try:
            now = time.time()
            last = getattr(self, "_shot_t", {})
            if now - last.get(kind, 0) < min_gap:
                return
            last[kind] = now
            self._shot_t = last
            v = self.vision
            sw, sh = v.screen_size()
            full = v.grab_full()
            main, alt, mine = v.name_crops()
            table = v.capture(config.scaled_zone(config.ZONE_TABLE, sw, sh))
            hand = v.capture(config.scaled_zone(config.ZONE_MY_HAND, sw, sh))
            base = os.path.join(os.path.dirname(__file__), "data", "shots")
            os.makedirs(base, exist_ok=True)
            tag = "%d_%s_f%d" % (int(now), kind, self.frame)
            if self._shot_pool is None:
                from concurrent.futures import ThreadPoolExecutor
                self._shot_pool = ThreadPoolExecutor(max_workers=1)
            info = dict(meta, kind=kind, t=round(now, 3), frame=self.frame, trump=self.trump, declarer=self.declarer_known,
                        trump_votes=list(getattr(self, "trump_votes", [])), decl_votes=list(getattr(self, "decl_votes", [])),
                        hand=[str(c) for c in getattr(self, "hand_mem", {})], rounds=self.tracker.rounds, size=[sw, sh])
            def work():
                try:
                    cv2.imwrite(os.path.join(base, tag + "_full.jpg"), full, [cv2.IMWRITE_JPEG_QUALITY, 88])
                    cv2.imwrite(os.path.join(base, tag + "_table.png"), table)
                    cv2.imwrite(os.path.join(base, tag + "_hand.png"), hand)
                    cv2.imwrite(os.path.join(base, tag + "_name_main.png"), main)
                    cv2.imwrite(os.path.join(base, tag + "_name_alt.png"), alt)
                    cv2.imwrite(os.path.join(base, tag + "_name_me.png"), mine)
                    with open(os.path.join(base, tag + ".json"), "w", encoding="utf-8") as f:
                        json.dump(info, f, ensure_ascii=False, default=str)
                    files = sorted((os.path.join(base, n) for n in os.listdir(base)), key=os.path.getmtime)
                    for old in files[:max(0, len(files) - getattr(config, "SHOTS_MAX_FILES", 600))]:
                        os.remove(old)
                except Exception:
                    pass
            self._shot_pool.submit(work)
            self._trace("shot", shot=tag, **{k: v_ for k, v_ in meta.items()})
        except Exception:
            pass

    def tick(self):
        if not self.active or not self.vision:
            return
        self._t0 = time.time()
        try:
            # Козырь — автоматически по иконке в левом верхнем квадратике (голосование по 3 кадрам)
            self.frame += 1
            self.vision._tick_t0 = self._t0
            # Окно «Rezultate runda N» закрывает руку и стол: это не ошибка распознавания. Пока оно открыто — ничего не читаем,
            # не кликаем и не копим «mismatch»; после закрытия даём 2 сек на то, чтобы игра раздала новые карты.
            if getattr(config, "RESULTS_DIALOG", True) and self.vision.results_dialog_open():
                if not getattr(self, "_dlg_open", False):
                    self._dlg_open = True
                    self._trace("results_dialog", state="open", rounds=self.tracker.rounds)
                self._dlg_t = time.time(); self._mm = 0; self._ap_ctx = None
                self._oracle.reset(); self._screen_legal = None
                self.result.emit({"hand": [], "table": [], "trump": self.trump, "declarer": self.declarer_known, "move": None,
                                  "why": "окно результатов раздачи — жду", "position": (self.vision.screen_size()[0] // 2, self.vision.screen_size()[1] // 4)})
                return
            if getattr(self, "_dlg_open", False):
                self._dlg_open = False
                self._trace("results_dialog", state="closed")
            trump_locked = self.trump is not None and bool(getattr(self.tracker, "seen", None))
            slow = trump_locked and self.declarer_known is not None and self.frame % 6
            auto = None
            if not slow:
                try:
                    auto = self.vision.read_trump_icon()
                except Exception:
                    auto = None
            self.trump_votes = ((getattr(self, "trump_votes", []) + [auto])[-3:]) if not slow else getattr(self, "trump_votes", [])
            top = max(set(self.trump_votes), key=self.trump_votes.count) if self.trump_votes else None
            # Смена козыря автоматически: нужны 3/3 одинаковых чтения. Разрешена, если (а) козыря ещё нет, или
            # (б) в раунде не сыграно ни одной карты, или (в) раздача только что сброшена (<45 с) — раньше именно
            # здесь козырь «залипал» на прошлой раздаче (бот советовал с неверным козырём). Не чаще раза в 25 с,
            # кроме новой раздачи. Подавленные смены пишем в журнал. Вручную F5–F8 — всегда.
            round_started = bool(getattr(self.tracker, "seen", None))
            since_reset = time.time() - getattr(self.tracker, "_last_reset_t", 0.0)
            _need_v = 2 if not getattr(self, "trump_fresh", True) else 3      # сразу после новой раздачи иконка читается быстрее: 2 одинаковых кадра
            if auto and not getattr(self, "trump_fresh", True):
                self._icon_after_reset = (getattr(self, "_icon_after_reset", []) + [auto])[-4:]   # во время торгов иконки нет: любое чтение — козырь НОВОЙ раздачи
            if top and len(self.trump_votes) >= _need_v and self.trump_votes[-_need_v:].count(top) >= _need_v and top != self.trump:
                gap_ok = time.time() - getattr(self, "_trump_t", 0) > 25 or since_reset < 45
                allowed = self.trump is None or ((not round_started or since_reset < 45) and gap_ok)
                if allowed:
                    self._trump_t = time.time()
                    old_tr = self.trump
                    self._auto_set = True
                    self.set_trump(top)
                    self.log.emit("Козырь определён автоматически: " + top)
                    self._trace("trump_change", old=old_tr, new=top, since_reset=round(since_reset, 1), round_started=round_started)
                    self._shot("trump", min_gap=5.0, old=old_tr, new=top)
                elif getattr(self, "_sup_trump", None) != (top, self.tracker.rounds):
                    self._sup_trump = (top, self.tracker.rounds)
                    self._trace("trump_change_suppressed", bot=self.trump, icon=top, round_started=round_started,
                                gap_ok=gap_ok, since_reset=round(since_reset, 1))
            # Кто выбрал козырь: если сверху появилось моё имя (JackDaniels1) — выбрал я; другое имя — не я.
            # Читаем и после решения (каждый 3-й кадр), «выбрал я» может прийти позже; ложные «не я» не фиксируются.
            dm, dinfo = None, {}
            if (not slow) or self.frame % 3 == 0:
                try:
                    dinfo = self.vision.declarer_check()
                    dm = dinfo.get("me")
                except Exception:
                    dm, dinfo = None, {}
            self._decl_info = {k: v for k, v in dinfo.items() if k != "crop"}
            if dm is not None:
                self.decl_votes = (getattr(self, "decl_votes", []) + [dm])[-5:]
            yes, no = self.decl_votes.count(True), self.decl_votes.count(False)
            n_v = yes + no
            new_known = None
            if yes >= 3 or (yes >= 2 and n_v <= 3):
                new_known = True
            elif n_v >= 3 and yes == 0:
                new_known = False
            if new_known is not None and new_known != self.declarer_known:
                self.declarer_known = new_known
                self._trace("declarer", me=new_known, votes=list(self.decl_votes), score=self._decl_info.get("score"), ratio=self._decl_info.get("ratio"), zone=self._decl_info.get("zone"))
                self._shot("declarer", min_gap=3.0, me=new_known, score=self._decl_info.get("score"), ratio=self._decl_info.get("ratio"), zone=self._decl_info.get("zone"))
            if new_known is not None and new_known != self.declarer_me:
                self.set_declarer(new_known)
                self.log.emit("Козырь выбрал: " + ("я" if self.declarer_me else "другой игрок"))
            trump = self.trump or self.vision.read_trump()
            sw, sh = self.vision.screen_size()
            try:
                _raw = self.vision.turn_state() if getattr(config, "TURN_RING", True) else None
            except Exception:
                _raw = None
            if self.frame % 3 == 0:
                try:
                    _bt = find_bid_buttons(self.vision.capture(config.scaled_zone(config.ZONE_BID_PANEL, sw, sh)))
                    if _bt["green"] or _bt["red"] or _bt["white"]:
                        self._bid_last_seen, self._bid_seen_round = time.time(), True
                except Exception:
                    pass
            self._turn_hist = (getattr(self, "_turn_hist", []) + [_raw])[-3:]
            _h = self._turn_hist
            if len(_h) >= 2 and _h[-1] == _h[-2]:
                _tn = _h[-1]
            elif _h.count("me") >= 2: _tn = "me"
            else: _tn = getattr(self, "turn_now", None) if _raw is not None else None
            if _tn != getattr(self, "turn_now", None):
                self._trace("turn", state=_tn, ring={k: round(v_, 4) for k, v_ in getattr(self.vision, "last_ring", {}).items()})
            self.turn_now = _tn
            self._bid_tick(sw, sh)
            if not trump:
                txt = None
                try: txt = self._five_eval(sw, sh)
                except Exception as e: self.log.emit("Оценка 5 карт: " + str(e))
                sig = ("NO_TRUMP", txt)
                if self.last_signature != sig:
                    self.last_signature = sig
                    self.result.emit({"text": txt or "Жду карты / козырь: F5 ♠  F6 ♥  F7 ♦  F8 ♣  (или V R D C)",
                                      "position": (sw//2, sh//4)})
                return
            hand_zone = config.scaled_zone(config.ZONE_MY_HAND, sw, sh)
            table_zone = config.scaled_zone(config.ZONE_TABLE, sw, sh)
            hand_hits = self.vision.detect_cards(hand_zone, dim=True)
            _hs = dict(getattr(self.vision, "last_scores", {}) or {})
            if _hs: self._sc_hand = _hs
            table_hits = self.vision.detect_cards(table_zone)
            # Торги: открытая карта на столе (кандидат в козыри) — не сыгранная. Фаза торгов: видна панель «Joc/Pas» либо в руке
            # ровно 5 карт и ни одной карты ещё не сыграно.
            _bidding = (time.time() - getattr(self, "_bid_last_seen", 0) < 1.2) or \
                       (len(hand_hits) == 5 and not self.tracker.seen and not self.tracker.closed)
            if _bidding and table_hits:
                if getattr(self, "_bid_tbl_logged", None) != tuple(str(c) for c, _ in table_hits):
                    self._bid_tbl_logged = tuple(str(c) for c, _ in table_hits)
                    self._trace("bidding_table_ignored", cards=list(self._bid_tbl_logged))
                table_hits = []
            _ts = dict(getattr(self.vision, "last_scores", {}) or {})
            if _ts: self._sc_table = _ts
            self._scores = {**getattr(self, "_sc_hand", {}), **getattr(self, "_sc_table", {})}
            # Память руки: карта пропадает из руки только если её нет ~2 сек. подряд
            # (или она появилась на столе) — одиночные промахи распознавания больше не «съедают» карты.
            hand_hits = [(c, p) for c, p in hand_hits if c in self.tracker.deck]
            table_hits = [(c, p) for c, p in table_hits if c in self.tracker.deck]
            # FIX ♣/♠: разовая ошибка масти не должна менять карту. Если «новая» чёрная карта — двойник (тот же ранг,
            # другая чёрная масть) стабильно виденной карты, которой сейчас нет в кадре, — это она же, масть спутана.
            # память раздачи: карта из закрытой взятки (или лежащая на столе) в руке/на столе — это двойник ♠↔♣
            # Новая раздача, которую не заметили: сразу несколько карт руки «уже вышли» в закрытых взятках —
            # значит память взяток устарела (из-за неё карты, например 10♠, пропадали из руки и со стола).
            if len({c for c, _ in hand_hits} & self.tracker.closed) >= 3 and self.tracker.can_reset():
                self.tracker.reset("closed>=3"); self.dealt = None
                self.hand_mem.clear(); self.hand_seen_cnt.clear(); self.table_order = []
            hand_hits = self._stab_black("h", hand_hits)
            table_hits = self._stab_black("t", table_hits)
            _hp = {c for c, _ in hand_hits if self.hand_seen_cnt.get(c, 0) >= 4 and c in self.hand_mem}   # надёжно читаются в руке
            _before = set(self.tracker.closed)
            hand_hits = self.tracker.fix_black(hand_hits, forbid={c for c, _ in table_hits}, protect=_hp)
            if _before - self.tracker.closed:
                self._trace("closed_healed", cards=[str(c) for c in (_before - self.tracker.closed)])
            table_hits = self.tracker.fix_black(table_hits)
            try:   # 1) ложные карты стола (низкая оценка достоинства/масти); 2) двойник ♠/♣ в руке на одной позиции
                _sc = getattr(self, "_scores", {})
                table_hits, _tdrop = filter_table(table_hits, _sc, protect=set(self.hand_mem), dead=set(self.tracker.closed))
                if _tdrop: self._trace("table_low_conf_removed", cards=[str(c) for c, _ in _tdrop], scores={str(c): _sc.get(f"{c.rank}{c.suit[0]}") for c, _ in _tdrop})
                hand_hits, _hdrop = dedupe_black_twins(hand_hits, _sc, known_hand={c for c, v in self.hand_mem.items()},
                                                       played=set(self.tracker.seen) | set(self.tracker.closed))
                if _hdrop: self._trace("hand_twin_removed", removed=[str(c) for c, _ in _hdrop], kept=[str(c) for c, _ in hand_hits])
            except Exception: pass
            try:   # 3) остатки прошлой взятки, которые игра ещё не убрала со стола
                _g = getattr(self, "_trick_gate", None)
                if _g is None: _g = self._trick_gate = TrickGate()
                if self.tracker.rounds != getattr(self, "_gate_round", 0):
                    _g.reset(); self._gate_round = self.tracker.rounds
                _gP = {"1v1": 2, "3p": 3, "2v2": 4}.get(self.mode, 4)
                table_hits, _gdrop = _g.update(table_hits, _gP)
                if _gdrop and getattr(self, "_gate_logged", None) != frozenset(c for c, _ in _gdrop):
                    self._gate_logged = frozenset(c for c, _ in _gdrop)
                    self._trace("trick_leftover_removed", cards=[str(c) for c, _ in _gdrop])
            except Exception: pass
            _ids = {c for c, _ in hand_hits}
            _fixed = []
            for c, p_ in hand_hits:
                if c.suit in ("clubs", "spades") and self.hand_seen_cnt.get(c, 0) < 3:
                    twin = Card("spades" if c.suit == "clubs" else "clubs", c.rank)
                    if twin in self.hand_mem and twin not in _ids and self.hand_seen_cnt.get(twin, 0) >= 3:
                        c = twin
                _fixed.append((c, p_))
            hand_hits = _fixed
            # Подтверждённая рука раздачи: 8 одинаковых кадров подряд -> запоминаем «розданные» карты.
            # Дальше карта, которой нет в розданных, но чей двойник ♠↔♣ есть (и не виден) — это ошибка масти: чиним.
            _ids2 = {c for c, _ in hand_hits}
            _dealt = getattr(self, "dealt", None)
            if _dealt:
                _unk = [c for c in _ids2 if c not in _dealt]
                if len(_ids2) >= 7 and len(_unk) >= 4:
                    self.dealt = _dealt = None          # другая рука -> новая раздача
                else:
                    _fx = []
                    for c, p_ in hand_hits:
                        if c not in _dealt and c.suit in ("clubs", "spades"):
                            tw = Card("spades" if c.suit == "clubs" else "clubs", c.rank)
                            if tw in _dealt and tw not in _ids2 and tw not in self.tracker.closed:
                                c = tw
                        _fx.append((c, p_))
                    hand_hits = _fx
            if not _dealt:
                _sig = frozenset(c for c, _ in hand_hits)
                if len(_sig) == 8 and _sig == getattr(self, "_lock_sig", None):
                    self._lock_cnt = getattr(self, "_lock_cnt", 0) + 1
                    if self._lock_cnt >= 8:
                        self.dealt = set(_sig)
                else:
                    self._lock_sig, self._lock_cnt = _sig, 0
            try:   # голосование кадров: FRAME_VOTING в config.py (False = только журнал)
                _raw = {c for c, _ in hand_hits}
                _conf, _lv = self._hand_voter.push(_raw)
                _lp = getattr(self, "_last_hand_pos", {})
                for _c, _p in hand_hits: _lp[_c] = _p
                self._last_hand_pos = _lp
                if _raw != _conf and self.frame % 5 == 0:
                    self._trace("vote_diff", raw_only=[str(c) for c in _raw - _conf], voted_only=[str(c) for c in _conf - _raw], applied=bool(getattr(config, "FRAME_VOTING", False)))
                if getattr(config, "FRAME_VOTING", False) and _conf and len(self._hand_voter.frames) >= 3:
                    _new_hits = [(c, p) for c, p in hand_hits if c in _conf]
                    _new_hits += [(c, _lp[c]) for c in _conf - _raw if c in _lp and c not in {t_ for t_, _ in table_hits}]
                    if _new_hits: hand_hits = _new_hits
            except Exception: pass
            try:   # санитарная проверка стола: лишние карты и дубли «рука+стол» -> ложные кадры
                _np = {"1v1": 2, "3p": 3, "2v2": 4}[self.mode]
                _stable = set(_conf) if "_conf" in dir() else set()
                _dup = {c for c, _ in table_hits} & {c for c, _ in hand_hits} & _stable
                if _dup:
                    table_hits = [(c, p) for c, p in table_hits if c not in _dup]
                    self._trace("table_dup_removed", cards=[str(c) for c in _dup])
                if len(table_hits) > _np:
                    self._trace("table_overflow", raw=[str(c) for c, _ in table_hits], players=_np)
                    table_hits = list(getattr(self, "_last_table_hits", []))[:_np]
                else:
                    self._last_table_hits = list(table_hits)
            except Exception: pass
            # Подтверждённо сыгранная карта не должна возвращаться в руку на следующих кадрах (см. PlayedGuard)
            if getattr(self, "_pg", None) is None: self._pg = PlayedGuard()
            if self.tracker.rounds != getattr(self, "_pg_round", None): self._pg.reset(); self._pg_round = self.tracker.rounds
            _gone = self._pg.update({c for c, _ in hand_hits}, set(self.hand_mem))
            if _gone:
                hand_hits = [(c, p) for c, p in hand_hits if c not in _gone]
                for c in _gone: self.hand_mem.pop(c, None); self.hand_seen_cnt.pop(c, None)
                self._trace("played_card_removed_from_hand", cards=[str(c) for c in _gone])
            try:    # оракул легальных ходов: затемнённые игрой карты (подтверждается 2 кадрами подряд)
                if getattr(config, "SCREEN_LEGAL", True) and getattr(self, "trump_fresh", True):
                    _lv, _um = playable_read(self.vision, self.vision.capture(hand_zone), hand_hits)
                    self._screen_legal = self._oracle.update(_lv, _um)
                else:
                    self._screen_legal = None
            except Exception:
                self._screen_legal = None
            seen_hand = {c for c, _ in hand_hits}
            table_cards_now = {c for c, _ in table_hits}
            # Полная трассировка: что увидел бот в этом кадре (с оценками уверенности), при каждом изменении
            _sig_tr = (tuple(sorted(str(c) for c, _ in hand_hits)), tuple(sorted(str(c) for c in table_cards_now)), self.trump)
            if _sig_tr != getattr(self, "_sig_tr", None):
                self._sig_tr = _sig_tr
                self._trace("frame", hand_raw=[str(c) for c, _ in hand_hits], table_raw=[str(c) for c, _ in table_hits],
                            scores=dict(getattr(self, "_scores", {}) or {}), decl=dict(getattr(self, "_decl_info", {}) or {}), trump=self.trump,
                            trump_votes=list(getattr(self, "trump_votes", [])), decl_votes=list(getattr(self, "decl_votes", [])),
                            hand_mem=[str(c) for c in self.hand_mem], dealt=sorted(str(c) for c in (getattr(self, "dealt", None) or [])),
                            seen=len(self.tracker.seen), closed=len(self.tracker.closed), voids={k: sorted(v) for k, v in self.tracker.voids.items()},
                            rounds=self.tracker.rounds, tick_ms=round((time.time() - getattr(self, "_t0", time.time())) * 1000))
            _rl = getattr(self.tracker, "reset_log", [])
            if len(_rl) != getattr(self, "_rl_n", 0):
                for _r in _rl[getattr(self, "_rl_n", 0):]:
                    self._trace("reset", reason=_r[1], at=_r[0])
                    self._pos_suit.clear()
                    self._shot("reset", min_gap=3.0, reason=_r[1])
                self._rl_n = len(_rl)
            _sl = getattr(self.tracker, "suppressed_log", [])
            if len(_sl) != getattr(self, "_sl_n", 0):
                for _r in _sl[getattr(self, "_sl_n", 0):]:
                    self._trace("reset_suppressed", reason=_r[1], at=_r[0])
                self._sl_n = len(_sl)
            _newt = table_cards_now - self._tbl_prev_set
            _mine = [c for c in _newt if c in self.hand_mem and c not in seen_hand]
            if _mine:
                self._pg.confirm(_mine)
                self._trace("played", cards=[str(c) for c in _mine])
                try:
                    for _c in _mine: self.decisions.link_played(_c)
                except Exception: pass
                self._shot("played", min_gap=1.0, cards=[str(c) for c in _mine])
            self._tbl_prev_set = set(table_cards_now)
            for c in seen_hand:
                self.hand_mem[c] = 0
                self.hand_seen_cnt[c] = self.hand_seen_cnt.get(c, 0) + 1
            for c in list(self.hand_mem):
                if c in seen_hand:
                    continue
                self.hand_mem[c] += 1
                # Карта, стабильно видимая раньше, — почти наверняка всё ещё в руке (просто промах
                # распознавания): держим её ~6 сек. Иначе бот считал, что масти нет, и советовал чужую масть.
                limit = 40 if self.hand_seen_cnt.get(c, 0) >= 8 else 4
                if self.hand_mem[c] > limit or c in table_cards_now:
                    del self.hand_mem[c]
                    self.hand_seen_cnt.pop(c, None)
            # Уже сыгранная карта не может быть «призраком» в руке: если её нет на экране в руке, а она уже
            # выходила на стол — удаляем. То же для карты, которую бот советовал и которая исчезла при новом ходе на столе.
            adv = self.memory.last_advice[0] if self.memory.last_advice else None
            for c in list(self.hand_mem):
                if c in seen_hand:
                    continue
                if c in self.tracker.seen or (c == adv and len(table_cards_now) != getattr(self, "_prev_tbl_n", 0)):
                    del self.hand_mem[c]; self.hand_seen_cnt.pop(c, None)
            self._prev_tbl_n = len(table_cards_now)
            # Масть захода на столе, а карта этой масти в руке уже >6 кадров не видна -> это «призрак» (я её сыграл):
            # иначе бот думает, что масть есть, и не требует резать козырем.
            tbl0 = getattr(self, "table_order", [])
            if tbl0:
                lead_s = tbl0[0].suit
                for c in list(self.hand_mem):
                    if c.suit == lead_s and c not in seen_hand and self.hand_mem[c] > 6:
                        del self.hand_mem[c]; self.hand_seen_cnt.pop(c, None)
            # Рука на экране стала ровно на 1 карту короче -> я сыграл карту: «призраков» не держим, верим экрану
            pn = getattr(self, "_prev_seen_n", 0)
            if pn >= 2 and len(seen_hand) == pn - 1:
                for c in list(self.hand_mem):
                    if c not in seen_hand:
                        del self.hand_mem[c]; self.hand_seen_cnt.pop(c, None)
            self._prev_seen_n = len(seen_hand)
            # Карты закрытых взяток в руке быть не могут (это «призраки»), и размер руки ≤ 8 − сыгранные взятки
            for c in list(self.hand_mem):
                if c in self.tracker.closed and c not in seen_hand:
                    del self.hand_mem[c]; self.hand_seen_cnt.pop(c, None)
            _cap = max(0, 8 - self.tracker.tricks_done)
            if self.tracker.tricks_done and len(self.hand_mem) > _cap:
                for c in sorted(self.hand_mem, key=lambda c: (c in seen_hand, -self.hand_mem[c]))[:len(self.hand_mem) - _cap]:
                    if c not in seen_hand:
                        del self.hand_mem[c]; self.hand_seen_cnt.pop(c, None)
            # Размер руки на экране стабилен >=10 кадров: «призраки» сверх него (сыгранные карты) убираем
            _n = len(seen_hand)
            if _n == getattr(self, "_stable_n", -1):
                self._stable_cnt = getattr(self, "_stable_cnt", 0) + 1
            else:
                self._stable_n, self._stable_cnt = _n, 0
            if _n >= 2 and self._stable_cnt >= 10:
                for c in list(self.hand_mem):
                    if c not in seen_hand:
                        del self.hand_mem[c]; self.hand_seen_cnt.pop(c, None)
            order = {c: p[0] for c, p in hand_hits}
            # В руке не может быть больше 8 карт: лишние (самые «давно не виденные» призраки) отбрасываем.
            keep_cards = sorted(self.hand_mem, key=lambda c: (self.hand_mem[c], order.get(c, 10**6)))[:8]
            for c in list(self.hand_mem):
                if c not in keep_cards:
                    del self.hand_mem[c]; self.hand_seen_cnt.pop(c, None)
            hand = sorted(keep_cards, key=lambda c: order.get(c, 10**6))
            # Новая раздача: сбрасываем только счёт карт, козырь НЕ трогаем (его меняешь сам: F5-F8 / V R D C).
            if ((len(hand) >= 5 and 0 < self.prev_hand_len <= 2) or (len(hand) == 8 and 0 < self.prev_hand_len <= 5)) and self.tracker.can_reset():
                self.tracker.reset("hand %d->%d" % (self.prev_hand_len, len(hand))); self.trump_unlocked = False
                self.hand_seen_cnt = {c: 1 for c in hand}
                self.memory.on_new_round()
                self.trump_fresh, self._trump_at_reset, self._bid_seen_round = False, self.trump, False   # козырь прошлой раздачи устарел
                self._fresh_t0 = time.time()
                self._icon_after_reset = []
                self._trace("trump_stale", old=self.trump)
                self.declarer_known = None; self.decl_votes = []   # новая раздача: заново читаем, кто выбрал козырь
                self.new_round_hint = 40          # ~6 сек. мягкая подсказка проверить козырь
            elif self.tracker.rounds != getattr(self, 'seen_rounds', 0):
                self.trump_unlocked = False
            self.seen_rounds = self.tracker.rounds
            self.prev_hand_len = len(hand)
            # Козырь новой раздачи считается известным, когда: (а) иконка сменилась на другую масть, (б) панель торгов
            # была и пропала, (в) уже ходили картами этой раздачи / рука убавилась, (г) прошло 40 с (запасной выход).
            if not getattr(self, "trump_fresh", True):
                _ia = getattr(self, "_icon_after_reset", [])
                _icon_ok = len(_ia) >= 2 and _ia[-1] == _ia[-2] == self.trump                # иконка после раздачи подтверждает козырь бота
                _icon_now = (max(set(self.trump_votes), key=self.trump_votes.count) if self.trump_votes else None)
                _icon_against = _icon_now is not None and _icon_now != self.trump            # иконка показывает другую масть — козырь ещё старый
                _since_f = time.time() - getattr(self, "_fresh_t0", 0)
                _ok = ((self.trump is not None and self.trump != getattr(self, "_trump_at_reset", None) and _icon_ok)
                       or (_icon_ok and getattr(self, "_bid_seen_round", False) and time.time() - getattr(self, "_bid_last_seen", 0) > 1.5)
                       or (_icon_ok and (bool(getattr(self.tracker, "seen", None)) or len(hand) <= 6))
                       or (not _icon_against and (bool(getattr(self.tracker, "seen", None)) or len(hand) <= 6) and _since_f > 8)
                       or _since_f > 40)
                if _ok:
                    self.trump_fresh = True
                    self._trace("trump_fresh", trump=self.trump, was=getattr(self, "_trump_at_reset", None))
            # Порядок хода = порядок появления карт на столе.
            seen_now = [c for c, _ in table_hits]
            # карта на столе не пропадает из-за одного-двух кадров промаха (красные карты иногда мигали)
            miss = getattr(self, "tbl_miss", {})
            for c in seen_now: miss[c] = 0
            keep = []
            for c in getattr(self, "table_order", []):
                if c in seen_now: keep.append(c)
                else:
                    miss[c] = miss.get(c, 0) + 1
                    if miss[c] <= 4 and seen_now: keep.append(c)   # стол совсем пуст -> взятка убрана, не держим
            self.tbl_miss = {c: miss[c] for c in keep}
            self.table_order = keep
            if not table_hits and not self.table_order:
                self._card_seat = {}          # стол пуст — места прошлой взятки больше не нужны
            _cs = getattr(self, "_card_seat", None)
            if _cs is None: _cs = self._card_seat = {}
            for _c, _p in table_hits:
                _cs.setdefault(_c, self._seat_of(_p, table_zone))
            _new = [(c, p) for c, p in table_hits if c not in self.table_order]
            if not self.table_order and len(_new) >= 2:
                # Несколько карт появились в одном кадре: порядок хода берём по местам за столом
                # (по часовой: слева -> партнёр -> справа -> я), лидер = место, перед которым никого нет.
                _new = self._order_by_seats(_new, table_zone, self.mode)
            for c, _p in _new:
                if c not in self.table_order:
                    self.table_order.append(c)
            # Стол не может быть больше числа игроков: лишние карты — остаток прошлой взятки (в логах 10 из 34 взяток
            # были записаны с 4-6 картами при 3 игроках). Оставляем только карты текущей, ещё не завершённой взятки.
            _P = {"1v1": 2, "3p": 3, "2v2": 4}.get(self.mode, 4)
            if len(self.table_order) > _P:
                self.table_order = self.table_order[_P * (len(self.table_order) // _P):] or self.table_order[-_P:]
            table = list(self.table_order)
            # FIX: порядок карт на столе — по появлению, не по очереди. Если первой оказался козырь, а есть
            # масть (не козырь), в которой лежит 2+ карты — заходили именно ею (козырь её порезал): ставим её первой.
            if len(table) >= 3 and table[0].suit == trump:
                from collections import Counter
                cnt = Counter(c.suit for c in table if c.suit != trump)
                if cnt:
                    ls, k = cnt.most_common(1)[0]
                    if k >= 2:
                        first = next(c for c in table if c.suit == ls)
                        table.remove(first); table.insert(0, first)
            # (v67) Восстановление руки из «розданных» отключено: оно вызывало ложные сбросы раздачи. Только контроль:
            _d = getattr(self, "dealt", None)
            if _d and len(_d) == 8:
                _sh = {c for c, _ in hand_hits}
                _exp = _d - {c for c in _d if c not in _sh and (c in self.tracker.seen or c in table_cards_now or c in self.tracker.closed)}
                _since = time.time() - getattr(self.tracker, "_last_reset_t", 0.0)
                _dealing = _since < 12 and len(_exp) >= 7      # докладывают карты 5->8: рука ещё неполная, это не ошибка
                if not _sh and len(_exp) > 0:
                    # на экране рук нет вообще (раздача завершена / карты ещё не розданы) — это не ошибка распознавания
                    self._mm = 0
                    self._trace("hand_not_on_screen", expected=len(_exp), since_reset=round(_since, 1)) if getattr(self, "_hns", 0) % 30 == 0 else None
                    self._hns = getattr(self, "_hns", 0) + 1
                elif _sh and len(_sh) != len(_exp) and not _dealing and time.time() - getattr(self, "_dlg_t", 0) > 3.0:
                    self._mm = getattr(self, "_mm", 0) + 1
                    if self._mm in (15, 60):
                        self._trace("mismatch", seen=len(_sh), expected=len(_exp), since_reset=round(_since, 1))
                        self._shot("mismatch", min_gap=3.0, seen=len(_sh), expected=len(_exp))
                        try:
                            os.makedirs(os.path.join(os.path.dirname(__file__), "data", "mismatch"), exist_ok=True)
                            self.vision.save_debug(hand_zone, os.path.join(os.path.dirname(__file__), "data", "mismatch",
                                                   f"hand_{int(time.time())}_{len(_sh)}vs{len(_exp)}.png"))
                        except Exception:
                            pass
                else:
                    self._mm = 0
            # Одна карта не может быть и в руке, и на столе (в реальных логах ~12% советов): карта на столе уже сыграна —
            # убираем её из руки и из памяти руки; если на столе она лишь «держится» памятью (в кадре её нет) — убираем со стола.
            _both = set(hand) & set(table)
            if _both:
                _vis = {c for c, _ in table_hits}
                for c in _both:
                    if c in _vis:
                        self.hand_mem.pop(c, None); self.hand_seen_cnt.pop(c, None)
                    else:
                        self.table_order = [x for x in self.table_order if x != c]
                hand = [c for c in hand if not (c in _both and c in _vis)]
                table = [c for c in table if not (c in _both and c not in _vis)]
            stats = self.tracker.update(hand, table)
            try: self.memory.save_round(self.tracker, trump, hand)     # состояние раздачи переживает перезапуск
            except Exception: pass
            self.memory.on_table(hand, table, trump, {"1v1": 2, "3p": 3, "2v2": 4}[self.mode], self.tracker)
            if hand:     # быстрый гейт: считаем ход только когда вход стабилен 2 кадра и изменился
                in_sig = (tuple(hand), tuple(table), trump, getattr(self, "turn_now", None), getattr(self, "trump_fresh", True),
                          frozenset(self._screen_legal) if self._screen_legal else None)
                if in_sig == self.committed_sig:
                    _ow = getattr(self, "_opp_wait", None)
                    if _ow and _ow[0] == in_sig and time.time() - _ow[1] > 8:
                        self._opp_expired = in_sig; self.committed_sig = None      # 15 сек соперник не ходит — считаем, что заход мой
                    else:
                        self._autoplay_tick(hand_hits, hand_zone)   # совет не менялся -> проверяем «выдержку» и кликаем
                        return
                if in_sig != self.pending_sig:
                    self.pending_sig, self.pending_cnt = in_sig, 1
                else:
                    self.pending_cnt += 1
                if self.pending_cnt < 1:
                    return
                self.committed_sig = in_sig
                self._job += 1
            move, why, kw, extra = None, "", None, ""
            if not hand:
                self.empty_frames += 1
                if self.empty_frames < 10:
                    return          # не мигаем из-за пары пустых кадров
                why = "карты не видны — проверь рамку (F2)"
            else:
                if not getattr(self, "trump_fresh", True):
                    self._ap_ctx = None
                    self.result.emit({"hand": hand, "table": [], "trump": trump, "declarer": self.declarer_known, "move": None,
                                      "why": "новая раздача — жду, пока выберут козырь (старый не считаю)", "position": (sw//2, sh//4)})
                    return
                from engine.rules import who_takes_trick
                n = len(table)
                players = {"1v1": 2, "3p": 3, "2v2": 4}[self.mode]
                if n >= players:
                    try:
                        _res = self.decisions.resolve_from_table(table, trump)
                        if _res: self._trace("decision_outcome", **_res)
                    except Exception: pass
                if n >= players:
                    try:
                        _wi = who_takes_trick(table, trump)
                        _ws = self._card_seat.get(table[_wi])
                        _lt0 = self.memory.last_trick
                        if _ws is not None and (not _lt0 or _lt0[0] != tuple(table) or _lt0[1] != (_ws == 3)):
                            self.memory.last_trick = (tuple(table), _ws == 3)    # 3 = моё место (внизу)
                            self._trace("trick_winner_seat", table=[str(c) for c in table], winner=str(table[_wi]), seat=_ws, me=(_ws == 3))
                    except Exception:
                        pass
                lt = self.memory.last_trick
                if n >= players and lt and lt[0] == tuple(table) and lt[1]:
                    table = []; n = 0            # взятку взял я -> сразу подсказываю заход следующей
                _lt = self.memory.last_trick
                _i_lead = bool(_lt and _lt[1])
                _ts = getattr(self, "turn_now", None)
                if _ts == "other" and n < players:
                    self._ap_ctx = None
                    self.result.emit({"hand": hand, "table": table, "trump": trump, "declarer": self.declarer_known, "move": None,
                                      "why": "не мой ход — ходит соперник (кольцо у него)", "position": (sw//2, sh//4)})
                    return
                if _ts != "me" and n == 0 and self.tracker.tricks_done > 0 and not _i_lead and getattr(self, "_opp_expired", None) != in_sig:
                    # прошлую взятку взял НЕ я -> заход соперника: не мой ход, советов нет и кликать нельзя
                    if not getattr(self, "_opp_wait", None) or self._opp_wait[0] != in_sig:
                        self._opp_wait = (in_sig, time.time())
                    self._ap_ctx = None
                    self.result.emit({"hand": hand, "table": [], "trump": trump, "declarer": self.declarer_known, "move": None,
                                      "why": "ходит соперник (взятку взял не я) — жду его карту", "position": (sw//2, sh//4)})
                    return
                self._opp_wait = None
                if n >= players:
                    why = "взятка завершена — жду следующую"
                    self.result.emit({"hand": hand, "table": table, "trump": trump, "declarer": self.declarer_known, "move": None,
                                      "why": why, "position": (sw//2, sh//4)})
                    return
                # Ограничение «нельзя начинать козырем, пока не начал сыгравший»:
                if table and table[0].suit == trump:
                    self.trump_unlocked = True

                partner_wins = (self.mode == "2v2" and n >= 2 and
                                who_takes_trick(table, trump) == n - 2)
                mine, opp, limit = self.score
                step = 100 if self.mode == "1v1" else 10     # 1v1: очки, иначе били
                near = 16 * (10 if self.mode == "1v1" else 1)
                risk = "risky" if (limit - opp) <= near and (limit - mine) > near else \
                       "safe" if (limit - mine) <= near // 2 and (limit - opp) > near else "normal"
                kw = dict(trump_lead_allowed=(self.trump_unlocked or self.declarer_me),
                          is_partner_winning=partner_wins, snap=stats, i_declared=self.declarer_me,
                          last_to_play=(n == players - 1), risk=risk,
                          voids=(self.tracker.voids if self.mode == "2v2" else None))
                # Мгновенная подсказка по правилам (без MC) — появляется сразу после хода
                try:   # ♠/♣ в руке перепутаны с мастью заходной карты: иначе бот «режет козырем», хотя надо идти в масть
                    self._flip_map = {}
                    hand, _lf = lead_suit_fix(hand, table, set(self.tracker.closed) | set(self.tracker.seen), trump=trump,
                                              stable={c for c in hand if self.hand_seen_cnt.get(c, 0) >= 4})
                    self._flip_map = {b: a for a, b in _lf}
                    if _lf: self._trace("lead_suit_fix", flips=[f"{a}->{b}" for a, b in _lf], table=[str(c) for c in table])
                except Exception: pass
                tp = _trained_params()
                kw["lead_style"] = tp.get("lead_style", "small")
                if self.mode == "2v2" and tp.get("voids") and kw.get("voids") is None:
                    kw["voids"] = self.tracker.voids
                _banned = (set(self.tracker.closed) | set(self.tracker.seen)) - set(table)
                move, why = robust_recommend(lambda h_, t_: recommend_for_mode(h_, t_, trump, self.mode, use_mc=False, **kw),
                                             hand, table, trump, _banned, kw.get("trump_lead_allowed", True))   # мгновенное решение по правилам, без пересмотра; законно при любом прочтении ♠/♣
                try:    # подсказка игры: серые карты нельзя. Совет только из разрешённых; расхождения с rules.py пишем в журнал
                    _inv = {a: b for b, a in getattr(self, "_flip_map", {}).items()}
                    _sl = {_inv.get(c, c) for c in (self._screen_legal or ())}
                    _sl = {c for c in _sl if c in hand}
                    self._sl_now = _sl
                    if _sl:
                        _rl = set(legal_moves(hand, table, trump))
                        _vis = {c for c in hand if c in {x for x, _ in hand_hits} or _inv.get(c, c) in {x for x, _ in hand_hits}}
                        if (_rl & _vis) != _sl and getattr(self, "_lm_sig", None) != (frozenset(_sl), frozenset(_rl), tuple(table)):
                            self._lm_sig = (frozenset(_sl), frozenset(_rl), tuple(table))
                            self._trace("legal_mismatch", screen=sorted(str(c) for c in _sl), rules=sorted(str(c) for c in _rl),
                                        hand=[str(c) for c in hand], table=[str(c) for c in table], trump=trump)
                            self._shot("legal_mismatch", min_gap=3.0, screen=sorted(str(c) for c in _sl), rules=sorted(str(c) for c in _rl))
                        if move is None or move not in _sl:
                            _hr = [c for c in hand if c in _sl]
                            _m2, _w2 = robust_recommend(lambda h_, t_: recommend_for_mode(h_, t_, trump, self.mode, use_mc=False, **kw),
                                                        _hr, table, trump, _banned, kw.get("trump_lead_allowed", True))
                            if _m2 is not None and _m2 in _sl:
                                move, why = _m2, _w2 + " · игра затемнила остальные карты"
                            elif len(_sl) == 1:
                                move, why = next(iter(_sl)), "единственная разрешённая карта (остальные затемнены игрой)"
                            else:
                                move = sorted(_sl, key=lambda c: c.points(trump))[0]
                                why = "ход только из разрешённых игрой карт"
                except Exception as _e:
                    self._sl_now = set()
                if risk != "normal":
                    extra = " · " + ("соперник близок к победе — рискуем" if risk == "risky" else "я близок к победе — играю осторожно")
                    why += extra
            # Информационная строка: счёт карт, комбинации, Joc/Pas
            info = []
            guard_msg = None
            # FIX: сколько карт в руке должно быть (2v2: 8 минус сыгранные взятки). Если видно меньше — одна не распознана.
            if hand and self.mode in ("2v2", "3p"):
                done_tr = max(0, (len(self.tracker.seen - set(table)) // (4 if self.mode == "2v2" else 3)))
                if len(hand) < 8 - done_tr and table and move is not None and move.suit != table[0].suit:
                    guard_msg = "⛔ вижу не все карты в руке — если есть масть захода, ходи в масть"
            if guard_msg: info.append(guard_msg)
            if table and move is not None and move.suit != table[0].suit:
                lead_s = table[0].suit
                info.append(f"⚠ ход не в масть: если у тебя есть карта масти {lead_s} — она не распознана (F2 / Диагностика)")
            if getattr(self, 'new_round_hint', 0) > 0:
                self.new_round_hint -= 1
                info.append(f"новая раздача? проверь козырь (сейчас {trump}) — F5 ♠ F6 ♥ F7 ♦ F8 ♣")
            if hand:
                tl = trumps_left(stats, trump)
                if tl:
                    info.append(f"козырей у других: {len(tl)} (старший {tl[0]})")
                else:
                    info.append("козырей у других нет")
                info.append(f"очков у других: {points_left(stats, trump)}")
                if len(hand) >= 7 and not table:
                    combs = detect_combinations(hand, trump, self.mode)
                    names = [n_ for n_, _, _ in combs]
                    if "four_7" in names: info.append("ЧЕТЫРЕ 7 — раздача отменяется!")
                    if "belot" in names: info.append("BELOT: все 8 карт козыря — мгновенная победа!")
                    if "four_8" in names: info.append("ЧЕТЫРЕ 8 — комбинации всех аннулируются (кроме Bella)")
                    if any(n_ == "bella" for n_ in names): info.append("Bella: нажми кнопку ДО того, как положишь Q или K козыря")
                    if self.mode == "2v2" and sum(c.points(trump) for c in hand) < 14:
                        info.append("меньше 14 очков — можно отменить раздачу")
                    cp = total_points(combs, trump)
                    if cp: info.append(f"комбинации {cp} очков — объяви в первых 2 взятках")
                if len(hand) in (5, 6) and not table:
                    ok, txt = should_play(hand, trump, min_score=_trained_params().get('min_score', 50), behind_bile=(self.score[1] - self.score[0]) // (10 if self.mode == "1v1" else 1), mode=self.mode)
                    info.append(txt)
                    from engine.strategy import best_suit
                    bs = best_suit(hand)
                    if bs and bs[0] != trump:
                        info.append(f"для 2-го тура лучшая масть: {bs[0]} ({bs[1]})")
            if move is not None:
                self.memory.on_advice(hand, table, trump, move, why, self.score)
                ins = self.memory.insight(why)
                if ins: info.append(ins)
            payload = {"hand": hand, "table": table, "trump": trump, "declarer": self.declarer_known, "info": info,
                       "move": move, "why": why, "position": (sw//2, sh//4)}
            try:
                _did = self.decisions.record(hand, table, trump, move, why, self.score)
                _prob = check_state(hand, table, self.tracker.seen, self.mode)
                if _prob: self._trace("state_invalid", problems=_prob)
                _cm = CardMemory(self.tracker).analyse(hand, table)
                if _cm["contradictions"]:
                    self._trace("memory_contradiction", cards=[str(c) for c in _cm["contradictions"]], voids={k: sorted(v) for k, v in self.tracker.voids.items()})
                if _cm["certain"] and move is not None:
                    self._trace("memory_certain", holders={str(c): p for c, p in _cm["certain"].items()})
            except Exception:
                _did = None
            self._trace("advice", hand=[str(c) for c in hand], table=[str(c) for c in table], trump=trump,
                        move=str(move) if move else None, why=why, latency_ms=round((time.time() - getattr(self, "_t0", time.time())) * 1000))
            self.result.emit(payload)
            try:   # автоклик по посоветованной карте (кнопка в окне / F4)
                _P = {"1v1": 2, "3p": 3, "2v2": 4}.get(self.mode, 4)
                _n = len(table)
                _lead = bool(self.memory.last_trick and self.memory.last_trick[1])     # я взял прошлую взятку -> заход мой
                _base = getattr(config, 'AUTOPLAY_HOLD', 1.0)
                _need = _base if _n == _P - 1 else (_base + 0.5 if (_n == 0 and _lead) else (getattr(config, 'AUTOPLAY_FIRST_WAIT', 4.0) if (_n == 0 and self.tracker.tricks_done == 0) else getattr(config, 'AUTOPLAY_WAIT_UNSURE', 3.0)))
                self._ap_ctx = dict(need=_need, move=move, legal=((list(getattr(self, "_sl_now", ()) or []) or legal_moves(hand, table, trump)) if move else []), hand=hand, table=table, trump=trump,
                                    my_turn=(True if getattr(self, "turn_now", None) == "me" else
                                             False if getattr(self, "turn_now", None) == "other" else
                                             bool(hand) and len(hand) == 8 - self.tracker.tricks_done and len(table) < _P))
                # не спешим: даже при подтверждении кольцом нужна полностью распознанная рука (все карты на месте)
                # Рука короче ожидаемой (карта не распознана): кликаем только если ход заведомо законен без неё —
                # заход (стол пуст) или ход в масть захода. Раньше бот в таких случаях просто не кликал.
                if self._ap_ctx["my_turn"] and bool(hand) and len(hand) != 8 - self.tracker.tricks_done:
                    _short_ok = len(hand) < 8 - self.tracker.tricks_done and move is not None and not table     # только заход: любая карта законна; в масть/козырь при неполной руке не кликаем (масть стола могла быть прочитана неверно)
                    if len(hand) > 8 - self.tracker.tricks_done or not _short_ok:
                        self._ap_ctx["my_turn"] = False
                if getattr(self, "turn_now", None) == "me":
                    self._ap_ctx["need"] = getattr(config, "AUTOPLAY_HOLD_RING", 0.3)
                self._autoplay_tick(hand_hits, hand_zone)
            except Exception as e:
                self.autoplay.enabled = False
                self.log.emit("Автоклик выключен из-за ошибки: " + str(e))
            # Уточнение расчётом сценариев — в фоне; применяется, только если на столе всё ещё то же самое
            # решение окончательное: фоновый пересмотр отключён (совет больше не меняется после показа)
        except Exception as e:
            self.log.emit("Ошибка анализа: " + str(e))

    def _five_eval(self, sw, sh):
        """Торги: сразу по первым 5 картам — стоит ли играть (Joc/Pas) и какая масть лучшая."""
        from engine.strategy import should_play, best_suit
        sym = {"spades": "♠", "hearts": "♥", "diamonds": "♦", "clubs": "♣"}
        hz = config.scaled_zone(config.ZONE_MY_HAND, sw, sh)
        hand = sorted({c for c, _ in self.vision.detect_cards(hz, dim=True)}, key=str)
        if len(hand) < 4:
            return None
        mp = _trained_params().get("min_score", 50)
        lines = [f"Карты (вижу {len(hand)} из 5): " + " ".join(map(str, hand))]
        offered = [s_ for s_ in (self._bid_suits or []) if s_]
        for s_ in offered[:1]:
            ok, why = should_play(hand, s_, min_score=mp, mode=self.mode)
            lines.append(f"Предложен {sym.get(s_, s_)}: {'JOC — играть' if ok else 'PAS — пас'} ({why})")
        bs = best_suit(hand)
        if bs:
            ok, why = should_play(hand, bs[0], min_score=mp, mode=self.mode)
            lines.append(f"Лучшая масть: {sym.get(bs[0], bs[0])} (оценка {bs[1]}) → {'играть' if ok else 'пас'}")
        return "\n".join(lines)

    def _bid_tick(self, sw, sh):
        """Торги (Joc/Pas, выбор козыря во 2-м круге) и кнопки комбинаций слева. Только при включённом автокликe."""
        if not self.autoplay.enabled:
            self.bid.reset()
            try:
                if self._bid_n % 6 == 0:
                    bt0 = find_bid_buttons(self.vision.capture(config.scaled_zone(config.ZONE_BID_PANEL, sw, sh)))
                    seen = bool(bt0["green"] or bt0["red"] or bt0["white"])
                    if seen and not self._bid_seen_off:
                        self.log.emit("Вижу панель Joc/Pas — включи «Автоклик», чтобы бот нажал сам (оценка карт — в подсказке).")
                    self._bid_seen_off = seen
                    if not seen: self._bid_suits = []
                self._bid_n += 1
            except Exception:
                pass
            return
        try:
            self._bid_n += 1
            in_bid = False
            if getattr(config, "BID_AUTO", True) and self._bid_n % 2 == 0:
                bz = config.scaled_zone(config.ZONE_BID_PANEL, sw, sh)
                img = self.vision.capture(bz)
                bt = find_bid_buttons(img)
                if bt["green"] or bt["red"] or bt["white"]:
                    in_bid = True
                    hz = config.scaled_zone(config.ZONE_MY_HAND, sw, sh)
                    hand = sorted({c for c, _ in self.vision.detect_cards(hz, dim=True)}, key=str)
                    if bt["white"]:
                        suits = [white_blob_suit(img, b, self.vision.classify_trump_icon) for b in bt["white"]]
                    else:
                        suits = [blob_suit(img, b, self.vision.classify_trump_icon) for b in bt["green"]]
                    self._bid_suits = suits
                    from engine.strategy import should_play, best_suit, evaluate_hand
                    act = self.bid.step(hand, bt, suits, bz, lambda h, t: should_play(h, t, min_score=_trained_params().get("min_score", 50), mode=self.mode),
                                        best_suit, lambda h, t: evaluate_hand(h, t)[0])
                    if act:
                        self._trace("bid_click", act=act, hand=[str(c) for c in hand], suits=suits)
                        self.log.emit(f"Торги: {act} · рука {', '.join(map(str, hand))}")
                else:
                    self.bid.reset(); self._bid_suits = []
            if getattr(config, "COMBO_AUTO", True) and not in_bid:
                cz = config.scaled_zone(config.ZONE_COMBO, sw, sh)
                p = self.combo.feed(self.vision.capture(cz))      # следующая НЕнажатая кнопка (их может быть несколько)
                if p and time.time() - self._combo_t > 0.8:       # по одной кнопке за раз, с короткой паузой
                    self._combo_t = time.time()
                    self._combo_click(cz[0] + p[0], cz[1] + p[1])
                    self.combo.mark_clicked(p)
                    self._trace("combo_click", at=p, left=len(self.combo.visible))
                    self.log.emit("Комбинация: нажал кнопку слева (Bella / Jumate Suta / ...)")
        except Exception as e:
            self.log.emit("Торги/комбинации: " + str(e))

    def _autoplay_tick(self, hand_hits, hand_zone):
        """Вызывается КАЖДЫЙ кадр (и когда совет не менялся) — иначе «выдержка» перед кликом никогда не пройдёт."""
        ctx = getattr(self, "_ap_ctx", None)
        if not ctx or not self.autoplay.enabled:
            return
        try:
            _pos = {c: p for c, p in hand_hits}
            for _b, _a in getattr(self, "_flip_map", {}).items():
                if _a in _pos: _pos[_b] = _pos[_a]
            def _verify(p, _mv=ctx["move"], _hand=ctx["hand"], _hz=hand_zone):
                """Свежий кадр перед кликом: под курсором должна быть карта того же номинала и цвета, число карт в руке то же."""
                fresh = self.vision.detect_cards(_hz, dim=True)
                if len(fresh) != len(_hand):
                    return False
                raw = getattr(self, "_flip_map", {}).get(_mv, _mv)
                black = ("spades", "clubs"); red = ("hearts", "diamonds")
                same_col = lambda a, b: a == b or (a in black and b in black) or (a in red and b in red)
                near = [c for c, q in fresh if abs(q[0] - p[0]) <= 14]
                return any(c.rank == raw.rank and same_col(c.suit, raw.suit) for c in near) and len(near) >= 1
            _act = self.autoplay.step(ctx["move"], ctx["legal"], ctx["hand"], ctx["table"], ctx["trump"], (ctx["my_turn"] and getattr(self, "turn_now", None) != "other"), _pos, hand_zone, hold=ctx.get("need"), verify=_verify)
            if _act == "click": self._trace("autoplay_click", move=str(ctx["move"])); self.log.emit(f"Автоклик: {ctx['move']}")
            elif _act == "verify_failed":
                self._trace("autoplay_verify_failed", move=str(ctx["move"]))
            elif _act == "retry":
                self._trace("autoplay_retry", move=str(ctx["move"]))
            elif _act == "stopped":
                self._trace("autoplay_stopped", move=str(ctx["move"])); self.log.emit("Автоклик выключен: карта не сыграна после нескольких попыток")
                self.autoplay_off.emit()
        except Exception as e:
            self.autoplay.enabled = False
            self.autoplay_off.emit()
            self.log.emit("Автоклик выключен из-за ошибки: " + str(e))

    def _refine_async(self, hand, table, trump, kw, payload, extra):
        from concurrent.futures import ThreadPoolExecutor
        if self._pool is None:
            self._pool = ThreadPoolExecutor(max_workers=1)
        job, sig = self._job, self.committed_sig
        def run():
            try:
                if job != self._job:
                    return
                move, why = robust_recommend(lambda h_, t_: recommend_for_mode(h_, t_, trump, self.mode, use_mc=True,
                                                                              budget=0.35, max_samples=500, **kw),
                                             hand, table, trump, (set(self.tracker.closed) | set(self.tracker.seen)) - set(table),
                                             kw.get("trump_lead_allowed", True))
                if move is None or job != self._job or sig != self.committed_sig:
                    return                      # ситуация уже изменилась — результат устарел
                p = dict(payload); p["move"] = move; p["why"] = why + extra
                self.memory.last_advice = (move, why + extra)
                self.result.emit(p)
            except Exception as e:
                self.log.emit("Ошибка расчёта: " + str(e))
        self._pool.submit(run)

class MainWindow(QWidget):
    hotkey_suit = pyqtSignal(str)
    hotkey_pause = pyqtSignal()
    hotkey_zones = pyqtSignal()
    hotkey_auto = pyqtSignal()
    stop_worker = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Belot AI Assistant")
        self.resize(560, 600)
        self.setStyleSheet("""
            QWidget{background:#202832;color:#e8eef5;font-size:14px}
            QPushButton,QComboBox{padding:9px;background:#344454;border-radius:8px}
            QPushButton:hover{background:#46627a}
            QTextEdit{background:#101820;border:1px solid #445;color:#b8f5ce}
            QGroupBox{border:1px solid #536273;border-radius:10px;margin-top:10px;padding:10px}
        """)
        root = QVBoxLayout(self)
        header = QLabel("🎴  BELOT AI ASSISTANT")
        header.setStyleSheet("font-size:22px;font-weight:bold")
        root.addWidget(header)
        root.addWidget(QLabel("Режим игры:"))
        self.mode_combo = QComboBox()
        for key, label in MODE_LABELS.items():
            self.mode_combo.addItem(label, key)
        root.addWidget(self.mode_combo)
        self.declarer_cb = QCheckBox("Я объявил козырь (могу начинать козырем)")
        self.declarer_cb.toggled.connect(lambda v: self.worker and (setattr(self.worker, '_manual_decl', True), self.worker.set_declarer(v), setattr(self.worker, '_manual_decl', False)))
        root.addWidget(self.declarer_cb)
        self.status = QLabel("● Остановлен")
        root.addWidget(self.status)
        row = QHBoxLayout()
        self.start_btn, self.pause_btn = QPushButton("▶ Запустить анализ"), QPushButton("Ⅱ Пауза")
        self.pause_btn.setEnabled(False)
        row.addWidget(self.start_btn); row.addWidget(self.pause_btn); root.addLayout(row)
        suits = QGroupBox("Козырь (F5 ♠ · F6 ♥ · F7 ♦ · F8 ♣  или V R D C)")
        grid = QGridLayout(suits)
        for i, (key, symbol) in enumerate([("v","♠"),("r","♥"),("d","♦"),("c","♣")]):
            b = QPushButton(f"{symbol}  [{key.upper()}]")
            b.clicked.connect(lambda checked=False, k=key: self.set_suit(k))
            grid.addWidget(b, 0, i)
        root.addWidget(suits)
        self.auto_btn = QPushButton("🤖 Автоклик: ВЫКЛ (F4)")
        self.auto_btn.setCheckable(True)
        self.auto_btn.setStyleSheet("QPushButton:checked{background:#2e8b57;font-weight:bold}")
        root.addWidget(self.auto_btn)
        self.auto_wanted = bool(getattr(config, 'AUTOPLAY', False))
        row2 = QHBoxLayout()
        self.zones_btn, self.debug_btn = QPushButton("F2 · Показать зоны"), QPushButton("Диагностика шаблонов")
        row2.addWidget(self.zones_btn); row2.addWidget(self.debug_btn); root.addLayout(row2)
        self.log = QTextEdit(); self.log.setReadOnly(True)
        root.addWidget(QLabel("Журнал событий")); root.addWidget(self.log)
        self.overlay = OverlayWindow()
        self.running = False
        self.worker_thread = self.worker = None
        self.start_btn.clicked.connect(self.start)
        self.pause_btn.clicked.connect(self.toggle_pause)
        self.zones_btn.clicked.connect(self.toggle_zones)
        self.debug_btn.clicked.connect(self.diagnostics)
        self.hotkey_suit.connect(self.set_suit)
        self.hotkey_pause.connect(self.toggle_pause)
        self.hotkey_zones.connect(self.toggle_zones)
        self.hotkey_auto.connect(self.toggle_autoplay)
        self.auto_btn.clicked.connect(lambda checked=False: self.set_autoplay(self.auto_btn.isChecked()))
        self._sync_auto_btn()
        self.listener = keyboard.Listener(on_press=self.on_key); self.listener.start()
        self.log.append("Выбери режим, козырь и запусти анализ. F2 — зоны, F3 — пауза.")

    def start(self):
        if self.running: return
        mode = self.mode_combo.currentData()
        self.worker_thread = QThread(self)
        self.worker = Worker(mode); self.worker.moveToThread(self.worker_thread)
        self.stop_worker.connect(self.worker.stop)
        self.worker_thread.started.connect(self.worker.start)
        self.worker.result.connect(self.overlay.set_recommendation)
        self.worker.log.connect(self.log.append)
        self.worker.autoplay_off.connect(lambda: self.set_autoplay(False, quiet=True))
        self.worker.autoplay.enabled = self.auto_wanted
        self.worker.finished.connect(self.worker_thread.quit)
        self.worker_thread.start()
        self.running = True
        self.start_btn.setEnabled(False); self.mode_combo.setEnabled(False); self.pause_btn.setEnabled(True)
        self.status.setText("● Анализ активен — " + MODE_LABELS[mode])
        self.log.append("Запущен режим: " + MODE_LABELS[mode])

    def stop(self):
        if self.worker: self.stop_worker.emit()
        self.running = False
        self.start_btn.setEnabled(True); self.mode_combo.setEnabled(True); self.pause_btn.setEnabled(False)
        self.status.setText("● Остановлен")

    def toggle_pause(self):
        if self.running and self.worker:
            self.worker.pause()
            self.status.setText("● Пауза / анализ")

    def set_suit(self, key):
        suit = {"v":"spades","r":"hearts","d":"diamonds","c":"clubs"}.get(key, key)
        config.TRUMP_SUIT = suit
        symbols = {"spades":"♠","hearts":"♥","diamonds":"♦","clubs":"♣"}
        self.log.append("Козырь вручную: " + symbols.get(suit, suit))
        if self.worker: self.worker.set_trump(suit)

    def _sync_auto_btn(self):
        self.auto_btn.blockSignals(True)
        self.auto_btn.setChecked(self.auto_wanted)
        self.auto_btn.setText("🤖 Автоклик: ВКЛЮЧЁН (F4 — выкл.)" if self.auto_wanted else "🤖 Автоклик: ВЫКЛ (F4)")
        self.auto_btn.blockSignals(False)

    def set_autoplay(self, on, quiet=False):
        self.auto_wanted = bool(on)
        w = getattr(self, "worker", None)
        if w is not None:
            w.autoplay.enabled = self.auto_wanted
            w.autoplay._reset()
        self._sync_auto_btn()
        if not quiet:
            self.log.append("Автоклик ВКЛЮЧЁН — бот сам кликает по посоветованной карте в твой ход." if on else "Автоклик выключен")
            if on and w is None: self.log.append("(сработает после запуска анализа)")

    def toggle_autoplay(self):
        self.set_autoplay(not self.auto_wanted)

    def toggle_zones(self):
        self.overlay.toggle_debug()
        self.log.append("Отображение зон переключено.")

    def diagnostics(self):
        try:
            v = VisionEngine()
            sw, sh = v.screen_size()
            hz = config.scaled_zone(config.ZONE_MY_HAND, sw, sh)
            tz = config.scaled_zone(config.ZONE_TABLE, sw, sh)
            hh, nh = v.save_debug(hz, "debug_hand.png", dim=True)
            th, nt = v.save_debug(tz, "debug_table.png")
            self.log.append(f"Шаблоны: {len(v.templates)}/32. Рука: рамок {nh}, карт {len(hh)} {hh}")
            self.log.append(f"Стол: рамок {nt}, карт {len(th)} {th}")
            self.log.append("Сохранены debug_hand.png и debug_table.png рядом с main.py — пришли их, если карты пропускаются.")
            v.close()
        except Exception as e:
            self.log.append("Диагностика: " + str(e))

    def on_key(self, key):
        try: ch = key.char.lower() if key.char else None
        except AttributeError: ch = None
        fk = {keyboard.Key.f5: "v", keyboard.Key.f6: "r", keyboard.Key.f7: "d", keyboard.Key.f8: "c"}
        if key in fk: self.hotkey_suit.emit(fk[key])
        elif ch in ("v","r","d","c"): self.hotkey_suit.emit(ch)
        elif key == keyboard.Key.f2: self.hotkey_zones.emit()
        elif key == keyboard.Key.f3: self.hotkey_pause.emit()
        elif key == keyboard.Key.f4: self.hotkey_auto.emit()

    def closeEvent(self, event):
        self.stop(); self.listener.stop(); self.overlay.close(); event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
