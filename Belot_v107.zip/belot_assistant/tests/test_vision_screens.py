# Регрессия распознавания руки по реальным скриншотам belot.md (1279x719).
import os, sys, types
import cv2
try:
    import mss  # noqa
except ImportError:
    sys.modules["mss"] = types.SimpleNamespace(mss=lambda: None)
import config
from engine.vision import VisionEngine

SYM = {"hearts": "h", "diamonds": "d", "clubs": "c", "spades": "s"}
TRUTH = {
    1: ["Jd", "Ad", "9h", "10h", "Ah", "Jc", "Qc", "Kc"],   # кнопки Tărț/Bella закрывают первую карту
    2: ["10c", "Jc", "Kc", "9h"],
    3: ["9c", "10d", "9s", "Js", "Ks"],
    4: ["9c", "10h", "Qh", "9s", "Js", "Ks", "10d", "Kd"],
    5: ["9h", "10h", "Ah", "9c", "Qc", "9d", "Ad", "As"],
}

def test_hand_screens():
    here = os.path.dirname(__file__)
    v = VisionEngine()
    for i, truth in TRUTH.items():
        img = cv2.imread(os.path.join(here, "screens", f"s{i}.png"))
        H, W = img.shape[:2]
        x, y, w, h = config.scaled_zone(config.ZONE_MY_HAND_OLD, W, H)
        hits = v.detect_cards_in_image(img[y:y+h, x:x+w], vmin=105)
        got = [c.rank + SYM[c.suit] for c, _ in hits]
        assert got == truth, f"скриншот {i}: {got} != {truth}"


def test_hand_screens_other_resolutions():
    """Тот же стол на экранах 1920x1080 и 2560x1440 (зоны масштабируются от 1279x719)."""
    here = os.path.dirname(__file__)
    v = VisionEngine()
    for i, truth in TRUTH.items():
        base = cv2.imread(os.path.join(here, "screens", f"s{i}.png"))
        for W, H in ((1920, 1080), (2560, 1440)):
            img = cv2.resize(base, (W, H), interpolation=cv2.INTER_CUBIC)
            x, y, w, h = config.scaled_zone(config.ZONE_MY_HAND_OLD, W, H)
            hits = v.detect_cards_in_image(img[y:y+h, x:x+w], vmin=105)
            got = [c.rank + SYM[c.suit] for c, _ in hits]
            assert got == truth, f"скриншот {i} {W}x{H}: {got} != {truth}"


NEW = {  # экран 1918x1078, режим 2 на 2: (рука, стол)
    1: (["7c", "9c", "9h", "Jh", "7s", "Js", "Ks"], ["9d"]),
    2: (["Qd", "Kd", "7s", "9h", "10h", "Qh", "7c", "Qc"], ["Ac"]),
    3: (["Jc", "Qc", "Ac", "9h", "7s", "As", "7d", "Kd"], ["Ad"]),
    4: (["Qh", "8c", "Jc", "Qc", "Kc", "Qd", "Ad", "10s"], ["7s"]),
}

def test_hand_and_table_2v2_screens():
    here = os.path.dirname(__file__)
    v = VisionEngine()
    for i, (hand, table) in NEW.items():
        img = cv2.imread(os.path.join(here, "screens", f"n{i}.png"))
        H, W = img.shape[:2]
        x, y, w, h = config.scaled_zone(config.ZONE_MY_HAND_OLD, W, H)
        got = [c.rank + SYM[c.suit] for c, _ in v.detect_cards_in_image(img[y:y+h, x:x+w], vmin=105)]
        assert got == hand, f"рука {i}: {got} != {hand}"
        x, y, w, h = config.scaled_zone(config.ZONE_TABLE, W, H)
        got = [c.rank + SYM[c.suit] for c, _ in v.detect_cards_in_image(img[y:y+h, x:x+w], vmin=185, scale=W / 1279.0)]
        assert got == table, f"стол {i}: {got} != {table}"
