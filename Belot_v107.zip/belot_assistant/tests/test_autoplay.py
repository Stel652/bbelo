from engine.autoplay import AutoPlayer
from engine.cards import Card
def C(s, r): return Card(s, r)

class Clock:
    t = 100.0
    def __call__(self): return self.t

def make():
    clicks, clk = [], Clock()
    ap = AutoPlayer(lambda x, y: clicks.append((x, y)), hold=1.0, retry_after=2.5, max_clicks=3, now=clk, min_frames=1)
    ap.enabled = True
    return ap, clicks, clk

A = C("hearts", "A"); K = C("spades", "K")
ARGS = dict(move=A, legal=[A, K], hand=[A, K], table=[], trump="hearts", my_turn=True,
            pos={A: (50, 40), K: (150, 40)}, zone=(320, 568, 638, 107))

def test_disabled_by_default_and_toggle():
    ap = AutoPlayer(lambda x, y: None)
    assert ap.enabled is False and ap.step(**ARGS) is None
    assert ap.toggle() is True and ap.toggle() is False

def test_clicks_only_after_hold_and_at_card_position():
    ap, clicks, clk = make()
    assert ap.step(**ARGS) is None and clicks == []          # первый кадр: ждём
    clk.t += 0.5; assert ap.step(**ARGS) is None             # ещё рано
    clk.t += 0.6; assert ap.step(**ARGS) == "click"
    assert clicks == [(320 + 50, 568 + 40)]
    clk.t += 1.0; assert ap.step(**ARGS) is None             # ждём результат, не кликаем повторно
    assert len(clicks) == 1

def test_never_clicks_illegal_card_or_not_my_turn():
    ap, clicks, clk = make()
    for kw in (dict(legal=[K]), dict(my_turn=False), dict(pos={K: (150, 40)}), dict(move=None), dict(pos={A: (900, 40), K: (1, 1)})):
        ap._reset(); a = {**ARGS, **kw}
        ap.step(**a); clk.t += 2; assert ap.step(**a) is None
    assert clicks == []

def test_changed_advice_restarts_timer():
    ap, clicks, clk = make()
    ap.step(**ARGS); clk.t += 0.9
    ap.step(**{**ARGS, "move": K}); clk.t += 0.9              # совет сменился — таймер заново
    assert ap.step(**{**ARGS, "move": K}) is None and clicks == []

def test_stops_after_failed_attempts():
    ap, clicks, clk = make()
    ap.step(**ARGS); clk.t += 1.1
    res = []
    for _ in range(8):
        res.append(ap.step(**ARGS)); clk.t += 2.6
    assert res.count("click") >= 3 and "retry" in res and ap.enabled is True     # больше не выключается навсегда
    assert all(c == (370, 608) for c in clicks)


def test_set_enabled_flag_and_repeated_ticks_click():
    """Регресс: step() вызывается каждый кадр при неизменном совете — клик происходит после HOLD."""
    ap, clicks, clk = make()
    ap.step(**ARGS)
    for _ in range(30):
        clk.t += 0.1; ap.step(**ARGS)
    assert len(clicks) >= 1


def test_bid_clicker_smoke():
    from engine.bidding import BidClicker
    from engine.strategy import should_play, best_suit, evaluate_hand
    hand = [C("hearts", "Q"), C("diamonds", "A"), C("spades", "10"), C("hearts", "J"), C("hearts", "K")]
    clicks, t = [], [0.0]
    bc = BidClicker(lambda x, y: clicks.append((x, y)), now=lambda: t[0])
    bt = {"green": [{"c": (146, 56)}], "red": [{"c": (290, 55)}]}
    for _ in range(15):
        t[0] += 0.2
        bc.step(hand, bt, ["hearts"], (477, 469, 329, 92), lambda h, s: should_play(h, s), best_suit, lambda h, s: evaluate_hand(h, s)[0])
    assert len(clicks) == 1


def test_combo_button_detected_only_on_green_plate():
    import numpy as np, cv2
    from engine.bidding import find_combo_buttons
    bg = np.full((144, 237, 3), (25, 20, 15), np.uint8)
    assert find_combo_buttons(bg) == []
    img = bg.copy(); cv2.rectangle(img, (13, 100), (223, 140), (60, 170, 70), -1); cv2.putText(img, "Patru carti J", (40, 128), 0, 0.7, (255, 255, 255), 2)
    r = find_combo_buttons(img); assert len(r) == 1 and 100 < r[0]["c"][1] < 140
    fan = bg.copy(); cv2.circle(fan, (60, 50), 40, (60, 60, 200), 3)       # круг/рамка — не кнопка
    assert find_combo_buttons(fan) == []


def test_combo_watcher_clicks_every_stacked_button():
    """Регресс: раньше жалась только первая кнопка комбинации; теперь — все по очереди (Bella + Tertz + 50 ...)."""
    import numpy as np, cv2
    from engine.bidding import find_combo_buttons, ComboWatcher
    img = np.full((204, 237, 3), (25, 20, 15), np.uint8)
    for i in range(3):
        y = 150 - i * 46
        cv2.rectangle(img, (13, y), (223, y + 40), (60, 170, 70), -1); cv2.putText(img, "Bella", (40, y + 28), 0, 0.7, (255, 255, 255), 2)
    assert len(find_combo_buttons(img)) == 3
    w, got = ComboWatcher(), []
    for _ in range(8):      # кнопки не исчезают -> повтор только позже (persist+8 кадров)
        c = w.feed(img)
        if c: got.append(c); w.mark_clicked(c)
    assert len(got) == 3 and len(set(got)) == 3


def test_combo_ignores_red_card_art():
    import numpy as np, cv2
    from engine.bidding import find_combo_buttons
    img = np.full((204, 237, 3), (25, 20, 15), np.uint8)
    cv2.rectangle(img, (13, 150), (223, 190), (40, 40, 220), -1); cv2.putText(img, "Q", (40, 180), 0, 0.7, (255, 255, 255), 2)
    assert find_combo_buttons(img) == []


def test_no_click_before_min_frames_identical():
    """Клик после >=2 одинаковых кадров подряд и выдержки."""
    clicks, clk = [], Clock()
    ap = AutoPlayer(lambda x, y: clicks.append((x, y)), hold=1.0, now=clk, min_frames=2); ap.enabled = True
    ap.step(**ARGS); clk.t += 1.5
    assert ap.step(**ARGS) == "click"                                # 2-й одинаковый кадр + выдержка


def test_verify_blocks_click_on_wrong_card():
    """Свежий кадр не подтвердил карту под курсором -> клика нет."""
    clicks, clk = [], Clock()
    ap = AutoPlayer(lambda x, y: clicks.append((x, y)), hold=0.5, now=clk, min_frames=1); ap.enabled = True
    ap.step(**ARGS); clk.t += 1.0
    assert ap.step(**ARGS, verify=lambda p: False) == "verify_failed" and clicks == []
    ap.step(**ARGS); clk.t += 1.0
    assert ap.step(**ARGS, verify=lambda p: True) == "click" and len(clicks) == 1
