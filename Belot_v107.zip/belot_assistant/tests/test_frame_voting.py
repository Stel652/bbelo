import json
from engine.cards import Card
from engine.frame_voting import FrameVoter, HIGH, LOW
from tools.mismatch_manifest import build, confirmed

def C(s, r): return Card(s, r)

def test_single_frame_glitch_ignored():
    v = FrameVoter(5, 3); a, b = C("clubs", "9"), C("hearts", "A")
    for _ in range(4): v.push({a})
    conf, lv = v.push({a, b})
    assert a in conf and b not in conf and lv[b] == LOW
    assert v.reliable_hand(expected_len=2) is None and v.reliable_hand(1) == {a}

def test_high_confidence():
    v = FrameVoter(3, 3)
    for _ in range(3): conf, lv = v.push({C("clubs", "9")})
    assert lv[C("clubs", "9")] == HIGH

def test_manifest_requires_confirmation(tmp_path):
    (tmp_path / "hand_1_6vs8.png").write_bytes(b"x")
    c = build(str(tmp_path))
    assert c["hand_1_6vs8.png"]["status"] == "unlabeled" and not confirmed(str(tmp_path))
    c["hand_1_6vs8.png"].update(status="confirmed", labels=["9♣"])
    json.dump(c, open(tmp_path / "labels.json", "w", encoding="utf-8"))
    assert len(confirmed(str(tmp_path))) == 1
