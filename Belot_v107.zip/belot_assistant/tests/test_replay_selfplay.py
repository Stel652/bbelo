import random
from train_selfplay import play_round, BASE
from engine.replay import verify_round

def test_selfplay_rounds_fully_recorded_and_replayable():
    rng = random.Random(7)
    for _ in range(25):
        r, viol, info = play_round(rng, [BASE, BASE], rng.randrange(4))
        assert not viol
        assert len(info["moves"]) == 32 and len(info["tricks"]) == 8
        assert verify_round(info) == []

def test_verify_detects_corruption():
    rng = random.Random(1)
    _, _, info = play_round(rng, [BASE, BASE], 0)
    info["moves"][5][1] = (info["moves"][5][1] + 1) % 4
    assert verify_round(info)
