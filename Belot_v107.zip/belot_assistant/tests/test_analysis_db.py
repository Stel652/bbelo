import json
from engine.cards import Card
from engine.decision_tracker import DecisionTracker
from engine.decision_analysis import load, analyse
from engine.player_tracker import PlayerTracker
from database.db import connect, import_all

def C(s, r): return Card(s, r)

def _make(tmp_path):
    p = tmp_path / "decisions.jsonl"
    t = DecisionTracker("2v2", str(p))
    for _ in range(2):
        hand = [C("clubs", "9"), C("hearts", "A")]
        t.record(hand, [C("clubs", "8")], "diamonds", C("clubs", "9"), "Старшая · тест")
        t.link_played(C("clubs", "9"))
        t.resolve_from_table([C("clubs", "8"), C("clubs", "9"), C("clubs", "A"), C("clubs", "7")], "diamonds")
        t.pending = None
    return p

def test_analysis_and_db(tmp_path):
    p = _make(tmp_path)
    rows = analyse(load(str(p)), min_n=1)
    assert rows and rows[0]["reason"] == "Старшая" and rows[0]["done"] >= 1 and rows[0]["win_rate"] == 0.0
    con = connect(str(tmp_path / "b.db")); import_all(con, str(tmp_path))
    assert con.execute("SELECT COUNT(*) FROM decisions").fetchone()[0] >= 1
    assert con.execute("SELECT COUNT(*) FROM outcomes").fetchone()[0] >= 1

def test_player_tracker_min_obs():
    pt = PlayerTracker()
    pt.observe_trick([C("clubs", "8"), C("hearts", "7"), C("diamonds", "9"), C("clubs", "A")], C("clubs", "A"), "diamonds")
    pr = pt.profile(1)
    assert pr["observations"] == 1 and pr["reliable"] is False
