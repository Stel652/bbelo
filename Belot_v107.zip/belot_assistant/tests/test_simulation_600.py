# 600 случайных раздач целиком (8 взяток, 4 игрока): каждый совет бота должен быть легальным,
# из моей руки и не повторять уже сыгранную карту.
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.cards import Card, SUITS
from engine.rules import can_play_card, who_takes_trick
from engine.strategy import recommend_for_mode
from engine.tracker import CardTracker

DECK = [Card(s, r) for s in SUITS for r in ("7", "8", "9", "10", "J", "Q", "K", "A")]

def run(deals=600, seed=2026):
    rng = random.Random(seed)
    checked = 0
    for d in range(deals):
        trump = rng.choice(SUITS)
        cards = DECK[:]; rng.shuffle(cards)
        hands = {i: cards[i * 8:(i + 1) * 8] for i in range(4)}
        tr = CardTracker("2v2")
        leader, played_by_me, lead_ok = rng.randrange(4), set(), rng.random() < 0.5
        use_mc = d % 3 == 0
        for trick in range(8):
            table = []
            for k in range(4):
                seat = (leader + k) % 4
                h = hands[seat]
                legal = [c for c in h if can_play_card(c, table, h, trump, lead_ok or any(x.suit == trump for x in table))]
                if seat == 0:
                    snap = tr.update(list(h), list(table))
                    pw = len(table) >= 2 and who_takes_trick(table, trump) == len(table) - 2
                    move, why = recommend_for_mode(list(h), list(table), trump, "2v2",
                        trump_lead_allowed=lead_ok or any(x.suit == trump for x in table),
                        is_partner_winning=pw, snap=snap, last_to_play=(len(table) == 3),
                        use_mc=use_mc, budget=0.01, max_samples=6)
                    assert move in legal, f"deal {d}: нелегальный совет {move} ({why}); рука {h}, стол {table}, козырь {trump}"
                    assert move in h and move not in played_by_me, f"deal {d}: карта уже сыграна {move}"
                    pick = move; played_by_me.add(move)
                    checked += 1
                else:
                    pick = rng.choice(legal)
                h.remove(pick); table.append(pick)
                tr.update(list(hands[0]), list(table))
            leader = (leader + who_takes_trick(table, trump)) % 4
    return checked

def test_simulation_600():
    assert run() == 600 * 8

if __name__ == "__main__":
    import time; t = time.time()
    print("проверено советов:", run(), "за", round(time.time() - t), "с — нарушений нет")
