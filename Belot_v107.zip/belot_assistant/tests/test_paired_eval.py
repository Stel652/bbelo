from paired_eval import evaluate
from train_selfplay import BASE

def test_identical_versions_have_zero_difference():
    r = evaluate(dict(BASE), dict(BASE), n=20, seed=3)
    assert r["mean"] == 0 and r["violations"] == 0 and not r["better"]
