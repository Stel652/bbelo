from engine.cards import Card
from engine.rules import can_play_card
from engine.strategy import recommend_for_mode
from engine.tracker import CardTracker


def test_follow_suit_over_trump():
    hand = [Card('spades', 'A'), Card('hearts', '7'), Card('clubs', 'J')]
    table = [Card('hearts', 'A'), Card('hearts', 'K')]
    assert not can_play_card(Card('spades', 'A'), table, hand, 'spades', True)
    assert can_play_card(Card('hearts', '7'), table, hand, 'spades', True)


def test_recommendation_while_trick_is_in_progress():
    hand = [Card('spades', 'A'), Card('hearts', '7'), Card('clubs', 'J')]
    table = [Card('hearts', 'A'), Card('hearts', 'K')]
    card, reason = recommend_for_mode(hand, table, 'spades', '3p')
    assert card == Card('hearts', '7')
    assert reason


def test_opening_recommendation():
    hand = [Card('spades', 'A'), Card('hearts', '7'), Card('clubs', 'J')]
    card, reason = recommend_for_mode(hand, [], 'spades', '3p')
    assert card is not None
    assert reason


def test_tracker_counts_known_and_unseen():
    tracker = CardTracker()
    snap = tracker.update([Card('spades', 'A')], [Card('hearts', 'K')])
    assert snap['unseen_count'] == 30
    assert snap['known_played'] == 1
