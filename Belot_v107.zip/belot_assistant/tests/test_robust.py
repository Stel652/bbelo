from engine.cards import Card
from engine.robust import table_readings, robust_recommend
from engine.strategy import recommend_for_mode

def C(s, r): return Card(s, r)

def test_duplicate_forces_twin_and_legal_move():
    """Реальный журнал: J♠ уже сыграна, а на столе «K♠, J♠» -> J♠ на самом деле J♣; ход должен быть законным и при K♣ (идти в трефу)."""
    hand = [C('clubs','10'), C('clubs','Q'), C('clubs','A'), C('diamonds','9'), C('diamonds','A')]
    table = [C('spades','K'), C('spades','J')]
    banned = {C('spades','J')}
    rs = table_readings(table, banned, hand)
    assert all(r[1] == C('clubs','J') for r in rs)
    rec = lambda h, t: recommend_for_mode(h, t, 'hearts', '3p', use_mc=False, trump_lead_allowed=True, last_to_play=True)
    mv, _ = robust_recommend(rec, hand, table, 'hearts', banned)
    assert mv.suit == 'clubs'          # при K♣ на столе дискарт бы нарушил правила

def test_plain_table_unchanged():
    hand = [C('hearts','9'), C('spades','A')]
    table = [C('diamonds','K')]
    assert table_readings(table, set(), hand)[0] == table
