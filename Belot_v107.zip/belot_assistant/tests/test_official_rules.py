# Тесты по официальному регламенту (Cuprins 1-7 + «Cum se calculează bilele»).
import itertools, random
from engine.cards import Card, SUITS, RANKS_BY_DECK
from engine.rules import can_play_card, who_takes_trick
from engine.combinations import detect_combinations, best_combination
from engine.scoring import *
from engine.tracker import CardTracker
from engine.strategy import recommend_for_mode

C = lambda s, r: Card(s, r)
H, D, K, S = "hearts", "diamonds", "clubs", "spades"

def test_points_trump_order():
    T = "hearts"
    assert [C(T, r).points(T) for r in "J 9 A 10 K Q 8 7".split()] == [20, 14, 11, 10, 4, 3, 0, 0]
    o = sorted([C(T, r) for r in "J 9 A 10 K Q 8 7".split()], key=lambda c: -c.strength(T))
    assert [c.rank for c in o] == "J 9 A 10 K Q 8 7".split()

def test_points_plain_order():
    T = "hearts"
    assert [C(S, r).points(T) for r in "A 10 K Q J 9 8 7".split()] == [11, 10, 4, 3, 2, 0, 0, 0]
    o = sorted([C(S, r) for r in "A 10 K Q J 9 8 7".split()], key=lambda c: -c.strength(T))
    assert [c.rank for c in o] == "A 10 K Q J 9 8 7".split()

def test_round_total_162():
    for T in SUITS:
        deck = [C(s, r) for s in SUITS for r in RANKS_BY_DECK[32]]
        assert sum(c.points(T) for c in deck) == 152

def test_follow_suit_priority():
    hand = [C(S, "7"), C(H, "J")]
    assert [c for c in hand if can_play_card(c, [C(S, "A")], hand, H, True)] == [C(S, "7")]

def test_must_trump_when_no_suit():          # пример «Ești obligat să pui coz»
    hand = [C(H, "9"), C(D, "A"), C(K, "K")]
    assert [c for c in hand if can_play_card(c, [C(S, "8")], hand, H, True)] == [C(H, "9")]

def test_free_discard_no_suit_no_trump():
    hand = [C(D, "A"), C(K, "K")]
    assert len([c for c in hand if can_play_card(c, [C(S, "8")], hand, H, True)]) == 2

def test_must_overtrump_if_able():
    hand = [C(H, "7"), C(H, "J"), C(D, "A")]
    table = [C(S, "8"), C(H, "10")]
    assert [c for c in hand if can_play_card(c, table, hand, H, True)] == [C(H, "J")]

def test_undertrump_allowed_if_cannot_beat():
    hand = [C(H, "7"), C(D, "A")]
    table = [C(S, "8"), C(H, "10")]
    assert [c for c in hand if can_play_card(c, table, hand, H, True)] == [C(H, "7")]

def test_trump_led_must_beat():
    hand = [C(H, "Q"), C(H, "9"), C(D, "A")]
    assert [c for c in hand if can_play_card(c, [C(H, "K")], hand, H, True)] == [C(H, "9")]

def test_trump_led_cannot_beat_play_any_trump():
    hand = [C(H, "7"), C(H, "8"), C(D, "A")]
    assert len([c for c in hand if can_play_card(c, [C(H, "J")], hand, H, True)]) == 2

def test_no_lead_trump_before_declarer():     # «Nu poți începe cu coz...»; исключение — только козыри
    hand = [C(H, "9"), C(H, "Q"), C(D, "7")]
    assert [c for c in hand if can_play_card(c, [], hand, H, False)] == [C(D, "7")]
    hand = [C(H, "9"), C(H, "Q")]
    assert len([c for c in hand if can_play_card(c, [], hand, H, False)]) == 2

def test_trick_winner_example():             # A♠ против J♥ (козырь) -> бьёт коз.
    assert who_takes_trick([C(S, "A"), C(H, "J")], H) == 1
def test_trick_winner_no_trump_highest_lead():
    assert who_takes_trick([C(S, "K"), C(D, "A"), C(S, "10")], H) == 2
def test_trick_winner_highest_trump():
    assert who_takes_trick([C(H, "A"), C(H, "9"), C(H, "10"), C(S, "A")], H) == 1
def test_offsuit_never_wins():
    assert who_takes_trick([C(S, "7"), C(D, "A"), C(K, "A")], H) == 0

def hand_of(*ids): return [C(*x) for x in ids]
def test_combinations():
    T = H
    names = lambda h: [n for n, _, _ in detect_combinations(h, T)]
    assert "bella" in names(hand_of((H, "Q"), (H, "K")))
    assert "tertz" in names(hand_of((S, "7"), (S, "8"), (S, "9")))
    assert "half_hundred" in names(hand_of((S, "10"), (S, "J"), (S, "Q"), (S, "K")))
    assert "hundred" in names(hand_of((D, "9"), (D, "10"), (D, "J"), (D, "Q"), (D, "K")))
    assert "four_J" in names([C(s, "J") for s in SUITS])
    pts = {n: p for n, p, _ in detect_combinations([C(s, "9") for s in SUITS], T)}
    assert pts["four_9"] == 150
    assert {n: p for n, p, _ in detect_combinations([C(s, "J") for s in SUITS], T)}["four_J"] == 200
    for r in "A 10 K Q".split():
        assert {n: p for n, p, _ in detect_combinations([C(s, r) for s in SUITS], T)}[f"four_{r}"] == 100
    assert "four_8" in names([C(s, "8") for s in SUITS]) and "four_7" in names([C(s, "7") for s in SUITS])
    assert "belot" in names([C(H, r) for r in RANKS_BY_DECK[32]])

def test_combination_priority():
    T = H
    a = detect_combinations([C(s, "J") for s in SUITS], T)
    b = detect_combinations(hand_of((S, "7"), (S, "8"), (S, "9")), T)
    assert best_combination(a + b, T)[0] == "four_J"
    t1 = ("tertz", 20, C(S, "9")); t2 = ("tertz", 20, C(D, "K"))
    assert best_combination([t1, t2], T)[2] == C(D, "K")      # старшая карта выше
    t3 = ("tertz", 20, C(H, "K"))
    assert best_combination([t2, t3], T)[2] == C(H, "K")      # равны -> козырная

def test_points_to_bile():
    assert [points_to_bile(x) for x in (64, 65, 66, 75, 76, 53)] == [6, 6, 7, 7, 8, 5]

def test_3p_example_from_rules():            # 64 / 53 / 65, играл первый -> 7 билей, не BT
    r = calculate_round_3p({0: 64, 1: 53, 2: 65}, 0)
    assert r[0] == 7 and r[1] == 5 and r[2] == 6 and not r["bt"]

def test_3p_tie_by_bile_uses_points():
    r = calculate_round_3p({0: 80, 1: 40, 2: 42}, 0)   # 8/4/4; играющий больше
    assert not r["bt"]
    r = calculate_round_3p({0: 60, 1: 60, 2: 42}, 0)
    assert r["equal"] or not r["bt"]

def test_pair_tie_splits():                  # 212 очков, 106/106 -> 11 : 11
    r = calculate_round_pair(106, 106, 1)
    assert r["team1"] == 11 and r["team2"] == 11 and not r["bt"]

def test_pair_bt_all_to_opponents():
    r = calculate_round_pair(70, 92, 1)
    assert r["bt"] and r["team1"] == 0 and r["team2"] == points_to_bile(162)

def test_1v1_exact_points_and_bt():
    assert calculate_round_1v1(90, 72, True)["bt"] is False
    r = calculate_round_1v1(70, 92, True)
    assert r["bt"] and r["opponent"] == 162
    assert not calculate_round_1v1(81, 81, True)["bt"]

def test_minuses():
    assert calculate_minuses(False, 0, "2v2") == 10
    assert calculate_minuses(False, 0, "1v1") == 100
    assert calculate_minuses(True, 3, "3p") == 10 and calculate_minuses(True, 2, "3p") == 0

def test_limits():
    assert game_limit("1v1") == 1010 and game_limit("2v2") == 101
    assert check_game_end([105, 103, 50], 101, "3p") == (None, 151)
    assert check_game_end([1100, 900], 1010, "1v1") == (0, 1010)
    assert check_game_end([105, 103], 101, "2v2", tournament=True)[0] == 0

def test_reduced_combos():
    rc = ReducedCombos()
    assert rc.apply(0, [100], False) == []
    assert rc.apply(0, [100], True) == [100] and rc.apply(0, [150], True) == [150]
    assert rc.apply(0, [100], True) == []
    rc2 = ReducedCombos(); rc2.apply(1, [100], True)
    assert rc2.apply(1, [100, 100], True) == [100, 100]
    rc3 = ReducedCombos()
    assert rc3.apply(2, [100, 100], True) == [100, 100] and rc3.apply(2, [100], True) == []

def _rand_state(rng, mode):
    ranks = RANKS_BY_DECK[32 if mode == "2v2" else 24]
    deck = [C(s, r) for s in SUITS for r in ranks]; rng.shuffle(deck)
    P = {"1v1": 2, "3p": 3, "2v2": 4}[mode]
    hand = deck[:rng.randint(1, 8)]
    table = deck[20:20 + rng.randint(0, P - 1)]
    return hand, table, rng.choice(SUITS)

def test_bot_never_illegal_random():       # тысячи позиций, все режимы, с MC и без
    rng = random.Random(7)
    for mode in ("2v2", "3p", "1v1"):
        for i in range(400):
            hand, table, T = _rand_state(rng, mode)
            st = CardTracker(mode).update(hand, table)
            allowed = rng.random() < 0.5
            mv, _ = recommend_for_mode(hand, table, T, mode, trump_lead_allowed=allowed, snap=st,
                                       is_partner_winning=(mode == "2v2" and len(table) >= 2 and rng.random() < .5),
                                       i_declared=rng.random() < .5, last_to_play=len(table) == {"1v1": 1, "3p": 2, "2v2": 3}[mode],
                                       use_mc=(i % 10 == 0), budget=0.05, max_samples=20)
            legal = [c for c in hand if can_play_card(c, table, hand, T, allowed)]
            assert mv in legal, (mode, hand, table, T, mv, legal)

def test_bot_overtakes_with_cheapest():
    hand = [C(S, "K"), C(S, "A"), C(D, "7")]
    table = [C(S, "Q")]
    st = CardTracker("2v2").update(hand, table)
    mv, _ = recommend_for_mode(hand, table, H, "2v2", snap=st, use_mc=False)
    assert mv == C(S, "K")

def test_bot_gives_points_to_secure_partner():
    hand = [C(S, "A"), C(S, "7")]
    table = [C(S, "8"), C(D, "7"), C(S, "9")]  # заглушка, проверяем только легальность
    st = CardTracker("2v2").update(hand, table)
    mv, _ = recommend_for_mode(hand, table, H, "2v2", snap=st, is_partner_winning=True, last_to_play=True, use_mc=False)
    assert mv in hand
