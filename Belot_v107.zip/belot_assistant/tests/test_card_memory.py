from engine.cards import Card
from engine.tracker import CardTracker
from engine.card_memory import CardMemory

def C(s, r): return Card(s, r)

def test_void_makes_certain_and_contradiction():
    t = CardTracker("3p")
    hand = [C("hearts", "9")]
    m = CardMemory(t)
    a = m.analyse(hand)
    assert all(len(o) == 3 for o in a["possible"].values())
    t.voids[1].add("spades"); t.voids[2].add("spades")      # у 1 и 2 нет пик -> все пики у 3
    a = m.analyse(hand)
    spades = [c for c in a["unseen"] if c.suit == "spades"]
    assert spades and all(a["certain"][c] == 3 for c in spades)
    t.voids[3].add("spades")                               # у всех нет пик, а они не вышли
    assert set(m.analyse(hand)["contradictions"]) >= set(spades)

def test_probabilities_sum_to_one():
    t = CardTracker("2v2"); m = CardMemory(t)
    a = m.analyse([C("clubs", "A")])
    for c in a["unseen"]:
        assert abs(sum(a["prob"][(c, p)] for p in a["possible"][c]) - 1) < 1e-9
