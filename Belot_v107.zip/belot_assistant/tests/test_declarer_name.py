"""Кто выбрал козырь: моё имя (JackDaniels1) сверху -> я; любое другое имя или бейдж «A» -> не я / не прочиталось."""
import os, sys, types
sys.modules.setdefault("mss", types.ModuleType("mss"))
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import cv2
import config
from engine.vision import VisionEngine as V

S = os.path.join(os.path.dirname(__file__), "screens")


def _crop(name, dy=0):
    im = cv2.imread(os.path.join(S, name))
    h, w = im.shape[:2]
    z = config.ZONE_DECLARER_NAME
    x, y, ww, hh = config.scaled_zone((z[0], z[1] + dy, z[2], z[3]), w, h)
    return im[y:y + hh, x:x + ww]


def _ref():
    return cv2.imread(os.path.join(os.path.dirname(__file__), "..", "assets", "names", "my_name_top.png"))


def _me(img):
    r = V.name_score(img, _ref())
    return None if r is None else (r[0] >= config.NAME_MATCH_THR and 0.85 <= r[1] <= 1.15)


def test_my_name_detected():
    assert _me(_crop("r_2e55c5b6.png")) is True
    assert _me(_crop("r_c38a995b.png")) is True


def test_other_names_rejected():
    assert _me(_crop("r_cdaac949.png")) is False          # jora25_1994 (раньше давало ложное True)
    for n in ("n1.png", "n4.png", "r_3129c4de.png"):        # arteem / ya_vanea, раскладка с плашкой «14/A»
        assert _me(_crop(n, config.ZONE_DECLARER_NAME_ALT_DY)) is False


def test_badge_zone_is_not_a_name():
    img = _crop("n1.png")                                   # в раскладке с плашкой основная зона ловит бейдж «A»
    sig = V._name_sig(img)
    assert sig is None or sig.shape[1] < 45
