import json
from engine.cards import Card
from engine.decision_tracker import DecisionTracker, legal_moves
from engine.validation import check_state, is_valid

def C(s, r): return Card(s, r)

def test_legal_and_link_and_outcome(tmp_path):
    p = tmp_path / "d.jsonl"
    t = DecisionTracker("2v2", str(p))
    hand = [C("clubs", "9"), C("hearts", "A"), C("spades", "K")]
    table = [C("clubs", "8")]
    assert legal_moves(hand, table, "diamonds") == [C("clubs", "9")]
    did = t.record(hand, table, "diamonds", C("clubs", "9"), "тест")
    assert did and t.record(hand, table, "diamonds", C("clubs", "9"), "тест") == did
    assert t.link_played(C("clubs", "9")) == did
    full = [C("clubs", "8"), C("clubs", "9"), C("clubs", "7"), C("clubs", "10")]
    r = t.resolve_trick(full, C("clubs", "9"), "diamonds")
    assert r["decision_id"] == did and r["points"] == 10 and r["won"] is True  # 10♣ сыграл партнёр (напротив)
    s = t.summary()
    assert s["followed"] == 1 and s["illegal_advice"] == 0 and s["won"] == 1
    evs = [json.loads(l)["ev"] for l in p.read_text(encoding="utf-8").splitlines()]
    assert evs == ["decision", "played", "outcome"]

def test_illegal_advice_flagged(tmp_path):
    t = DecisionTracker("2v2", str(tmp_path / "d.jsonl"))
    hand = [C("clubs", "9"), C("hearts", "A")]
    t.record(hand, [C("clubs", "8")], "diamonds", C("hearts", "A"), "x")
    assert t.stats["illegal_advice"] == 1

def test_validation():
    assert is_valid([C("clubs", "9")], [], set(), "2v2")
    assert check_state([C("clubs", "9")], [C("clubs", "9")], set(), "2v2")
    assert check_state([C("clubs", "9")], [], {C("clubs", "9")}, "2v2")
    assert check_state([C("clubs", "7")], [], set(), "3p")   # 7 вне 24-карточной колоды

def test_resolve_from_table(tmp_path):
    t = DecisionTracker("2v2", str(tmp_path / "d.jsonl"))
    hand = [C("clubs", "9"), C("hearts", "A")]
    did = t.record(hand, [C("clubs", "8")], "diamonds", C("clubs", "9"), "x")
    t.link_played(C("clubs", "9"))
    full = [C("clubs", "8"), C("clubs", "9"), C("clubs", "A"), C("clubs", "7")]
    r = t.resolve_from_table(full, "diamonds")
    assert r["decision_id"] == did and r["won"] is False
    assert t.resolve_from_table(full, "diamonds") is None     # повторно не считается
