"""Тесты по матрице решений для 3 игроков (блоки 0, 2.34-2.37, 3, 6)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.cards import Card
from engine.rules import can_play_card, who_takes_trick
from engine.scoring import calculate_round_3p, calculate_minuses
from engine.strategy import _heuristic_recommend

C = lambda s, r: Card(s, r)
T = "spades"

def legal(hand, table, trump=T, tla=True):
    return {c for c in hand if can_play_card(c, table, hand, trump, tla)}

def test_0_1_overtrump():                     # 0.1 / 0.2
    hand = [C(T, "J"), C(T, "7")]
    assert legal(hand, [C("hearts", "A"), C(T, "K")]) == {C(T, "J")}
    hand = [C(T, "7"), C(T, "8")]
    assert legal(hand, [C("hearts", "A"), C(T, "K")]) == set(hand)

def test_0_3_0_5_follow_and_discard():       # 0.3 / 0.4 / 0.5
    hand = [C("hearts", "7"), C(T, "8"), C("clubs", "A")]
    assert legal(hand, [C("hearts", "K")]) == {C("hearts", "7")}
    hand = [C(T, "8"), C("clubs", "A")]
    assert legal(hand, [C("hearts", "K")]) == {C(T, "8")}
    hand = [C("diamonds", "8"), C("clubs", "A")]
    assert legal(hand, [C("hearts", "K")]) == set(hand)

def test_0_6_0_7_lead_trump():               # 0.6 / 0.7
    assert legal([C(T, "J"), C(T, "7")], [], tla=False) == {C(T, "J"), C(T, "7")}
    assert legal([C(T, "J"), C("clubs", "7")], [], tla=False) == {C("clubs", "7")}

def test_2_34_to_2_37_trump_on_table():
    # 2.34: на столе J, у меня 9 -> не перебить (нельзя), сбросить мелкую
    assert who_takes_trick([C(T, "J"), C(T, "9")], T) == 0
    p, _ = _heuristic_recommend([C(T, "9"), C(T, "7")], [C(T, "J")], T, "3p")
    assert p == C(T, "7") or p == C(T, "9")  # оба козыря обязаны, но берёт J
    # 2.36: на столе A, у меня 10 -> не бьёт
    assert who_takes_trick([C(T, "A"), C(T, "10")], T) == 0
    # 2.37: на столе 10, у меня A -> бьёт
    assert who_takes_trick([C(T, "10"), C(T, "A")], T) == 1
    # 2.35: на столе 9, у меня J -> бьёт
    assert who_takes_trick([C(T, "9"), C(T, "J")], T) == 1

def test_my_case_hearts_not_trump():         # случай пользователя: 9♥ K♥ на столе, у меня 10♥ Q♥
    hand = [C("hearts", "10"), C("hearts", "Q")]
    for table in ([C("hearts", "9"), C("hearts", "K")],):
        p, _ = _heuristic_recommend(hand, table, T, "3p", is_partner_winning=False, last_to_play=True)
        assert p == C("hearts", "10"), p     # 10 бьёт K, Q проигрывает

def test_my_case_hearts_trump():             # 9 козыря старше 10 -> не побить, сбрасываем Q
    hand = [C("hearts", "10"), C("hearts", "Q")]
    p, _ = _heuristic_recommend(hand, [C("hearts", "9"), C("hearts", "K")], "hearts", "3p", last_to_play=True)
    assert p == C("hearts", "Q"), p

def test_2_4_no_trump_discard_small():       # 2.4 / 0.5 нечем бить -> мелкая
    hand = [C("clubs", "A"), C("diamonds", "7")]
    p, _ = _heuristic_recommend(hand, [C("hearts", "K")], T, "3p")
    assert p == C("diamonds", "7")

def test_3_10_last_trick_bonus():            # 0.10
    from engine.scoring import ROUND_POINTS
    assert ROUND_POINTS == 162

def test_6_1_rule_example():                 # 64 + 53 + 65 = 182 -> 18 билей, мне 7, без BT
    r = calculate_round_3p({0: 64, 1: 53, 2: 65}, 0)
    assert not r["bt"] and r[0] == 7 and r[1] == 5 and r[2] == 6

def test_6_17_to_6_20_bt_logic():            # билей 18: исходы BT / без BT
    def bt(a, b, c):                          # очки подобраны под билей 7-6-5 и т.п.
        return calculate_round_3p({0: a, 1: b, 2: c}, 0)
    assert not bt(70, 60, 50)["bt"]           # 7 > 6, 7 > 5   (6.17)
    assert bt(50, 70, 60)["bt"]               # 5 < 7          (6.19)
    assert not bt(80, 50, 50)["bt"]           # 8 > 5          (6.20)
    r = bt(60, 60, 60)                        # 6.18 равенство билей и очков -> egal
    assert r["equal"] and not r["bt"]

def test_6_29_6_30_equal_bile_compare_points():
    # играющий и соперник по 6 билей: сравнение очков
    assert calculate_round_3p({0: 58, 1: 64, 2: 60}, 0)["bt"]          # 6=6=6 билей, 58 < 64 (6.29)
    assert not calculate_round_3p({0: 64, 1: 58, 2: 60}, 0)["bt"]      # 6=6=6 билей, 64 > 60 (6.30)

def test_4_20_minuses():                     # 4.20/4.23/6.10/6.14
    assert calculate_minuses(False, 0, "3p") == 10
    assert calculate_minuses(True, 3, "3p") == 10
    assert calculate_minuses(True, 2, "3p") == 0
    assert calculate_minuses(True, 0, "3p") == 0

def _mc(hand, table, trump=T):
    from engine.tracker import CardTracker
    from engine.strategy import recommend_for_mode
    import random; random.seed(3)
    snap = CardTracker("3p").update(hand, table)
    return recommend_for_mode(hand, table, trump, "3p", True, False, snap, False, len(table) == 2)

def test_3_19_ace_first_keep_jack():
    p, _ = _mc([C(T, "J"), C("hearts", "A")], [])
    assert p == C("hearts", "A"), p

def test_my_case_full_path_3p():
    p, _ = _mc([C("hearts", "10"), C("hearts", "Q"), C("clubs", "7")], [C("hearts", "9"), C("hearts", "K")])
    assert p == C("hearts", "10"), p

def test_3p_bonus_module_imports():
    from engine.situations import matrix3p_bonus
    assert callable(matrix3p_bonus)
