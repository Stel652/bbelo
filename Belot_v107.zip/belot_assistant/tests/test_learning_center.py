import json
from learning_center import archive_champion, rollback

def test_rollback(tmp_path):
    sp = str(tmp_path)
    json.dump({"champion": {"min_score": 55}}, open(tmp_path / "params.json", "w"))
    archive_champion(sp, {"min_score": 50}, {"min_score": 55}, 0.3, 3.0, 1000)
    assert rollback(sp) == {"min_score": 50}
    assert json.load(open(tmp_path / "params.json"))["champion"] == {"min_score": 50}
    assert rollback(sp) is None
