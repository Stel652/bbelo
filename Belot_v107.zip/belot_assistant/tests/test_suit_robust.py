# Регрессия: пики/трефы не путаются на разных разрешениях экрана; карты стола читаются.
import os, sys, types
import cv2
try:
    import mss  # noqa
except ImportError:
    sys.modules["mss"] = types.SimpleNamespace(mss=lambda: None)
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
for _p in (ROOT, HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)
import config
from engine.vision import VisionEngine
from test_vision_screens import TRUTH, NEW, SYM
RES = ((1279, 719), (1600, 900), (1100, 620), (960, 540), (1920, 1080), (2560, 1440))


def _swaps(got, truth):
    return [(a, b) for a, b in zip(got, truth) if a[:-1] == b[:-1] and a[-1] != b[-1] and a[-1] in "cs" and b[-1] in "cs"]


def test_no_club_spade_swaps_in_hand():
    v = VisionEngine()
    for i, truth in TRUTH.items():
        base = cv2.imread(os.path.join(HERE, "screens", f"s{i}.png"))
        for W, H in RES:
            img = base if W == 1279 else cv2.resize(base, (W, H), interpolation=cv2.INTER_AREA)
            x, y, w, h = config.scaled_zone(config.ZONE_MY_HAND_OLD, W, H)
            got = [c.rank + SYM[c.suit] for c, _ in v.detect_cards_in_image(img[y:y+h, x:x+w], vmin=105)]
            assert not _swaps(got, truth), f"s{i} {W}x{H}: путаница ♣/♠ {_swaps(got, truth)}"


def test_table_cards_read():
    v = VisionEngine()
    for i, (hand, table) in NEW.items():
        base = cv2.imread(os.path.join(HERE, "screens", f"n{i}.png"))
        H, W = base.shape[:2]
        x, y, w, h = config.scaled_zone(config.ZONE_TABLE, W, H)
        got = [c.rank + SYM[c.suit] for c, _ in v.detect_cards_in_image(base[y:y+h, x:x+w], vmin=185, scale=W / 1279.0)]
        assert got == table, f"стол {i}: {got} != {table}"


def test_learned_suit_templates_consistent():
    """Эталоны масти в assets/game_idx не перепутаны: у пики значок заметно «плотнее» (выпуклее), чем у трефы."""
    import numpy as np
    d = os.path.join(HERE, "..", "assets", "game_idx")
    sol = {"spades": [], "clubs": []}
    for f in os.listdir(d):
        name = f.split("#")[0]
        if not name.startswith("suit_") or name[5:] not in sol:
            continue
        img = cv2.imread(os.path.join(d, f), 0)
        p = cv2.resize(img, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC)
        m = ((p < 128) if p.mean() > 128 else (p > 128)).astype(np.uint8)
        cs, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        c = max(cs, key=cv2.contourArea)
        sol[name[5:]].append(cv2.contourArea(c) / cv2.contourArea(cv2.convexHull(c)))
    assert min(sol["spades"]) > max(sol["clubs"]), "в эталонах пики/трефы перемешаны"
