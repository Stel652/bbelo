# Противник зашёл 8 треф, козырь бубны, треф у меня нет, один козырь -> обязан резать козырем.
from engine.cards import Card
from engine.rules import can_play_card
from engine.tracker import CardTracker
from engine.strategy import recommend_for_mode

def C(s, r): return Card(s, r)

def test_must_trump_legal():
    hand = [C("diamonds", "9"), C("hearts", "A"), C("spades", "K")]
    table = [C("clubs", "8")]
    assert [c for c in hand if can_play_card(c, table, hand, "diamonds", True)] == [C("diamonds", "9")]

def test_advice_is_trump():
    for mode in ("2v2", "3p", "1v1"):
        hand = [C("diamonds", "9"), C("hearts", "A"), C("spades", "K"), C("hearts", "10")]
        table = [C("clubs", "8")]
        st = CardTracker(mode).update(hand, table)
        for mc in (False, True):
            mv, why = recommend_for_mode(hand, table, "diamonds", mode, snap=st, use_mc=mc)
            assert mv == C("diamonds", "9"), (mode, mc, mv, why)

def test_trump_when_partner_winning_still_follows_rules():
    hand = [C("diamonds", "7"), C("hearts", "A")]
    table = [C("clubs", "8"), C("clubs", "A")]
    st = CardTracker("2v2").update(hand, table)
    mv, _ = recommend_for_mode(hand, table, "diamonds", "2v2", snap=st, is_partner_winning=False, use_mc=False)
    assert mv == C("diamonds", "7")
