from engine.cards import Card
from engine.rules import who_takes_trick, can_play_card
from engine.scoring import (points_to_bile, calculate_round_1v1, calculate_round_pair,
                            calculate_round_3p, ReducedCombos, check_game_end)
from engine.combinations import detect_combinations, best_combination
from engine.strategy import recommend_for_mode

def C(r, s): return Card(s, r)

def test_non_trump_order_ten_beats_king():
    assert who_takes_trick([C('K', 'hearts'), C('10', 'hearts')], 'spades') == 1
    assert who_takes_trick([C('10', 'hearts'), C('A', 'hearts')], 'spades') == 1
    assert who_takes_trick([C('J', 'hearts'), C('9', 'hearts')], 'spades') == 0

def test_trump_order():
    assert who_takes_trick([C('A', 'spades'), C('9', 'spades'), C('J', 'spades')], 'spades') == 2
    assert who_takes_trick([C('A', 'hearts'), C('7', 'spades')], 'spades') == 1

def test_must_trump_even_if_partner_wins():
    hand = [C('7', 'spades'), C('K', 'clubs')]
    table = [C('A', 'hearts'), C('7', 'hearts')]
    assert not can_play_card(C('K', 'clubs'), table, hand, 'spades', True)
    card, _ = recommend_for_mode(hand, table, 'spades', '2v2', is_partner_winning=True)
    assert card == C('7', 'spades')

def test_bile_rounding_half_down():
    assert [points_to_bile(p) for p in (64, 65, 66, 75, 76, 106)] == [6, 6, 7, 7, 8, 11]

def test_1v1_tie_no_bt():
    r = calculate_round_1v1(81, 81, True)
    assert not r['bt']
    assert calculate_round_1v1(70, 92, True)['bt']

def test_pair_equal_and_bt():
    r = calculate_round_pair(106, 106, 1)
    assert (r['team1'], r['team2'], r['bt']) == (11, 11, False)
    r = calculate_round_pair(70, 92, 1)
    assert r['bt'] and r['team1'] == 0 and r['team2'] == points_to_bile(162)

def test_3p_example_from_rules():
    # X играет 64, Y 53, Z 65 -> X получает 7 билей, BT нет
    r = calculate_round_3p({0: 64, 1: 53, 2: 65}, 0)
    assert r[0] == 7 and r[1] == 5 and r[2] == 6 and not r['bt']

def test_3p_equal_by_points():
    r = calculate_round_3p({0: 81, 1: 81, 2: 0}, 0)
    assert r['equal'] and not r['bt']

def test_reduced_combos():
    rc = ReducedCombos()
    assert rc.apply(0, [100], True) == [100]
    assert rc.apply(0, [100], False) == []          # без взятки не считается
    assert rc.apply(0, [150], True) == [150]
    assert rc.apply(0, [100], True) == []           # третья — нельзя
    rc2 = ReducedCombos()
    assert rc2.apply(1, [100, 100], True) == [100, 100]
    assert rc2.apply(1, [100], True) == []          # после двойной больше нельзя

def test_game_limit_extends():
    assert check_game_end([105, 110], 101, '2v2') == (None, 151)
    assert check_game_end([105, 90], 101, '2v2') == (0, 101)

def test_two_runs_same_suit_and_priorities():
    hand = [C(r, 'hearts') for r in ('7', '8', '9', 'J', 'Q', 'K')]
    names = [n for n, _, _ in detect_combinations(hand, 'spades')]
    assert names.count('tertz') == 2
    hand = [C('10', 'hearts'), C('J', 'hearts'), C('Q', 'hearts'), C('K', 'hearts')]
    n, p, top = best_combination(detect_combinations(hand, 'spades'), 'spades')
    assert (n, p, top.rank) == ('half_hundred', 50, 'K')

def test_pro_strategy():
    from engine.tracker import CardTracker, is_master, trumps_left
    from engine.hand_eval import evaluate_hand
    from engine.bile import BileTracker
    t = CardTracker('2v2')
    hand = [C('J','spades'), C('9','spades'), C('A','spades'), C('10','spades'), C('A','hearts'), C('7','clubs'), C('8','clubs'), C('9','diamonds')]
    snap = t.update(hand, [])
    assert is_master(C('J','spades'), snap, 'spades')
    assert not is_master(C('7','clubs'), snap, 'spades')  # у других есть 10♣, A♣ и др.
    assert len(trumps_left(snap, 'spades')) == 4
    assert evaluate_hand(hand, 'spades')[0] >= 80
    card, why = recommend_for_mode(hand, [], 'spades', '2v2', snap=snap, i_declared=True)
    assert card == C('J','spades') and 'козырь' in why   # объявил козырь -> начинаю с валета
    # партнёр берёт, я последний -> отдаю очки, не козырем
    table = [C('7','hearts'), C('K','hearts'), C('9','hearts')]
    h2 = [C('A','hearts'), C('7','clubs')]
    card, _ = recommend_for_mode(h2, table, 'spades', '2v2', is_partner_winning=True, last_to_play=True)
    assert card == C('A','hearts')
    # новая раздача сбрасывает память
    t.update([C('A','hearts')], [C('A','hearts')]); snap = t.update([C('A','hearts')], [])
    assert snap['known_played'] == 0
    b = BileTracker('2v2'); b.add_trick(64, True); b.add_trick(98, False)
    assert b.diff() == -4 and b.estimate_remaining() == 0

def test_bidding_rules():
    from engine.strategy import should_play
    h = [C('J','spades'), C('9','spades'), C('A','spades'), C('10','spades'), C('K','spades')]
    assert should_play(h, 'spades')[0]
    h = [C('7','spades'), C('8','spades'), C('A','hearts'), C('10','hearts'), C('K','clubs')]
    assert not should_play(h, 'spades')[0]
    h = [C('Q','spades'), C('K','spades'), C('10','spades'), C('A','hearts'), C('9','clubs')]
    assert should_play(h, 'spades')[0]       # 3 козыря + Bella

def test_void_tracking_and_risk():
    from engine.tracker import CardTracker, observe_complete_trick
    tr = CardTracker('2v2')
    table = [C('A','hearts'), C('7','hearts'), C('9','clubs'), C('K','hearts')]   # я = индекс 1; слева(2) сбросил ♣
    observe_complete_trick(tr, table, C('7','hearts'), 'spades')
    assert 'hearts' in tr.voids[1] and 'spades' in tr.voids[1]
    hand = [C('J','spades'), C('9','spades'), C('A','spades'), C('10','spades'), C('K','spades')]
    card, why = recommend_for_mode(hand, [], 'spades', '2v2', i_declared=True, risk='risky', lead_style='high')
    assert card == C('J','spades')


def test_bidding_3p_is_strict_without_partner():
    """Без партнёра слабые руки (3 козыря J+Q+K с Bella, 4 мелких козыря, 3 козыря + 2 туза) — Pas, иначе «болт»."""
    from engine.strategy import should_play
    h = [C('J','spades'), C('Q','spades'), C('K','spades'), C('A','hearts'), C('9','clubs')]
    assert should_play(h, 'spades')[0] and not should_play(h, 'spades', mode='3p')[0]
    h = [C('7','spades'), C('8','spades'), C('Q','spades'), C('K','spades'), C('A','hearts')]
    assert not should_play(h, 'spades', mode='3p')[0]
    h = [C('J','spades'), C('9','spades'), C('A','spades'), C('10','spades'), C('K','spades')]
    assert should_play(h, 'spades', mode='3p')[0]
    h = [C('J','spades'), C('9','spades'), C('A','spades'), C('10','hearts'), C('K','clubs')]
    assert should_play(h, 'spades', mode='3p')[0]
