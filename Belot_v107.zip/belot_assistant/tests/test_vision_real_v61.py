# Регрессия по реальным скриншотам игрока (1918x1078): рука из 7-8 карт, особенно ♠/♣.
import os, sys, types, cv2
try:
    import mss  # noqa
except ImportError:
    sys.modules["mss"] = types.SimpleNamespace(mss=lambda: None)
import config
from engine.vision import VisionEngine
SYM = {"hearts": "h", "diamonds": "d", "clubs": "c", "spades": "s"}
T = {"2e55c5b6": "Kd 9s Js 9c Jc Qc Kc", "9905ec8f": "7c 9c 9h Jh 7s Js Ks", "a4b652b9": "Qd Kd 7s 9h 10h Qh 7c Qc",
     "27405f2d": "Jc Qc Ac 9h 7s As 7d Kd", "3129c4de": "Qh 8c Jc Qc Kc Qd Ad 10s",
     "cdaac949": "9c Jc Kc Ac Jd Ad Js As", "c38a995b": "Jc Kd Ad 10s Ks 9h Jh Qh"}

def test_real_hands():
    here = os.path.dirname(__file__); v = VisionEngine()
    for k, t in T.items():
        img = cv2.imread(os.path.join(here, "screens", f"r_{k}.png")); H, W = img.shape[:2]
        x, y, w, h = config.scaled_zone(config.ZONE_MY_HAND_OLD, W, H)
        got = [c.rank + SYM[c.suit] for c, _ in v.detect_cards_in_image(img[y:y+h, x:x+w], vmin=105)]
        assert sorted(got) == sorted(t.split()), f"{k}: {got} != {t}"
