# Тесты правил хода и рекомендаций: бот никогда не должен советовать запрещённую карту.
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.cards import Card, SUITS
from engine.rules import can_play_card, who_takes_trick
from engine.strategy import recommend_for_mode
from engine.tracker import CardTracker

C = lambda s, r: Card(s, r)
legal = lambda hand, table, trump, lead_ok=True: [c for c in hand if can_play_card(c, table, hand, trump, lead_ok)]

def test_must_follow_suit():
    hand = [C("hearts", "K"), C("spades", "A"), C("clubs", "9")]
    assert legal(hand, [C("hearts", "7")], "clubs") == [C("hearts", "K")]      # есть масть -> только она

def test_must_trump_when_void():
    hand = [C("spades", "A"), C("clubs", "9"), C("diamonds", "K")]
    assert legal(hand, [C("hearts", "7")], "clubs") == [C("clubs", "9")]       # нет масти, есть козырь -> козырь

def test_void_and_no_trump_any_card():
    hand = [C("spades", "A"), C("diamonds", "K")]
    assert set(legal(hand, [C("hearts", "7")], "clubs")) == set(hand)

def test_must_overtrump():
    hand = [C("clubs", "7"), C("clubs", "J"), C("spades", "A")]
    assert legal(hand, [C("hearts", "7"), C("clubs", "K")], "clubs") == [C("clubs", "J")]

def test_cannot_overtrump_any_trump_ok():
    hand = [C("clubs", "7"), C("clubs", "8")]
    assert set(legal(hand, [C("hearts", "7"), C("clubs", "J")], "clubs")) == set(hand)

def test_trump_led_must_beat_if_can():
    hand = [C("clubs", "9"), C("clubs", "7"), C("hearts", "A")]
    assert legal(hand, [C("clubs", "K")], "clubs") == [C("clubs", "9")]

def test_follow_suit_even_if_trump_on_table():
    hand = [C("hearts", "7"), C("clubs", "J")]
    assert legal(hand, [C("hearts", "K"), C("clubs", "8")], "clubs") == [C("hearts", "7")]

def test_trick_winner():
    t = [C("hearts", "A"), C("hearts", "10"), C("clubs", "7"), C("hearts", "K")]
    assert who_takes_trick(t, "clubs") == 2                                    # самый младший козырь бьёт масть
    assert who_takes_trick(t[:2] + [C("spades", "A")], "clubs") == 0           # A бьёт 10 (не в масть не считается)
    assert who_takes_trick([C("hearts", "K"), C("hearts", "10")], "clubs") == 1  # 10 старше K

def test_recommendation_always_legal():
    rng = random.Random(7)
    deck = [Card(s, r) for s in SUITS for r in ("7", "8", "9", "10", "J", "Q", "K", "A")]
    for _ in range(400):
        trump = rng.choice(SUITS)
        cards = deck[:]; rng.shuffle(cards)
        nhand = rng.randint(2, 8)
        hand, rest = cards[:nhand], cards[nhand:]
        n = rng.randint(0, 3)
        table = rest[:n]
        tr = CardTracker("2v2"); snap = tr.update(hand, table)
        lead_ok = rng.random() < 0.5
        pw = n >= 2 and who_takes_trick(table, trump) == n - 2
        for use_mc in (False, True):
            move, why = recommend_for_mode(hand, table, trump, "2v2", trump_lead_allowed=lead_ok,
                                           is_partner_winning=pw, snap=snap, last_to_play=(n == 3),
                                           use_mc=use_mc, budget=0.02, max_samples=8)
            if legal(hand, table, trump, lead_ok):
                assert move in legal(hand, table, trump, lead_ok), (hand, table, trump, move, why, use_mc)

def test_trump_icon_classifier():
    import cv2, numpy as np
    try:
        from PIL import Image, ImageDraw, ImageFont
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 30)
    except Exception:
        return
    import types
    sys.modules.setdefault("mss", types.SimpleNamespace(mss=lambda: None))
    from engine.vision import VisionEngine
    for ch, col, want in (("♠", (0, 0, 0), "spades"), ("♣", (0, 0, 0), "clubs"),
                          ("♥", (220, 30, 40), "hearts"), ("♦", (220, 30, 40), "diamonds")):
        im = Image.new("RGB", (36, 36), (255, 255, 255))
        ImageDraw.Draw(im).text((18, 18), ch, font=font, fill=col, anchor="mm")
        assert VisionEngine.classify_trump_icon(cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)) == want


def test_void_no_trump_discards_lowest_3p():
    from engine.cards import Card
    from engine.strategy import recommend_for_mode
    hand = [Card('diamonds', 'A'), Card('clubs', '7'), Card('spades', 'K'), Card('spades', '8')]
    table = [Card('hearts', '9')]
    snap = {"unseen": [Card('hearts', 'A'), Card('hearts', '10'), Card('clubs', '9'), Card('spades', 'Q'),
                       Card('diamonds', '9'), Card('diamonds', '10'), Card('hearts', 'K'), Card('hearts', 'Q')]}
    for mc in (False, True):
        mv, _ = recommend_for_mode(hand, table, 'spades_x' if False else 'hearts', '3p', True, False, snap, False, False, None, use_mc=mc)
        assert mv == Card('clubs', '7'), mv
