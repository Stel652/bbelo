# 100 раздач на троих (24 карты, 8 взяток): совет легален, из руки, не повторяется;
# если нет масти и козыря и взятку не взять -> совет = самая младшая карта.
import os, sys, random, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.cards import Card, SUITS
from engine.rules import can_play_card, who_takes_trick
from engine.strategy import recommend_for_mode
from engine.tracker import CardTracker

DECK = [Card(s, r) for s in SUITS for r in ("9", "10", "J", "Q", "K", "A")]

def run(deals=100, seed=7):
    rng = random.Random(seed); checked = discards = 0
    for d in range(deals):
        trump = rng.choice(SUITS)
        cards = DECK[:]; rng.shuffle(cards)
        hands = {i: cards[i*8:(i+1)*8] for i in range(3)}
        tr = CardTracker("3p"); leader = rng.randrange(3); used = set()
        lead_ok = rng.random() < 0.5
        for trick in range(8):
            table = []
            for k in range(3):
                seat = (leader + k) % 3; h = hands[seat]
                allow = lead_ok or any(x.suit == trump for x in table)
                legal = [c for c in h if can_play_card(c, table, h, trump, allow)]
                if seat == 0:
                    snap = tr.update(list(h), list(table))
                    mv, why = recommend_for_mode(list(h), list(table), trump, "3p", trump_lead_allowed=allow,
                        is_partner_winning=False, snap=snap, last_to_play=(len(table) == 2),
                        use_mc=(d % 2 == 0), budget=0.01, max_samples=6)
                    assert mv in legal, f"deal {d}: нелегальный {mv} ({why}); рука {h}, стол {table}, козырь {trump}"
                    assert mv in h and mv not in used
                    if table and len(legal) > 1 and not why.startswith("точный разбор") and not any(who_takes_trick(table + [c], trump) == len(table) for c in legal):
                        low = min(legal, key=lambda c: (c.points(trump), c.strength(trump)))
                        assert mv == low, f"deal {d}: надо сбросить {low}, а совет {mv}"
                        discards += 1
                    used.add(mv); pick = mv; checked += 1
                else:
                    pick = rng.choice(legal)
                h.remove(pick); table.append(pick)
                tr.update(list(hands[0]), list(table))
            leader = (leader + who_takes_trick(table, trump)) % 3
    return checked, discards

def test_3p_100():
    c, _ = run(); assert c == 800

if __name__ == "__main__":
    t = time.time(); c, ds = run()
    print(f"100 раздач, советов: {c}, проверок сброса младшей: {ds}, {time.time()-t:.1f} с — нарушений нет")
