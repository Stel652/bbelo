from engine.cards import Card
from engine.hit_filters import filter_table, dedupe_black_twins
def C(s, r): return Card(s, r)

def test_table_phantoms_removed():
    sc = {"Ks": (0.78, 0.03), "Kd": (0.92, 0.98), "10s": (0.97, 0.98), "Ah": (0.30, 0.9)}
    hits = [(C("spades", "K"), (10, 0)), (C("diamonds", "K"), (50, 0)), (C("spades", "10"), (90, 0)), (C("hearts", "A"), (130, 0))]
    keep, drop = filter_table(hits, sc)                                   # низкая масть сама по себе — не повод убирать
    assert [c for c, _ in keep] == [C("spades", "K"), C("diamonds", "K"), C("spades", "10")] and len(drop) == 1
    keep, drop = filter_table(hits, sc, dead={C("spades", "K")})          # ...но у уже вышедшей карты — повод
    assert C("spades", "K") not in [c for c, _ in keep]
    assert filter_table(hits, {})[1] == []          # без оценок ничего не удаляем

def test_real_black_cards_with_zero_suit_kept():
    # реальные данные: сыгранный A♣ имел оценки (0.65, 0.0) и убирался фильтром
    hits = [(C("clubs", "A"), (10, 0))]
    assert filter_table(hits, {"Ac": (0.65, 0.0)})[0] == hits
    assert filter_table(hits, {"Ac": (0.30, 0.0)}, protect={C("clubs", "A")})[0] == hits   # карта из моей руки — всегда настоящая

def test_black_twin_prefers_known_card():
    sc = {"Ks": (0.73, 0.12), "Kc": (0.76, 0.68)}
    hits = [(C("spades", "K"), (400, 5)), (C("clubs", "K"), (405, 5)), (C("hearts", "A"), (600, 5))]
    out, dropped = dedupe_black_twins(hits, sc, known_hand={C("spades", "K")}, played=set())
    assert C("spades", "K") in [c for c, _ in out] and C("clubs", "K") not in [c for c, _ in out]
    assert len(out) == 2 and len(dropped) == 1
    # без знаний выбирается лучшая оценка масти
    out2, _ = dedupe_black_twins(hits, sc)
    assert C("clubs", "K") in [c for c, _ in out2]
    # разные позиции — две разные карты
    far = [(C("spades", "K"), (100, 5)), (C("clubs", "K"), (400, 5))]
    assert len(dedupe_black_twins(far, sc)[0]) == 2


def test_trick_gate_removes_leftovers():
    from engine.hit_filters import TrickGate
    g = TrickGate(need=3, gone=4)
    old = [(C("hearts", "10"), (10, 0)), (C("hearts", "A"), (50, 0)), (C("clubs", "9"), (90, 0))]
    for _ in range(3): keep, drop = g.update(old, 3)
    assert len(keep) == 3 and drop == []                      # комплект виден — ещё не остаток
    new = old + [(C("diamonds", "K"), (130, 0))]
    keep, drop = g.update(new, 3)
    assert [c for c, _ in keep] == [C("diamonds", "K")] and len(drop) == 3
    for _ in range(4): keep, drop = g.update([new[3]], 3)     # стол очистился от старых карт
    assert g.stale == {}
    keep, _ = g.update(old[:1], 3)                            # та же карта позже — уже новая взятка
    assert len(keep) == 1

def test_trick_gate_incomplete_trick_untouched():
    from engine.hit_filters import TrickGate
    g = TrickGate()
    two = [(C("hearts", "10"), (10, 0)), (C("hearts", "A"), (50, 0))]
    for _ in range(10): keep, drop = g.update(two, 3)
    assert len(keep) == 2 and drop == []


def test_played_guard_confirmed_card_not_back_in_hand():
    from engine.hit_filters import PlayedGuard
    g = PlayedGuard(back=8)
    J = C("clubs", "J"); A = C("hearts", "A")
    assert g.update({J, A}, {J, A}) == set()               # без подтверждённого хода руку не трогаем
    g.confirm([J])                                         # ход J♣ подтверждён
    for _ in range(3): assert g.update({J, A}, {J, A}) == {J}   # J♣ снова в руке — убираем
    for _ in range(7): assert g.update({A}, {A}) == set()
    assert J in g.ban or True
    g.update({A}, {A}); assert g.ban == {}                 # ~8 кадров отсутствия — бан снят

def test_played_guard_phantom_dup_does_not_ban():
    from engine.hit_filters import PlayedGuard
    g = PlayedGuard(); K = C("spades", "K")
    for _ in range(5): assert g.update({K}, {K}) == set()  # призрак на столе без подтверждённого хода — карта остаётся в руке


def test_lead_suit_fix_real_case():
    from engine.hit_filters import lead_suit_fix
    from engine.decision_tracker import legal_moves
    table = [C("spades", "Q"), C("spades", "A")]
    hand = [C("clubs", "J"), C("diamonds", "K"), C("hearts", "Q")]          # бот видел J♣, на деле у игрока пика
    new, fl = lead_suit_fix(hand, table)
    assert C("spades", "J") in new and len(fl) == 1
    assert legal_moves(new, table, "hearts") == [C("spades", "J")]          # обязан идти пикой, а не козырем
    assert lead_suit_fix(hand, table, forbidden={C("spades", "J")})[1] == []   # такая карта уже вышла — не трогаем
    assert lead_suit_fix([C("spades", "9"), C("clubs", "J")], table)[1] == []  # масть есть — ничего не меняем
    assert lead_suit_fix(hand, [C("hearts", "A")])[1] == []                  # заход не чёрный
