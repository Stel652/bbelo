import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from engine.cards import Card
from engine.tracker import CardTracker

def C(r, s): return Card(s, r)

def test_closed_trick_twin_fix():
    t = CardTracker("2v2")
    trick = [C("A", "spades"), C("9", "spades"), C("10", "spades"), C("K", "spades")]
    hand = [C("J", "spades"), C("J", "clubs")]
    for i in range(1, 5):
        t.update(hand, trick[:i])
    t.update(hand, [])                       # стол убрали
    assert t.tricks_done == 1 and C("10", "spades") in t.closed
    # 10♠ уже вышла: чтение 10♠ в руке — это 10♣
    assert t.fix_black([(C("10", "spades"), (0, 0))])[0][0] == C("10", "clubs")
    # обе 10 невозможны -> отбрасываем
    t.closed.add(C("10", "clubs"))
    assert t.fix_black([(C("10", "spades"), (0, 0))]) == []
    # карта на столе не может одновременно быть в руке
    t2 = CardTracker("2v2")
    assert t2.fix_black([(C("J", "spades"), (0, 0))], forbid={C("J", "spades")})[0][0] == C("J", "clubs")

def test_round_state_roundtrip(tmp_path=None):
    from engine import memory
    import tempfile
    memory.DATA_DIR = tempfile.mkdtemp()
    m = memory.GameMemory("2v2"); t = CardTracker("2v2")
    t.closed = {C("A", "spades"), C("9", "spades")}; t.seen = set(t.closed); t.voids[1].add("hearts")
    m.save_round(t, "clubs", [C("J", "clubs")])
    t2 = CardTracker("2v2"); assert memory.GameMemory("2v2").load_round(t2)
    assert t2.closed == t.closed and "hearts" in t2.voids[1]
