# Регрессия по реальным кадрам игрока (belot.md, экран 1920x1080): ♠/♣, затемнённые карты, окно результатов.
import os, sys, types
import cv2
try:
    import mss  # noqa
except ImportError:
    sys.modules["mss"] = types.SimpleNamespace(mss=lambda: None)
import config
from engine.vision import VisionEngine
from engine import playable, suit_shape

HERE = os.path.join(os.path.dirname(__file__), "real_v107")
SYM = {"hearts": "h", "diamonds": "d", "clubs": "c", "spades": "s"}
_V = None


def vis():
    global _V
    if _V is None:
        _V = VisionEngine()
    return _V


def img(name):
    im = cv2.imread(os.path.join(HERE, name))
    assert im is not None, name
    return im


def hand(name):
    im = img(name)
    hits = vis().detect_cards_in_image(im, vmin=105, hand_scale=im.shape[1] / float(config.ZONE_MY_HAND[2]))
    return [c.rank + SYM[c.suit] for c, _ in hits], hits, im


def table(name):
    im = img(name)
    hits = vis().detect_cards_in_image(im, scale=im.shape[1] / float(config.ZONE_TABLE[2]))
    return sorted(c.rank + SYM[c.suit] for c, _ in hits)


def test_hands_spade_club_not_confused():
    truth = {
        "f990_hand.png": ["9c", "Kc", "Js", "Qs", "As", "Jd", "Qd", "Ad"],   # Q♠ раньше читалась как Q♣ (+ призрак J♣)
        "f1059_hand.png": ["9c", "Kc", "Js", "Qs", "Qd"],
        "f1129_hand.png": ["Kc", "Js", "Qs"],
        "f1256_hand.png": ["Jh", "9s", "10s", "Js", "Qd"],
        "f801_hand.png": ["10c", "Kc", "Ac"],
        "f785_hand.png": ["Ah", "10c", "Kc", "Ac"],
    }
    for name, t in truth.items():
        got, _, _ = hand(name)
        assert got == t, f"{name}: {got} != {t}"


def test_table_cards():
    got = set(table("f785_table.png"))      # третья карта (моя Q♣) полупрозрачна: исчезает со стола, читается не всегда
    assert {"Ks", "Qd"} <= got <= {"Ks", "Qd", "Qc"}, got
    assert table("f1059_table.png") == sorted(["Ks", "As"])


def test_suit_shape_classifier_on_real_pips():
    # каждый угол чёрной карты с разметкой: >0 пики, <0 трефы
    for name, lab in (("f990_hand.png", ["9c", "Kc", "Js", "Qs", "As", "Jd", "Qd", "Ad"]), ("f801_hand.png", ["10c", "Kc", "Ac"])):
        im = img(name)
        boxes, _ = vis()._find_card_boxes(im, 105)
        for (x, y, w, h), l in zip(sorted(boxes), lab):
            if l[-1] not in "cs":
                continue
            s = suit_shape.score_card(im[y:y + h, x:x + w])
            assert s is not None and (s > 0) == (l[-1] == "s"), (name, l, s)


def test_dim_cards_are_not_playable():
    """f669: игра затемнила 6 карт, единственная разрешённая — K♦ (заход A♦)."""
    got, hits, im = hand("f669_hand.png")
    lv, unmatched = playable.read(vis(), im, hits)
    assert unmatched == 0
    legal = playable.screen_legal(lv)
    assert legal is not None and sorted(str(c) for c in legal) == ["K♦"], legal


def test_all_bright_means_no_signal():
    for name in ("f990_hand.png", "f801_hand.png", "f1256_hand.png"):
        _, hits, im = hand(name)
        lv, _ = playable.read(vis(), im, hits)
        assert playable.screen_legal(lv) is None, name


def test_oracle_needs_two_identical_frames():
    got, hits, im = hand("f669_hand.png")
    lv, um = playable.read(vis(), im, hits)
    o = playable.PlayableOracle()
    assert o.update(lv, um) is None            # первый кадр — ещё не подтверждён
    assert o.update(lv, um) is not None         # второй такой же — принят
    assert o.update(lv, 1) is None              # есть нераспознанная карта — сигнал снят


def test_results_dialog_detected():
    for name in ("f872_dialog_full.jpg", "f1211_dialog_full.jpg"):
        assert VisionEngine.is_results_dialog(_center(img(name))), name
    for name in ("f917_nodialog_full.jpg", "f990_full.jpg"):
        assert not VisionEngine.is_results_dialog(_center(img(name))), name


def _center(im):
    H, W = im.shape[:2]
    x, y, w, h = config.scaled_zone(config.ZONE_RESULTS, W, H)
    return im[y:y + h, x:x + w]
