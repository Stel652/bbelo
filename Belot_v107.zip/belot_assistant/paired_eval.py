"""Парное сравнение Challenger vs Champion на ОДИНАКОВЫХ раздачах со сменой сторон.
  python paired_eval.py '{"voids": true}' [раздач=2000] [seed=12345]
Параметры Challenger накладываются на текущего чемпиона. Новая версия считается лучше только при z >= 2.5."""
import sys, os, json, math, random
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from train_selfplay import play_round, BASE

def evaluate(chal, champ, n=2000, seed=12345):
    tot = sq = viol = 0
    for i in range(n):
        rng = random.Random(seed * 1_000_003 + i); d = rng.randrange(4); st = rng.getstate()
        r1, v1, _ = play_round(rng, [chal, champ], d); rng.setstate(st)
        r2, v2, _ = play_round(rng, [champ, chal], d)
        x = r1 - r2; tot += x; sq += x * x; viol += len(v1) + len(v2)
    m = tot / n; se = math.sqrt(max(sq / n - m * m, 1e-9) / n)
    return dict(n=n, mean=round(m, 3), z=round(m / se, 2), violations=viol, better=m / se >= 2.5 and viol == 0)

if __name__ == "__main__":
    pp = os.path.join(HERE, "data", "selfplay", "params.json")
    champ = json.load(open(pp, encoding="utf-8")).get("champion", BASE) if os.path.exists(pp) else BASE
    over = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    res = evaluate(dict(champ, **over), champ, int(sys.argv[2]) if len(sys.argv) > 2 else 2000,
                   int(sys.argv[3]) if len(sys.argv) > 3 else 12345)
    print(res)
    import time   # Strategy/Learning Tracker: каждый эксперимент сохраняется
    os.makedirs(os.path.dirname(pp), exist_ok=True)
    with open(os.path.join(os.path.dirname(pp), "experiments.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(dict(t=int(time.time()), champion=champ, override=over, **res), ensure_ascii=False) + "\n")
