# debug_vision.py  — проверка распознавания по скриншоту, без запуска игры.
# Запуск:  python debug_vision.py screenshot.png [x y w h]
# Без координат берётся ZONE_MY_HAND из config.py. Результат: debug_out.png
import sys, types, cv2
try:
    import mss  # noqa
except ImportError:
    sys.modules["mss"] = types.SimpleNamespace(mss=lambda: None)
import config
from engine.vision import VisionEngine

img = cv2.imread(sys.argv[1])
if img is None:
    sys.exit("Не удалось открыть скриншот")
H, W = img.shape[:2]
z = tuple(map(int, sys.argv[2:6])) if len(sys.argv) >= 6 else config.scaled_zone(config.ZONE_MY_HAND, W, H)
x, y, w, h = z
crop = img[y:y+h, x:x+w]
v = VisionEngine()
hits = v.detect_cards_in_image(crop, vmin=105)
print(f"Скриншот {W}x{H}, зона {z}")
print("Найдено карт:", len(hits), [str(c) for c, _ in hits])
print("Лучшие оценки:", getattr(v, "last_scores", {}))
for c, (cx, cy) in hits:
    cv2.circle(crop, (cx, cy), 4, (0, 255, 255), -1)
    cv2.putText(crop, str(c), (cx - 12, max(12, cy - 22)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
cv2.imwrite("debug_out.png", crop)
print("Сохранено: debug_out.png")
