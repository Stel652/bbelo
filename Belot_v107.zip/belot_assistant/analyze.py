"""Разбор накопленной памяти: python analyze.py — статистика советов и расхождений с твоей игрой."""
import json, os
from engine.memory import DATA_DIR

def main():
    st = os.path.join(DATA_DIR, "stats.json")
    if not os.path.exists(st):
        print("Данных пока нет — сыграй несколько партий с включённым анализом."); return
    s = json.load(open(st, encoding="utf-8"))
    f, i = s["followed"], s["ignored"]
    print(f"Взяток: {s['tricks']}, выиграно: {s['tricks_won']}, очков (мои−чужие): {s['points']}")
    print(f"Советам следовал: {f}, играл иначе: {i}\n")
    print(f"{'совет':45} {'n':>4} {'взял%':>6} {'ср.очк':>7} | иначе: n, взял%")
    for k, v in sorted(s["advice"].items(), key=lambda kv: -kv[1]["n"]):
        if v["n"] == 0: continue
        ign = f"{v['ign_n']}, {100*v['ign_win']//v['ign_n']}%" if v["ign_n"] else "-"
        print(f"{k[:45]:45} {v['n']:>4} {100*v['win']//v['n']:>5}% {v['pts']/v['n']:>+7.1f} | {ign}")
    print("\nГде ты играл иначе и выигрывал чаще бота — кандидаты на правку правил в strategy.py.")

if __name__ == "__main__":
    main()
